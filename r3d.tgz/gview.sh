#!/bin/bash
# gview.sh out.jpg [grip-json]   -> 4 close views of the phone grip (front, back, right side, left side)
G=${2:-}
B='{"rotY":2.9,"aimW":1,"phX":-0.16,"phY":0.8,"phZ":0.28,"handR":"grip","handL":"relax","mic":0,"aimYaw":3.9,"aimPitch":-0.8,"headX":0.15}'
P=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "[$B]"); V=$(python3 -c "import urllib.parse;print(urllib.parse.quote('[\"phone:0.33\",\"phone:-0.33\",\"phone:0:0.3\",\"phone:0:-0.3\"]'))")
X=""; [ -n "$G" ] && X="&grip=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$G")"
cd /home/claude/r3d && node shot.js "http://localhost:8765/lab.html?poses=$P&views=$V&fov=35$X" $1 | grep -v DBG | tail -1
