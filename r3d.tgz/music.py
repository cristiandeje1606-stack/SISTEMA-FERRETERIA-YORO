#!/usr/bin/env python3
"""Original synthesized soundtrack + SFX for a 62.6 s vertical promo.

Outputs (same folder as this script):
  music.wav   - music bed only (48 kHz stereo, peak -1 dBFS)
  sfx.wav     - SFX stem only
  premix.wav  - music + SFX before loudness normalisation
  mix_RS.wav  - final mix, -14 LUFS integrated, TP <= -1 dBTP (ffmpeg)

Edit the TIMELINE section and re-run:  python3 music.py
"""
import json, os, re, subprocess, sys
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

OUT = os.path.dirname(os.path.abspath(__file__))
SR = 48000
DUR = 62.6
N = int(DUR * SR)
rng = np.random.default_rng(1083)

# ============================ TIMELINE ==================================
CUTS = [4.5, 11, 18, 25, 31, 37, 44, 50, 56]
POPS = [1.2, 2.6, 3.3, 5.0, 7.2, 8.4, 11.4, 13.0, 15.2, 18.4, 19.6, 21.0, 22.0,
        22.8, 23.6, 25.4, 26.8, 27.6, 31.4, 32.4, 33.4, 34.4, 37.4, 39.0, 40.0,
        41.0, 44.4, 45.6, 46.6, 47.6, 50.4, 51.4, 52.4, 53.4, 56.4, 57.6, 58.6,
        59.6]
MOUSE = [2.4, 19.4]
SHUTTER = [6.8]
SUCCESS = [27.0]
TYPING = (12.5, 16.5)
FIRST_HIT = 0.6
LIFT_HIT = 56.0
FINAL_HIT = 60.5
GROOVE_FROM = 4.5          # full groove starts on the grid beat nearest this
BUILD = (49.3, 56.0)       # snare roll / riser into the close

# Tempo chosen (~108 BPM) so that 0.6 s and 56.0 s both land on downbeats
BARS_TO_LIFT = 25
BAR = (LIFT_HIT - FIRST_HIT) / BARS_TO_LIFT
BEAT = BAR / 4
BPM = 60 / BEAT
S16 = BEAT / 4
T0 = FIRST_HIT
NBARS = int(np.ceil((DUR - T0) / BAR)) + 1

# ============================ helpers ===================================
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def db(x): return 10 ** (x / 20)
def stereo(n): return np.zeros((n, 2))
def tt(n): return np.arange(n) / SR

def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'bandpass', fs=SR, output='sos'), x, axis=0)
def lp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'lowpass', fs=SR, output='sos'), x, axis=0)
def hp(x, fc, order=2):
    return sosfilt(butter(order, fc, 'highpass', fs=SR, output='sos'), x, axis=0)

def pan(mono, p):  # p in [-1, 1], constant power
    a = (p + 1) * np.pi / 4
    return np.stack([mono * np.cos(a), mono * np.sin(a)], 1)

def place(buf, sig, t):
    i = int(round(t * SR))
    if sig.ndim == 1: sig = pan(sig, 0)
    if i < 0: sig, i = sig[-i:], 0
    j = min(len(buf), i + len(sig))
    if j > i: buf[i:j] += sig[:j - i]

def adsr(n, a=0.005, d=0.1, s=0.7, r=0.05):
    e = np.ones(n) * s
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na = max(1, min(na, n)); e[:na] = np.linspace(0, 1, na)
    nd = min(nd, n - na)
    if nd > 0: e[na:na + nd] = 1 - (1 - s) * (1 - np.exp(-5 * np.linspace(0, 1, nd)))
    nr = min(nr, n)
    e[n - nr:] *= np.linspace(1, 0, nr) ** 2
    return e

def additive(f, n, hmax=12000, tilt=1.0, decay=None, kdec=0.6, phase_rand=True):
    """Bandlimited saw-like tone; per-harmonic exponential decay (natural pluck filter)."""
    t = tt(n); out = np.zeros(n)
    K = int(min(hmax, SR / 2 - 500) // f)
    for k in range(1, max(K, 1) + 1):
        amp = 1.0 / k ** tilt
        ph = rng.uniform(0, 2 * np.pi) if phase_rand else 0
        h = amp * np.sin(2 * np.pi * f * k * t + ph)
        if decay: h *= np.exp(-t / (decay / k ** kdec))
        out += h
    return out

def svf_sweep(x, f0, f1, q=1.2, curve=2.0):
    """Time-varying state-variable band-pass (python loop; used on short SFX)."""
    n = len(x); y = np.zeros(n); lo = bd = 0.0
    fc = f0 * (f1 / f0) ** (np.linspace(0, 1, n) ** curve)
    g = 2 * np.sin(np.pi * np.minimum(fc, SR / 6) / SR)
    damp = 1 / q
    for i in range(n):
        hi_ = x[i] - lo - damp * bd
        bd += g[i] * hi_
        lo += g[i] * bd
        y[i] = bd
    return y

def make_ir(dur=2.2, predelay=0.012, damp_hz=6000, seed=7):
    r = np.random.default_rng(seed); n = int(dur * SR)
    t = tt(n); ir = r.standard_normal((n, 2)) * np.exp(-t / (dur / 6.9))[:, None]
    ir = lp(ir, damp_hz, 1); ir[:int(0.003 * SR)] *= np.linspace(0, 1, int(0.003 * SR))[:, None]
    ir = np.vstack([np.zeros((int(predelay * SR), 2)), ir])
    return ir / np.sqrt(np.sum(ir ** 2) / 2)

IR_HALL = make_ir(2.4, 0.02, 5500, 7)
IR_ROOM = make_ir(0.9, 0.008, 8000, 11)

def reverb(x, ir, wet):
    if x.ndim == 1: x = pan(x, 0)
    y = np.stack([fftconvolve(x[:, 0], ir[:, 0])[:len(x)],
                  fftconvolve(x[:, 1], ir[:, 1])[:len(x)]], 1)
    y = hp(y, 180)
    return x + wet * y

def width(x, amt=1.3):
    m = (x[:, 0] + x[:, 1]) / 2; s = (x[:, 0] - x[:, 1]) / 2 * amt
    return np.stack([m + s, m - s], 1)

def noise(n): return rng.standard_normal(n)

# ============================ arrangement ===============================
def bar_t(b): return T0 + b * BAR
def step_t(b, s): return bar_t(b) + s * S16
groove_bar_from = (round((GROOVE_FROM - T0) / BEAT)) / 4.0   # in bars (can be fractional)
build_bar = int(np.floor((BUILD[0] - T0) / BAR + 0.5))
lift_bar = BARS_TO_LIFT
final_bar_t = FINAL_HIT

# D major: D  A  Bm  G
CHORDS = [
    dict(root=38, pad=[62, 66, 69, 74, 78]),
    dict(root=33, pad=[61, 64, 69, 73, 76]),
    dict(root=35, pad=[62, 66, 71, 74, 78]),
    dict(root=31, pad=[62, 67, 71, 74, 79]),
]
HOOK = [  # (16th step, midi)
    [(0, 74), (3, 78), (6, 76), (8, 74), (10, 69), (12, 71), (14, 74)],
    [(0, 73), (3, 76), (6, 73), (8, 69), (10, 71), (12, 73), (14, 76)],
    [(0, 74), (3, 78), (6, 81), (8, 78), (10, 76), (12, 74), (14, 76)],
    [(0, 79), (3, 78), (6, 76), (8, 74), (10, 71), (12, 74), (14, 73)],
]
BASS = [(0, 0, 3), (3, 0, 2), (6, 12, 2), (8, 0, 2), (10, 0, 2), (12, 12, 2), (14, 7, 2)]

def active(b, s=0):
    t = step_t(b, s)
    return t < FINAL_HIT - 0.02

def in_groove(b, s=0): return (b + s / 16) >= groove_bar_from - 1e-6
def in_close(b): return b >= lift_bar
def in_build(b): return build_bar <= b < lift_bar

# ---------------------------- instruments -------------------------------
def kick(vel=1.0):
    n = int(0.45 * SR); t = tt(n)
    f = 48 + 110 * np.exp(-t / 0.035)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.16)
    click = hp(noise(n), 2500) * np.exp(-t / 0.004) * 0.25
    x = np.tanh(1.6 * (body + click)) * vel
    return pan(x, 0)

def clap(vel=1.0):
    n = int(0.5 * SR); t = tt(n); x = np.zeros(n)
    for k, d in enumerate([0, 0.009, 0.019, 0.028]):
        i = int(d * SR); seg = n - i
        x[i:] += noise(seg) * np.exp(-tt(seg) / (0.006 if k < 3 else 0.11))
    x = bp(x, 900, 5200) * vel
    st = np.stack([x, np.roll(x, 90)], 1)
    return st * 0.6

def hat(vel=1.0, open_=False, p=0.0):
    n = int((0.28 if open_ else 0.06) * SR); t = tt(n)
    x = hp(noise(n), 7000, 4) * np.exp(-t / (0.07 if open_ else 0.014))
    x += hp(noise(n), 11000, 2) * np.exp(-t / 0.006) * 0.4
    return pan(x * vel, p)

def shaker(vel=1.0, p=0.0):
    n = int(0.08 * SR); t = tt(n)
    env = (t / 0.012) * np.exp(1 - t / 0.012)
    return pan(bp(noise(n), 4000, 12000) * env * vel, p)

def pluck(m, vel=1.0, dur=0.45):
    n = int(dur * SR); f = mtof(m); t = tt(n)
    a = additive(f * db(0.08) ** 0 * 2 ** (6 / 1200), n, 11000, 1.0, 0.35, 0.9)
    b = additive(f * 2 ** (-6 / 1200), n, 11000, 1.0, 0.35, 0.9)
    sub = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.3) * 1.2
    env = np.minimum(1, t / 0.002) * np.exp(-t / 0.28)
    env[-int(0.02 * SR):] *= np.linspace(1, 0, int(0.02 * SR))
    L = (0.8 * a + 0.35 * b + sub) * env; R = (0.35 * a + 0.8 * b + sub) * env
    return np.stack([L, R], 1) * vel * 0.12

def marimba(m, vel=1.0, p=0.0):
    f = mtof(m); n = int(0.9 * SR); t = tt(n)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.42)
         + 0.35 * np.sin(2 * np.pi * f * 3.93 * t) * np.exp(-t / 0.07)
         + 0.12 * np.sin(2 * np.pi * f * 9.2 * t) * np.exp(-t / 0.02))
    x += bp(noise(n), 2000, 6000) * np.exp(-t / 0.003) * 0.15
    x *= np.minimum(1, t / 0.001)
    return pan(x * vel * 0.22, p)

def bass(m, dur, vel=1.0):
    n = int(dur * SR); f = mtof(m); t = tt(n)
    x = additive(f, n, 2400, 1.15, 0.5, 0.5) * 0.35 + np.sin(2 * np.pi * f * t) * 0.9
    x *= adsr(n, 0.004, 0.12, 0.75, 0.03)
    return pan(np.tanh(1.3 * x) * vel * 0.5, 0)

def pad_chord(notes, dur, bright=1.0):
    n = int(dur * SR); out = stereo(n)
    det = [-14, -6, 0, 7, 13]; pans = [-0.8, -0.35, 0, 0.4, 0.8]
    for m in notes:
        for d, p in zip(det, pans):
            x = additive(mtof(m) * 2 ** (d / 1200), n, 2500 + 2500 * bright, 1.3)
            out += pan(x, p)
    out = lp(out, 2200 + 3500 * bright, 2)
    out *= adsr(n, 0.25, 0.6, 0.85, 0.35)[:, None]
    return out * 0.012

def crash(vel=1.0, dur=2.5):
    n = int(dur * SR); t = tt(n)
    x = np.stack([hp(noise(n), 5000, 2), hp(noise(n), 5000, 2)], 1)
    x = bp(x, 4000, 15000) * np.exp(-t / (dur / 4))[:, None]
    return x * vel * 0.35

def boom(vel=1.0, dur=1.8):
    n = int(dur * SR); t = tt(n)
    f = 32 + 70 * np.exp(-t / 0.08)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / (dur / 4))
    x = np.tanh(2.0 * x) + lp(noise(n), 400) * np.exp(-t / 0.15) * 0.4
    return pan(x * vel, 0)

# ---------------------------- render music ------------------------------
drums = stereo(N); bassb = stereo(N); plk = stereo(N); padb = stereo(N)
mar = stereo(N); fx = stereo(N)
kick_times = []

for b in range(-1, NBARS):
    if bar_t(b) > DUR: break
    ch = CHORDS[b % 4]
    phrase_end = (b % 4) == 3
    # ---- pad (whole session; opens up in build and close)
    if bar_t(b) < FINAL_HIT:
        bright = 0.35 if not in_groove(b + 1) else 0.6
        if in_build(b): bright = 0.6 + 0.35 * (b - build_bar + 1) / (lift_bar - build_bar)
        if in_close(b): bright = 1.0
        dur = min(BAR + 0.4, FINAL_HIT - bar_t(b) + 0.35)
        if bar_t(b) + dur > 0:
            place(padb, pad_chord(ch['pad'][:4] if not in_close(b) else ch['pad'], dur, bright), bar_t(b))
    for s in range(16):
        t = step_t(b, s)
        if t < 0 or t >= FINAL_HIT - 0.02: continue
        g = in_groove(b, s)
        # ---- kick: four on the floor (intro: only the hit)
        if g and s % 4 == 0 and not (in_build(b) and b == lift_bar - 1 and s >= 8):
            place(drums, kick(0.95), t); kick_times.append(t)
        # ---- clap on 2 & 4 (+ phrase-end pickup)
        if g and s in (4, 12): place(drums, clap(0.85), t)
        if g and phrase_end and s == 15 and not in_build(b): place(drums, clap(0.4), t)
        # ---- hats
        if g:
            if s % 4 == 2: place(drums, hat(0.55, True, 0.25), t)
            else: place(drums, hat(0.32 if s % 2 else 0.45, False, -0.2), t + (0.008 if s % 2 else 0))
            place(drums, shaker(0.18 + 0.08 * (s % 2), 0.45), t)
        elif t > 2.2 and s % 2 == 0:   # intro: soft offbeat hats teasing the groove
            place(drums, hat(0.22, s % 4 == 2, 0.2), t)
        # ---- build snare roll
        if in_build(b) and b >= lift_bar - 2:
            k = b - (lift_bar - 2)
            dens = 4 if k == 0 else (2 if s < 8 else 1)
            if s % dens == 0:
                v = 0.25 + 0.6 * ((k * 16 + s) / 32)
                place(drums, clap(v * 0.7), t)
        # ---- bass
        if g:
            for (st, iv, ln) in BASS:
                if st == s: place(bassb, bass(ch['root'] + iv, ln * S16 * 0.92, 1.0 if iv == 0 else 0.8), t)
        elif s == 0 and t > 0.5:  # intro: long soft root
            place(bassb, bass(ch['root'], BAR * 0.95, 0.45), t)
        # ---- hook pluck
        for (st, m) in HOOK[b % 4]:
            if st == s:
                if not g and st in (3, 12):   # sparser intro
                    continue
                v = 0.9 if st in (0, 8) else 0.72
                place(plk, pluck(m, v), t)
                if in_close(b): place(plk, pluck(m + 12, v * 0.45), t)
        # ---- marimba counter arp (groove only, offbeat 8ths)
        if g and s % 4 == 2:
            notes = ch['pad'][1:4]
            mm = notes[(s // 4 + b) % 3] + 12
            place(mar, marimba(mm, 0.7 if not in_close(b) else 0.9, 0.5 if (s // 4) % 2 else -0.5), t)

# ---- intro riser into the 0.6 s hit
n = int(FIRST_HIT * SR); t = tt(n)
r = svf_sweep(noise(n), 600, 9000, 2.0, 1.5) * (t / FIRST_HIT) ** 2
tone = np.sin(2 * np.pi * np.cumsum(220 * 2 ** (2 * t / FIRST_HIT)) / SR) * (t / FIRST_HIT) ** 3 * 0.25
place(fx, np.stack([r * 0.9 + tone, np.roll(r, 200) * 0.9 + tone], 1) * 0.6, 0)
# ---- hits
place(fx, boom(0.9), FIRST_HIT)
place(drums, kick(1.0), FIRST_HIT); kick_times.append(FIRST_HIT)
place(fx, crash(0.9, 2.5), FIRST_HIT)
for m in [62, 66, 69, 74, 78]: place(plk, pluck(m, 0.6, 0.9), FIRST_HIT)
# ---- build riser
n = int((BUILD[1] - BUILD[0]) * SR); t = tt(n)
rr = svf_sweep(noise(n), 300, 10000, 1.5, 2.2) * (t / t[-1]) ** 2.2
place(fx, np.stack([rr, np.roll(rr, 300)], 1) * 0.35, BUILD[0])
# ---- lift at 56: impact + crash
place(fx, boom(1.0, 2.0), LIFT_HIT); place(fx, crash(1.0, 3.0), LIFT_HIT)
# ---- final hit + tail at 60.5
place(fx, boom(1.1, 2.1), FINAL_HIT); place(fx, crash(1.0, 2.1), FINAL_HIT)
place(drums, kick(1.0), FINAL_HIT); kick_times.append(FINAL_HIT)
tail = int((DUR - FINAL_HIT) * SR)
fin = stereo(tail)
for m, v in zip([38, 50, 62, 66, 69, 74, 78, 81, 86], [1, .8, .7, .6, .6, .6, .5, .4, .3]):
    x = (pluck(m, v * 1.1, DUR - FINAL_HIT) if m > 45 else bass(m, DUR - FINAL_HIT, v))
    fin[:len(x)] += x
fin += pad_chord([62, 66, 69, 74, 78], DUR - FINAL_HIT, 1.0)[:tail] * 1.2
place(plk, fin, FINAL_HIT)

# ---- sidechain ducking from kick
sc = np.ones(N)
for tk in kick_times:
    i = int(tk * SR); m = min(N - i, int(0.35 * SR))
    if m <= 0: continue
    e = tt(m); env = 1 - np.exp(-e / 0.11) * (1 - np.exp(-e / 0.003))
    dip = 1 - 0.65 * (1 - env) / max(1e-9, (1 - env).max())
    sc[i:i + m] = np.minimum(sc[i:i + m], dip)
sc = sc[:, None]
duck_light = 1 - (1 - sc) * 0.4

# ---- buses
drums = reverb(drums, IR_ROOM, 0.12)
bassb = lp(bassb * sc, 3000)
plk = reverb(width(plk * duck_light, 1.2), IR_HALL, 0.22)
mar = reverb(mar * duck_light, IR_HALL, 0.30)
padb = reverb(width(padb * sc, 1.4), IR_HALL, 0.35)
fx = reverb(fx, IR_HALL, 0.25)

music = (1.0 * drums + 0.9 * bassb + 0.85 * plk + 0.55 * mar + 0.75 * padb + 0.8 * fx)
music = hp(music, 28, 2)

# ---- final fade (resolve by 62.6)
tt_all = tt(N)
fade = np.clip((DUR - tt_all) / (DUR - FINAL_HIT - 0.3), 0, 1) ** 1.6
fade[tt_all < FINAL_HIT + 0.3] = 1
music *= fade[:, None]
music[:int(0.002 * SR)] *= np.linspace(0, 1, int(0.002 * SR))[:, None]
# intro lift: sparse hook scene sits ~4 dB higher so it still grabs attention
INTRO_GAIN_DB = 4.5
ig = np.ones(N); a, b_ = int(1.0 * SR), int(GROOVE_FROM * SR)
ig[a:b_] = db(INTRO_GAIN_DB)
ig = np.convolve(ig, np.ones(int(0.25 * SR)) / int(0.25 * SR), 'same')
music *= ig[:, None]

# ---- gentle master bus compression (RMS, 2:1 above -16 dB) + soft clip
def master(x, thr=-16, ratio=2.0, makeup=1.0):
    x = x / (np.abs(x).max() + 1e-12) * db(-3)
    p = np.mean(x ** 2, 1)
    win = int(0.06 * SR)
    rms = np.sqrt(np.convolve(p, np.ones(win) / win, 'same') + 1e-12)
    lvl = 20 * np.log10(rms)
    gr = np.where(lvl > thr, (thr - lvl) * (1 - 1 / ratio), 0)
    gr = np.convolve(gr, np.ones(int(0.01 * SR)) / int(0.01 * SR), 'same')
    y = x * db(gr)[:, None] * makeup
    y = y / np.abs(y).max() * db(-2)
    y = np.tanh(1.4 * y) / np.tanh(1.4)  # soft saturation, gentle glue
    return y - y.mean(0)

music = master(music)
music *= db(-1) / np.abs(music).max()

# ============================ SFX =======================================
sfx = stereo(N)

def whoosh(peak_t, dur=0.42):
    n = int((dur + 0.18) * SR); t = tt(n)
    pk = dur / (dur + 0.18)
    u = np.linspace(0, 1, n)
    env = np.where(u < pk, (u / pk) ** 2.5, np.exp(-(u - pk) / 0.06))
    x = svf_sweep(noise(n), 400, 7000, 1.4, 1.2) * env
    pans = np.clip(-0.9 + 1.8 * u, -1, 1)
    a = (pans + 1) * np.pi / 4
    st = np.stack([x * np.cos(a), x * np.sin(a)], 1)
    place(sfx, st * 0.5, peak_t - pk * (dur + 0.18))

def pop(t0, k):
    n = int(0.09 * SR); t = tt(n)
    f0 = [900, 1100, 1000, 1250][k % 4]
    f = f0 * (0.6 + 0.6 * (1 - np.exp(-t / 0.012)))   # upward "bloop"
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.028)
    x += 0.4 * np.sin(2 * np.pi * np.cumsum(2 * f) / SR) * np.exp(-t / 0.012)
    x += hp(noise(n), 4000) * np.exp(-t / 0.0015) * 0.6
    x *= np.minimum(1, t / 0.0008)
    place(sfx, pan(x * 0.40, [-0.3, 0.3, -0.15, 0.15][k % 4]), t0)

def click_tick(level=1.0, fc=3000):
    n = int(0.02 * SR); t = tt(n)
    return bp(noise(n), fc, min(fc * 4, 20000)) * np.exp(-t / 0.002) * level

def mouse(t0):
    place(sfx, pan(click_tick(0.9, 2500), 0.1), t0)
    place(sfx, pan(click_tick(0.6, 3200), 0.1), t0 + 0.07)
    for i, (f, d) in enumerate([(988, 0.0), (1319, 0.07)]):  # coin
        n = int(0.45 * SR); t = tt(n)
        x = sum(np.sin(2 * np.pi * f * h * t) / h for h in (1, 3, 5)) * np.exp(-t / 0.12)
        x *= np.minimum(1, t / 0.001)
        if i == 0: x[int(0.07 * SR):] *= np.exp(-tt(n - int(0.07 * SR)) / 0.01)
        place(sfx, pan(x * 0.18, 0.2), t0 + 0.03 + d)

def shutter(t0):
    place(sfx, pan(click_tick(1.2, 1500), 0), t0)
    n = int(0.05 * SR); t = tt(n)
    place(sfx, pan(bp(noise(n), 1500, 8000) * np.exp(-t / 0.012) * 0.6, 0), t0 + 0.01)
    place(sfx, pan(click_tick(0.9, 1800), 0), t0 + 0.06)
    n = int(0.5 * SR); t = tt(n)  # flash charge whine
    f = 2500 + 4000 * t / t[-1]
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.15) * 0.04
    place(sfx, pan(x, 0.3), t0 + 0.02)

def chime(t0):
    out = stereo(int(1.6 * SR))
    for i, m in enumerate([74, 78, 81, 86]):
        n = int(1.2 * SR); t = tt(n); f = mtof(m + 12)
        mod = np.sin(2 * np.pi * f * 3.5 * t) * 1.2 * np.exp(-t / 0.15)
        x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t / 0.35) * np.minimum(1, t / 0.002)
        s = pan(x * 0.14, -0.4 + 0.27 * i)
        j = int(i * 0.07 * SR); out[j:j + n] += s[:len(out) - j]
    place(sfx, reverb(out, IR_HALL, 0.4), t0)

def typing(t0, t1):
    t = t0; r = np.random.default_rng(42)
    while t < t1:
        place(sfx, pan(click_tick(r.uniform(0.25, 0.5), r.uniform(2500, 4500)), r.uniform(-0.3, 0.3)), t)
        t += r.uniform(0.07, 0.15) + (0.3 if r.random() < 0.08 else 0)

for c in CUTS: whoosh(c)
for k, p in enumerate(POPS): pop(p, k)
for m in MOUSE: mouse(m)
for s in SHUTTER: shutter(s)
for s in SUCCESS: chime(s)
typing(*TYPING)
sfx = reverb(sfx, IR_ROOM, 0.15)
sfx -= sfx.mean(0)

# ============================ write & loudness ==========================
def wwrite(path, x):
    wavfile.write(path, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))

wwrite(f'{OUT}/music.wav', music)
wwrite(f'{OUT}/sfx.wav', sfx / max(1e-9, np.abs(sfx).max()) * db(-1))
MUS_G, SFX_G = db(-3), db(-4)
pre = music * MUS_G + sfx * SFX_G
pre *= db(-1.5) / np.abs(pre).max()
wwrite(f'{OUT}/premix.wav', pre)

def ff(args):
    return subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-y'] + args,
                          capture_output=True, text=True).stderr

src = f'{OUT}/premix.wav'; dst = f'{OUT}/mix_RS.wav'
LN = 'I=-14:TP=-1.5:LRA=7'
e = ff(['-i', src, '-af', f'loudnorm={LN}:print_format=json', '-f', 'null', '-'])
meas = json.loads(e[e.rfind('{'):e.rfind('}') + 1])
af = (f"loudnorm={LN}:measured_I={meas['input_i']}:measured_TP={meas['input_tp']}"
      f":measured_LRA={meas['input_lra']}:measured_thresh={meas['input_thresh']}"
      f":offset={meas['target_offset']}:linear=true,aresample=192000,"
      f"alimiter=limit={db(-1.6):.4f}:attack=1:release=60:level=false,aresample=48000")
ff(['-i', src, '-af', af, '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s24le', dst])

# ============================ verification ==============================
print(f'BPM {BPM:.2f}  bar {BAR:.3f}s  groove from bar {groove_bar_from}  build bar {build_bar}')
print('pass1 measured:', {k: meas[k] for k in ('input_i', 'input_tp', 'input_lra')})
e = ff(['-i', dst, '-af', 'ebur128=peak=true', '-f', 'null', '-'])
summ = e[e.rfind('Summary:'):]
I = float(re.search(r'I:\s+(-?[\d.]+) LUFS', summ).group(1))
LRA = float(re.search(r'LRA:\s+(-?[\d.]+) LU', summ).group(1))
TP = float(re.search(r'Peak:\s+(-?[\d.]+) dBFS', summ).group(1))
print(f'FINAL  I={I:.1f} LUFS  TP={TP:.1f} dBTP  LRA={LRA:.1f} LU')
st = {}
for m in re.finditer(r't:\s*([\d.]+)\s+TARGET.*?S:\s*(-?[\d.]+|-inf)', e):
    st[round(float(m.group(1)), 1)] = m.group(2)
mo = {}
for m in re.finditer(r't:\s*([\d.]+)\s+TARGET.*?M:\s*(-?[\d.]+)', e):
    mo[round(float(m.group(1)), 1)] = m.group(1 + 1)
print('momentary (M) 1-3 s (S needs 3 s of audio):', '  '.join(f'{t}s:{mo.get(t)}' for t in (1.0, 2.0, 3.0)))
print('short-term (S) every 2 s:', '  '.join(f'{t:.0f}s:{st.get(float(t), "?")}' for t in range(4, 63, 2)))

_, y = wavfile.read(dst); y = y.astype(np.float64) / 2 ** 31
print(f'samples clipped (|x|>=0.999): {int(np.sum(np.abs(y) >= 0.999))}   '
      f'DC offset L/R: {y[:,0].mean():.2e} / {y[:,1].mean():.2e}   len {len(y)/SR:.2f}s')

def onset_check(x, times, name, pre=(-0.12, -0.02), post=(-0.005, 0.04), band=2500):
    h = hp(x.mean(1), band, 4) ** 2
    ok = 0; rows = []
    for t in times:
        a = h[int((t + pre[0]) * SR):int((t + pre[1]) * SR)].mean() + 1e-12
        b = h[int((t + post[0]) * SR):int((t + post[1]) * SR)].mean()
        r = 10 * np.log10(b / a); ok += r > 3; rows.append(f'{t}:{r:+.0f}')
        print_rows = rows
    print(f'{name}: {ok}/{len(times)} onsets > +3 dB  [' + ' '.join(rows) + ']')

_, s_ = wavfile.read(f'{OUT}/sfx.wav'); s_ = s_ / 32768.0
pts = sorted(POPS + MOUSE + SHUTTER + SUCCESS)
onset_check(s_, pts, 'SFX stem point events')
def local_snr(times, win=0.04, lo=600, hi=9000):
    m = bp(music.mean(1) * MUS_G, lo, hi) ** 2; x = bp(sfx.mean(1) * SFX_G, lo, hi) ** 2
    rows, ok = [], 0
    for t in times:
        i, j = int(t * SR), int((t + win) * SR)
        r = 10 * np.log10(x[i:j].mean() / (m[i:j].mean() + 1e-12)); ok += r > 0; rows.append(f'{t}:{r:+.0f}')
    print(f'mix: SFX-over-music in 40 ms after event (0.6-9 kHz): {ok}/{len(times)} > 0 dB  [' + ' '.join(rows) + ']')
local_snr(pts)
onset_check(s_, CUTS, 'SFX stem whooshes', pre=(-0.5, -0.3), post=(-0.1, 0.01), band=400)
tk = s_[int(TYPING[0] * SR):int(TYPING[1] * SR)].mean(1)
print(f'typing window RMS {20*np.log10(np.sqrt(np.mean(tk**2))+1e-12):.1f} dBFS (stem)')
