// node sheet.js out.jpg "t1,t2,..." [W=540] [cols=5]  -> contact sheet of frames (labels with time)
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); }
const { execFileSync } = require('child_process');
const fs = require('fs'); const path = require('path'); const os = require('os');
(async () => {
  const [out, times, Wa = '540', colsA = '5'] = process.argv.slice(2);
  const W = +Wa, H = Math.round(W * 16 / 9);
  const ts = times.split(',').map(Number);
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const p = await b.newPage({ viewport: { width: W, height: H } });
  p.on('pageerror', e => console.log('[err]', e.message)); p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') console.log('[page]', m.text()); });
  await p.goto(`http://localhost:8765/index.html?w=${W}&h=${H}`);
  await p.waitForFunction(() => window.ready, null, { timeout: 120000 }); await p.evaluate(() => window.ready);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sheet'));
  const files = [];
  for (const [i, t] of ts.entries()) {
    const t0 = Date.now();
    await p.evaluate((t) => window.render(t), t);
    const f = path.join(dir, `f${String(i).padStart(3, '0')}.jpg`);
    await p.screenshot({ path: f, type: 'jpeg', quality: 85 });
    files.push(f); console.log('t', t, Date.now() - t0, 'ms');
  }
  await b.close();
  const cols = +colsA;
  const args = [];
  files.forEach(f => args.push('-i', f));
  const rows = Math.ceil(files.length / cols);
  const layout = files.map((_, i) => `${(i % cols) * W}_${Math.floor(i / cols) * H}`).join('|');
  const lab = files.map((_, i) => `[${i}:v]drawtext=text='${ts[i]}':x=10:y=10:fontsize=28:fontcolor=yellow:box=1:boxcolor=black@0.6[v${i}]`).join(';');
  const inputs = files.map((_, i) => `[v${i}]`).join('');
  let fc;
  if (files.length === 1) fc = `${lab.replace(`[v0]`, '[o]')}`;
  else fc = `${lab};${inputs}xstack=inputs=${files.length}:layout=${layout}:fill=black[o]`;
  try { execFileSync('ffmpeg', ['-y', '-loglevel', 'error', ...args, '-filter_complex', fc, '-map', '[o]', '-q:v', '3', out]); }
  catch (e) { console.log('ffmpeg err (drawtext?)', e.message.slice(0, 300)); }
  console.log('saved', out);
})();
