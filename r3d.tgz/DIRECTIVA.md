# DIRECTIVA v4 — "Estudio de Noticias" 3D explainer (aprobada por el panel)

Objetivo: calidad de película animada (referencia: reel Supermercados Colonial). Todo por código (three.js 0.160, sin GPU, sin IA).
Se mantiene: timeline de 62 s, tiempos de escena, audio (música + voz Gideon 0.35 s y 16.3 s), calle, chaleco PRENSA, micrófono con logo, tarjetas, estudio azul, logo real PROAUDIH.
Debe funcionar en vertical (1080×1920, por defecto) y TV (`?w=1920&h=1080`, zona segura x 96–1824, y 54–1026).

## Decisiones de dirección (obligatorias)
1. Manos: casi nunca en primer plano. NUNCA un dedo índice 3D entrando a la pantalla del celular en los primeros planos (6–26 s). Los toques en pantalla se muestran con la mano-cursor dorada (la misma de la moneda) + anillo cian + la tecla/botón que se ilumina. Del personaje, en esos planos, solo se ve la mano que sostiene el celular (palma detrás, pulgar quieto en el borde) o nada.
2. Mano de caricatura estilo Pixar: 4 dedos, UNA malla suave (SkinnedMesh), dedos cortos y gruesos, puntas redondeadas, uñas pintadas en la textura (no objetos aparte), pulgar grueso y bajo. Solo 4 posturas: puño relajado, pulgar arriba, agarre de objeto, mano abierta suave (sin dedos rectos en abanico).
3. Agarres simples: celular con la palma detrás y solo el pulgar a la vista; laptop desde abajo con las manos debajo; micrófono dentro del puño.
4. Pantalla del celular protagonista en 12–26 s: 60–80 % de la altura del cuadro, legible en TV.
5. Animación: curvas por canal (easeOutBack s=1.4 entradas 0.35–0.5 s; easeInCubic salidas 0.2–0.25 s; cambios de pose easeInOutQuad 0.4–0.7 s), anticipación 12–15 % 0.12 s antes de cada gesto, rebote 8 %, asentamiento con resorte amortiguado (ζ≈0.45, ω≈18) 0.4 s; acción superpuesta (cadera→torso→cabeza→brazos→manos, 2–4 cuadros de retraso); arcos en las muñecas; vida con ruido de 2–3 frecuencias (no senos puros); cambio de peso cada 3–4 s; parpadeo asimétrico (2 cuadros cerrar, 1 cerrado, 4 abrir) cada 2.5–5 s y al girar la cabeza; ojos 3 cuadros antes que la cabeza y mirando a lo que aparece; saltos con aplastar/estirar. Corregir ojos desviados (8, 38, 51–58 s).
6. Cámara: trayectoria Catmull-Rom con velocidad que pasa por las llaves (sin frenar en cada llave), acercamientos easeOutExpo 0.6 s al golpe, leve vaivén de cámara en mano 0.3°, paralaje con primer plano.
7. Sin cuadros vacíos: 7 s (velo blanco), 31 s (cuña azul), 37, 44, 50 s (personaje solo), 11 s y 27 s (plano de espalda muy cerca → plano medio). Cada transición = barrido navy #0B2238 con filo de luz ámbar #FDAE03 que se cierra SOBRE la escena siguiente; los letreros de la escena nueva entran antes (p. ej. "ELIGE EL ESTILO" desde 31 s).
8. Prueba de venta: 22–24.5 s la noticia terminada a casi media pantalla, quieta ~2.5 s, resto atenuado. 45–49 s titular grande "TU NOTICIA YA TRAE PATROCINADOR" y la cinta "ESPACIO PATROCINADO" grande y entera. Quitar "Plan Pro" de 38 s.
9. Cierre: logo PROAUDIH entra en 58.5 s, quieto ≥ 2.5 s, golpe en 60.5 s solo como pulso; proaudih.com + "Escríbenos y pide tu demostración" más grande + WhatsApp "+504 9741-7560 · +504 9350-3349". Laptop de frente y recta con la app.
10. Gráfica: títulos de sticker Archivo Expanded 800 ≥ 64 px, bisel 6 px degradado 2 tonos, sombra dura 8 px #06121F + suave 24 px; viñetas Figtree 700 40 px blanco, sombra 0 4 12 rgba(6,18,31,.6), máx. 2 líneas por pantalla, entran una por una al golpe; pasos 1–4 en cian, naranja #F6901C solo para la llamada a la acción; nada choca con el logo de arriba (títulos en y ≥ 200 en TV; en vertical bajo el logo).
11. Look: piel #B8693E roughness 0.55 sheen 0.3 sheenColor #FF9A6B, sin emissive constante, light-wrap rojizo; tela roughness 0.85 sheen 0.6 + textura de tejido; luz de recorte #8FD8FF 2.5 desde atrás-izquierda; hemisférica #BFD9FF/#3A2A1E 0.6; AgX tone mapping (o ACES exp 1.05) + viñeta 0.25; sombra de contacto bajo los pies; sombras con normalBias ~0.003 y foco de sombra ajustado en primeros planos; árboles 3 tonos (#2F7A3A, #4FA24A, #8CCB5E) con tronco y niebla #9EC3E8; estudio con bokeh cian 20 % y piso reflectivo (roughness 0.25). Cabeza escala 0.9, torso +8 %, nariz 0.8, párpados con grosor.

12. DECISIÓN DEL DUEÑO (27-oct 21:38): SIN PRECIOS. La escena de planes (50–56 s) ya no muestra L 990 / L 1,990 / L 3,490 ni "Instalación única…/Pago anual…". En su lugar: título "PIDE TU DEMOSTRACIÓN" + 3 stickers de beneficio (p. ej. "CON TU LOGO Y TUS COLORES", "PARA TV Y RADIO", "SIN COMPLICACIONES") — nada de cifras. En el cierre, "EN 48 HORAS TIENES TU SISTEMA" pasa a "EN MENOS DE 24 HORAS TIENES TU SISTEMA DISEÑADO" (o "…TU SISTEMA LISTO CON TU MARCA" si no cabe; manteniendo "menos de 24 horas"). La llamada a la acción principal: "PIDE TU DEMOSTRACIÓN".

## Reparto de archivos (NO tocar archivos de otro paquete)
- WP1 (personaje): js/character.js
- WP2 (animación, cámara, puesta en escena, cursor de toques): js/main.js, js/util.js, js/typing.js
- WP3 (luz, set, acabado, render): js/set.js, render.js, index.html, js/post.js (nuevo)
- WP4 (gráfica 2D y pantallas): js/overlay.js, js/screens.js
Interfaces: no cambiar firmas exportadas que otro paquete usa; si hace falta algo nuevo, agregarlo sin romper lo existente y anotarlo al final de este archivo en "Notas de integración". WP2 expone `window.__gl = {renderer, scene, camera, rig}` para WP3.

## Notas de integración

### WP4 (gráfica 2D y pantallas) — APIs nuevas
Todas las coordenadas son de diseño (después de `g.setTransform(SC,…)`): vertical 1080×1920, TV 1920×1080.
- `O.drawTap(g, x, y, p, opt = {})` (js/overlay.js) — toque en pantalla: mano-cursor dorada (arte de la moneda) con la PUNTA del dedo en (x, y) + anillo cian que se expande. `p` = progreso 0..1 del toque (duración sugerida 0.45 s; llamar con `p = (t - tToque + 0.12) / 0.45` para que el contacto caiga en p≈0.27): 0–0.27 el cursor baja con anticipación, 0.27 contacto (aplasta 12 %), 0.27–1 anillo cian + destellos, 0.8–1 el cursor se desvanece. `opt`: `{ scale = 1, color = '#3DE0FF', cursor = true, alpha = 1 }`. `p` fuera de [0,1] no dibuja nada.
- `O.tapAt(g, t, tTap, x, y, opt)` — atajo: `drawTap(g, x, y, (t - tTap + 0.12) / 0.45, opt)`.
- `O.timeline(g, t, env)` — dibuja TODA la gráfica 2D de las escenas (letreros, pasos 1–4, viñetas, barridos navy/ámbar, atenuado de la prueba 22–24.5 s, publicidad, planes, cierre, logo de arriba). `env = { TV, DW, DH, logo, logoBig, proofRect }` (`logo` = A.logoSmall||A.logo; `proofRect` opcional = rectángulo en px de la noticia terminada {x,y,w,h} para recortar el atenuado; si falta se usa uno por defecto centrado). **main.js: en `drawOverlay(t)` dejar `setTransform`, `clearRect`, `vignette`, los anillos de dedos/toques y `reactions`, y reemplazar todo lo demás (stickers, banners, list, note, flash blanco 6.83–7.25, `wipe(30.72…)`, cierre y `topMark`) por una sola llamada `O.timeline(g, t, {TV, DW, DH, logo: A.logoSmall || A.logo, logoBig: A.logo})`.** Sin esa llamada los arreglos de gráfica (choques con el logo, cuadros vacíos, titulares de 45–49 s, cierre) no se ven.
- `O.transitionWipe(g, t, t0, t1, env)` — barrido navy #0B2238 con filo ámbar #FDAE03 (cubre de t0 a la mitad y se abre sobre la escena siguiente). Ya va dentro de `timeline` en 6.55, 30.6, 36.75, 43.75, 49.75 s.
- `O.dimAround(g, rect, a, env)` — atenúa todo menos `rect` (alpha a 0..1).

### WP4 — pantallas del celular (js/screens.js)
- `S.KB` = `{ top: 0.70, rowH: 0.072, rows: [...] }` y `S.keyRect(row, col)` → rect normalizado {x,y,w,h} de una tecla (mismo trazado que el teclado actual).
- `S.drawKeyboard(x, w, h, k, key, p = 1)` — teclado (reemplaza el de main.js); `key = {row, col}` se ilumina en cian con globo de tecla ampliada encima; `p` 0..1 intensidad del pulso.
- `S.drawPress(x, w, h, which, k)` — ilumina el botón `HOTSPOT[which]` ('preparar', 'subir', 'shutter') con brillo ámbar/blanco y borde cian, `k` 0..1. Reemplaza el `if (desc.press)` de `drawScreen`.
- `HOTSPOT.shutter` agregado (= SHUTTER de main.js si coincide; ajustar allí).

### WP1 (personaje, js/character.js) — cambios y APIs
- Manos: cada mano es UNA `SkinnedMesh` suave (campo de distancia palma+4 dedos+pulgar con smooth-min → surface nets, ~21k triángulos), huesos `THREE.Bone` con los MISMOS nombres de antes (`H.fingers[k].base/segs/tip`, `H.thumb.base/t1/t2/tip`, `H.hand`), uñas y oscurecido entre dedos pintados en color de vértice. `H.skin` = la malla. Antebrazo = `arms[s].fore` (SkinnedMesh) + hueso `arms[s].twist` (lleva la mitad del giro de la muñeca; sin costura).
- Posturas: solo 4 formas reales; los nombres viejos siguen existiendo y apuntan a ellas: `open/relax/present/support/point` = mano abierta suave (curvas 0.25/0.35/0.45/0.55), `fist/tap` = puño relajado, `thumbsUp`, `grip` (celular, resuelto), `mic` (envuelve el mango), `side/tray` = bandeja (laptop). `point` YA NO apunta con el índice (era la "pistola").
- `HANDS[*].t` ahora tiene 5 valores `[yaw, pitch, b1, b2, roll]` (roll opcional = 0). Si WP2 crea manos propias, usar 5 valores para que la interpolación no dé NaN.
- Celular: palma detrás, dedos a lo largo del dorso (ocultos por el celular), solo el pulgar en el borde derecho (fuera del cristal). Sonda 0–31 s cada 0.2 s: penetración máxima 0 mm.
- Laptop: manos por debajo de la base (palmas arriba), constante exportada `LAP_GRIP`. Micrófono dentro del puño: `MIC_POS`.
- `applyPose` pone `root.scale = 1` al empezar; main.js aplica el aplastar/estirar DESPUÉS (como ya hace), así ningún contacto se rompe en los saltos.
- **`rig.lookAt(worldPoint, w = 1)`**: apunta las dos pupilas a un punto del mundo (convergen, nunca bizcas ni divergentes). Llamar DESPUÉS de `rig.setPose(p)` en cada cuadro; sobrescribe `eyeX/eyeY` solo en ese cuadro (`w` mezcla con la mirada de la pose). Devuelve `false` si el punto queda fuera del rango del ojo (se recorta). Sin `lookAt`, `eyeX/eyeY` ahora apuntan a un punto a 1.2 m (ojos convergentes).
- Look: piel #B8693E rough 0.55 sheen 0.3 sheenColor #FF9A6B sin emissive + light-wrap rojizo (onBeforeCompile, `customProgramCacheKey 'skinwrap1'`); telas rough 0.85 sheen 0.6 + bump de tejido. Cabeza ×0.9, torso ×1.08 (hombros/cuello/cabeza suben ~3.5 cm: revisar encuadres de cara), nariz ×0.8, párpados con borde grueso.

### WP2 — texto tecleado (js/typing.js) para la escritura letra por letra (WP4, screens.js)
- `TYPED_TEXT` = 'Esta mañana cayó un árbol en la calle principal del barrio El Centro, frente a la farmacia.' (mismo texto del cuadro de app_3).
- `TYPING_TAPS[i]` (30 clics de la música) → `TAP_CHARS[i]` = cuántos caracteres de `TYPED_TEXT` se ven justo después del clic i (≈3 por clic, el último = texto completo).
- `typedCount(t)` / `typedTextAt(t)` → texto visible en el segundo t (vacío antes de 12.5 s). `tapChar(i)` = carácter del clic i; `keyOfChar(ch)` → `{row, col}` (tildes → letra base, Ñ en la fila 1), espacio → `{row: 3, col: -1, space: true}`, puntuación → null.
- main.js: la tecla iluminada y el cursor dorado siguen la última letra de cada bloque (`keyPos(i)`); `desc.key = {row, col, space}` llega a `S.drawKeyboard`. Para el espacio (`space: true`) WP4 puede iluminar la barra espaciadora (hoy no se ilumina).
