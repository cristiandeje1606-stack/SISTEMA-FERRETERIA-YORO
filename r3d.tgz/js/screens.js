// Asset loading + tasteful placeholders (used only when the real files are missing)
import { loadImage, BRAND, clamp, easeInOut, easeOut, prog } from './util.js';

export const A = { app: [], posts: {}, newsvid: [], photo: null, placeholder: {} };

// Normalized position (0..1 of the phone screen) of the buttons the cursor taps.
// Adjust these once the real screenshots are in place.
export const HOTSPOT = {
  preparar: { x: 0.305, y: 0.605, w: 0.355, h: 0.085 },  // "Preparar noticia" button on app_4
  subir: { x: 0.5, y: 0.157, w: 0.82, h: 0.06 },          // red "DESCARGAR VIDEO NOTICIA" button on app_6
};

const HEADLINE = ['ÁRBOL CAÍDO', 'BLOQUEA LA CALLE', 'PRINCIPAL'];
const REPORT_TEXT = 'Cayó un árbol grande en la calle principal, frente a la farmacia. No hay paso de carros. Ya avisaron a los bomberos y a la alcaldía para que lo quiten.';

function cnv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function cover(g, im, x, y, w, h, zoom = 1, ox = 0.5, oy = 0.5) {
  const s = Math.max(w / im.width, h / im.height) * zoom;
  const dw = im.width * s, dh = im.height * s;
  g.drawImage(im, x + (w - dw) * ox, y + (h - dh) * oy, dw, dh);
}
function wrap(g, text, maxW) {
  const words = text.split(' '); const lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (g.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
}
function lg(g, x0, y0, x1, y1, stops) { const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach((c, i) => gr.addColorStop(i / (stops.length - 1), c)); return gr; }

export async function loadAssets() {
  A.photo = await loadImage('assets/photo_scene.jpg');
  for (let i = 1; i <= 6; i++) A.app[i] = await loadImage(`assets/app_${i}.png`);
  for (const k of ['impacto', 'cristal', 'clasico']) A.posts[k] = await loadImage(`assets/post_${k}.png`);
  // news video frames: probe sequentially
  for (let i = 1; i < 2000; i++) {
    const im = await loadImage(`assets/newsvid/f${String(i).padStart(4, '0')}.jpg`);
    if (!im) break; A.newsvid.push(im);
  }
  A.missing = [];
  for (let i = 1; i <= 6; i++) if (!A.app[i]) { A.app[i] = placeholderApp(i); A.missing.push(`app_${i}.png`); }
  for (const k of ['impacto', 'cristal', 'clasico']) if (!A.posts[k]) { A.posts[k] = placeholderPost(k); A.missing.push(`post_${k}.png`); }
  if (!A.newsvid.length) A.missing.push('newsvid/');
  return A;
}

// ---------- placeholders
function placeholderApp(n) {
  const W = 780, H = 1688; const c = cnv(W, H); const g = c.getContext('2d');
  g.fillStyle = lg(g, 0, 0, 0, H, ['#0B2238', '#06121F']); g.fillRect(0, 0, W, H);
  g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '600 26px UneText'; g.textBaseline = 'middle';
  g.fillText('9:41', 46, 50);
  // header
  g.font = '44px UneDisplay'; g.fillStyle = '#ffffff'; g.fillText('ESTUDIO DE', 46, 140);
  g.fillStyle = BRAND.ambar; g.fillText('NOTICIAS', 46, 192);
  g.fillStyle = lg(g, 0, 236, W, 236, [BRAND.cian, BRAND.azul, BRAND.naranja]); g.fillRect(46, 232, W - 92, 4);
  if (n === 6) {
    g.font = '30px UneCond'; g.fillStyle = BRAND.cian; g.fillText('TU NOTICIA ESTÁ LISTA', 46, 290);
    const p = A.posts.impacto && !A.posts.impacto.isPlaceholder ? A.posts.impacto : placeholderPost('impacto');
    const pw = W - 92, ph = pw * 1350 / 1080;
    g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 30; g.drawImage(p, 46, 330, pw, ph); g.restore();
    g.fillStyle = lg(g, 0, 0, W, 0, [BRAND.ambar, BRAND.naranja, BRAND.brasa]);
    g.beginPath(); g.roundRect(46, H * HOTSPOT.subir.y - 56, W - 92, 112, 56); g.fill();
    g.fillStyle = '#ffffff'; g.font = '42px UneDisplay'; g.textAlign = 'center'; g.fillText('SUBIR', W / 2, H * HOTSPOT.subir.y + 2); g.textAlign = 'left';
    tag(g, n, W, H); return c;
  }
  // photo box
  const by = 270, bh = 400;
  g.fillStyle = 'rgba(255,255,255,0.05)'; g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.fill();
  if (n >= 2 && A.photo) {
    g.save(); g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.clip(); cover(g, A.photo, 46, by, W - 92, bh); g.restore();
    g.fillStyle = BRAND.cian; g.beginPath(); g.arc(W - 90, by + 44, 24, 0, 7); g.fill();
    g.strokeStyle = BRAND.noche; g.lineWidth = 6; g.beginPath(); g.moveTo(W - 102, by + 44); g.lineTo(W - 92, by + 54); g.lineTo(W - 76, by + 34); g.stroke();
  } else {
    g.setLineDash([16, 12]); g.strokeStyle = 'rgba(8,225,255,0.6)'; g.lineWidth = 3; g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#ffffff'; g.font = '40px UneTextB, UneText'; g.textAlign = 'center'; g.fillText('Elegir foto o video', W / 2, by + bh / 2 - 10);
    g.fillStyle = 'rgba(255,255,255,0.6)'; g.font = '28px UneText'; g.fillText('desde tu teléfono', W / 2, by + bh / 2 + 40); g.textAlign = 'left';
  }
  // text area
  const ty = 710;
  g.fillStyle = BRAND.ambar; g.font = '30px UneCond'; g.fillText('¿QUÉ PASÓ? ESCRÍBELO TAL COMO TE LLEGÓ', 46, ty);
  g.fillStyle = 'rgba(255,255,255,0.07)'; g.beginPath(); g.roundRect(46, ty + 30, W - 92, 380, 22); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.15)'; g.lineWidth = 2; g.stroke();
  g.font = '34px UneText';
  let txt = n <= 2 ? '' : n === 3 ? REPORT_TEXT.slice(0, 74) : REPORT_TEXT;
  const lines = wrap(g, txt, W - 140);
  g.fillStyle = '#ffffff';
  lines.forEach((l, i) => g.fillText(l, 70, ty + 84 + i * 48));
  if (n === 3 || n === 2) { const lw = lines.length ? g.measureText(lines[lines.length - 1]).width : 0; g.fillStyle = BRAND.cian; g.fillRect(72 + lw, ty + 64 + Math.max(0, lines.length - 1) * 48, 4, 40); }
  if (!txt) { g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillText('Ej.: Cayó un árbol en la calle...', 70, ty + 84); }
  // button
  const bY = H * HOTSPOT.preparar.y;
  g.fillStyle = n >= 4 ? lg(g, 0, 0, W, 0, [BRAND.ambar, BRAND.naranja, BRAND.brasa]) : 'rgba(255,255,255,0.12)';
  g.beginPath(); g.roundRect(46, bY - 52, W - 92, 104, 52); g.fill();
  g.fillStyle = n >= 4 ? '#ffffff' : 'rgba(255,255,255,0.4)'; g.font = '38px UneDisplay'; g.textAlign = 'center'; g.fillText('PREPARAR NOTICIA', W / 2, bY + 2); g.textAlign = 'left';
  if (n === 5) {
    const y0 = bY + 90;
    g.fillStyle = BRAND.cian; g.font = '28px UneCond'; g.fillText('TITULAR', 46, y0);
    g.fillStyle = '#ffffff'; g.font = '40px UneDisplay'; g.fillText('ÁRBOL CAÍDO BLOQUEA', 46, y0 + 50); g.fillText('LA CALLE PRINCIPAL', 46, y0 + 100);
    g.fillStyle = BRAND.cian; g.font = '28px UneCond'; g.fillText('TEXTO PARA PUBLICAR', 46, y0 + 160);
    g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '28px UneText';
    wrap(g, 'Un árbol de gran tamaño cayó esta mañana sobre la calle principal y bloquea el paso de vehículos. Bomberos y personal de la alcaldía ya trabajan en el lugar.', W - 92).slice(0, 4).forEach((l, i) => g.fillText(l, 46, y0 + 205 + i * 40));
  }
  tag(g, n, W, H);
  return c;
}
function tag(g, n, W, H) {
  g.fillStyle = 'rgba(255,255,255,0.28)'; g.font = '22px UneText'; g.textAlign = 'center';
  g.fillText(`vista provisional · app_${n}.png`, W / 2, H - 30); g.textAlign = 'left';
}

function placeholderPost(kind) {
  const W = 1080, H = 1350; const c = cnv(W, H); c.isPlaceholder = true; const g = c.getContext('2d');
  g.fillStyle = BRAND.noche; g.fillRect(0, 0, W, H);
  if (A.photo) cover(g, A.photo, 0, 0, W, kind === 'clasico' ? 860 : H, 1.05);
  const date = 'MARTES 27 DE OCTUBRE';
  if (kind === 'clasico') {
    g.fillStyle = BRAND.marino; g.fillRect(0, 860, W, H - 860);
    g.fillStyle = BRAND.naranja; g.fillRect(0, 852, W, 10);
    g.fillStyle = BRAND.rojo; g.fillRect(60, 900, 240, 56);
    g.fillStyle = '#fff'; g.font = '34px UneCond'; g.textBaseline = 'middle'; g.fillText('NOTICIAS', 92, 929);
    g.font = '76px UneDisplay'; HEADLINE.forEach((l, i) => g.fillText(l, 60, 1020 + i * 84));
  } else if (kind === 'cristal') {
    g.fillStyle = 'rgba(6,18,31,0.25)'; g.fillRect(0, 0, W, H);
    g.save(); g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 40;
    g.fillStyle = 'rgba(20,50,90,0.55)'; g.beginPath(); g.roundRect(60, 820, W - 120, 440, 40); g.fill(); g.restore();
    g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 3; g.beginPath(); g.roundRect(60, 820, W - 120, 440, 40); g.stroke();
    g.fillStyle = BRAND.cian; g.font = '34px UneCond'; g.textBaseline = 'middle'; g.fillText('● NOTICIAS', 110, 880);
    g.fillStyle = '#fff'; g.font = '72px UneDisplay'; HEADLINE.forEach((l, i) => g.fillText(l, 110, 965 + i * 82));
  } else {
    const gr = lg(g, 0, 600, 0, H, ['rgba(6,18,31,0)', 'rgba(6,18,31,0.95)']); g.fillStyle = gr; g.fillRect(0, 600, W, H - 600);
    g.save(); g.translate(0, 820); g.rotate(-0.06); g.fillStyle = BRAND.rojo; g.fillRect(-20, 0, 340, 64);
    g.fillStyle = '#fff'; g.font = '36px UneCond'; g.textBaseline = 'middle'; g.fillText('● NOTICIAS', 40, 33); g.restore();
    g.fillStyle = '#fff'; g.font = '86px UneDisplay'; g.textBaseline = 'middle';
    g.fillText(HEADLINE[0], 60, 960); g.fillStyle = '#ff5a74'; g.fillText(HEADLINE[1], 60, 1055); g.fillStyle = '#fff'; g.fillText(HEADLINE[2], 60, 1150);
  }
  g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '28px UneCond'; g.textBaseline = 'middle'; g.fillText(date, 60, 60);
  g.font = '44px UneLogo'; g.fillStyle = BRAND.ambar; g.textAlign = 'right'; g.fillText('PROAUDIH', W - 60, 64); g.textAlign = 'left';
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.font = '22px UneText'; g.fillText(`vista provisional · post_${kind}.png`, 60, H - 34);
  return c;
}

// news video frame (real frames if present; placeholder animation otherwise)
export function newsFrame(g, tt, W, H, win = 6.4) {
  if (A.newsvid.length) {
    const N = A.newsvid.length, L = N / 15;
    const fr = (x) => A.newsvid[Math.max(0, Math.min(N - 1, Math.floor(x * 15)))];
    // whole clip (intro -> photos -> outro) fitted into the slot: ~1.8x speed
    const speed = Math.max(1, L / win);
    g.drawImage(fr(Math.min(tt * speed, L - 0.01)), 0, 0, W, H);
    return;
  }
  const L = 7.0; const t = ((tt % L) + L) % L;
  g.fillStyle = BRAND.noche; g.fillRect(0, 0, W, H);
  if (A.photo) {
    const z = 1.15 + t * 0.03;
    cover(g, A.photo, 0, 0, W, H, z, 0.35 + t * 0.03, 0.55);
  }
  // lower third
  const lt = easeOut(prog(t, 1.4, 1.9)) * (1 - prog(t, 5.6, 5.9));
  if (lt > 0) {
    g.save(); g.globalAlpha = lt;
    g.fillStyle = BRAND.rojo; g.fillRect(-10 + (1 - lt) * -300, H - 330, 230, 48);
    g.fillStyle = '#fff'; g.font = '30px UneCond'; g.textBaseline = 'middle'; g.fillText('ÚLTIMA HORA', 24 + (1 - lt) * -300, H - 305);
    g.fillStyle = 'rgba(6,18,31,0.88)'; g.fillRect(0, H - 280, W * lt, 170);
    g.fillStyle = '#fff'; g.font = '40px UneDisplay'; g.fillText('ÁRBOL CAÍDO', 24, H - 240); g.fillText('BLOQUEA LA CALLE', 24, H - 190);
    g.fillStyle = BRAND.ambar; g.fillRect(0, H - 112, W * lt, 6);
    g.restore();
  }
  // intro curtain
  const cu = t < 1.3 ? 1 - easeInOut(prog(t, 0.6, 1.3)) : t > 5.9 ? easeInOut(prog(t, 5.9, 6.5)) : 0;
  if (cu > 0) {
    const cols = [BRAND.rojo, BRAND.marino, BRAND.azul, BRAND.rojo, BRAND.marino];
    cols.forEach((c, i) => { g.fillStyle = c; const h = H / cols.length; g.fillRect((i % 2 ? 1 : -1) * (1 - cu) * W, i * h, W, h + 1); });
    if (cu > 0.6) { g.globalAlpha = (cu - 0.6) / 0.4; g.fillStyle = '#fff'; g.font = '64px UneDisplay'; g.textAlign = 'center'; g.fillText('NOTICIAS', W / 2, H / 2); g.textAlign = 'left'; g.globalAlpha = 1; }
  }
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.font = '18px UneText'; g.fillText('vista provisional · newsvid', 16, H - 20);
}
