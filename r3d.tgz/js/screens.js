// Asset loading + tasteful placeholders (used only when the real files are missing)
import { loadImage, BRAND, clamp, easeInOut, easeOut, prog } from './util.js';
import { TYPED_TEXT } from './typing.js';

export const A = { app: [], posts: {}, newsvid: [], photo: null, placeholder: {} };

// Normalized position (0..1 of the phone screen) of the buttons the cursor taps.
// Adjust these once the real screenshots are in place.
export const HOTSPOT = {
  preparar: { x: 0.305, y: 0.605, w: 0.355, h: 0.085 },  // "Preparar noticia" button on app_4
  subir: { x: 0.5, y: 0.157, w: 0.82, h: 0.06 },          // red "DESCARGAR VIDEO NOTICIA" button on app_6
  shutter: { x: 0.8, y: 0.56, w: 0.2, h: 0.093, round: true }, // camera shutter (main.js SHUTTER)
};

const HEADLINE = ['ÁRBOL CAÍDO', 'BLOQUEA LA CALLE', 'PRINCIPAL'];
const REPORT_TEXT = 'Cayó un árbol grande en la calle principal, frente a la farmacia. No hay paso de carros. Ya avisaron a los bomberos y a la alcaldía para que lo quiten.';

function cnv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function cover(g, im, x, y, w, h, zoom = 1, ox = 0.5, oy = 0.5) {
  const s = Math.max(w / im.width, h / im.height) * zoom;
  const dw = im.width * s, dh = im.height * s;
  g.drawImage(im, x + (w - dw) * ox, y + (h - dh) * oy, dw, dh);
}
function wrap(g, text, maxW) {
  const words = text.split(' '); const lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (g.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
}
function lg(g, x0, y0, x1, y1, stops) { const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach((c, i) => gr.addColorStop(i / (stops.length - 1), c)); return gr; }

export async function loadAssets() {
  A.photo = await loadImage('assets/photo_scene.jpg');
  for (let i = 1; i <= 6; i++) A.app[i] = await loadImage(`assets/app_${i}.png`);
  for (const k of ['impacto', 'cristal', 'clasico']) A.posts[k] = await loadImage(`assets/post_${k}.png`);
  // news video frames: probe sequentially
  for (let i = 1; i < 2000; i++) {
    const im = await loadImage(`assets/newsvid/f${String(i).padStart(4, '0')}.jpg`);
    if (!im) break; A.newsvid.push(im);
  }
  A.missing = [];
  for (let i = 1; i <= 6; i++) if (!A.app[i]) { A.app[i] = placeholderApp(i); A.missing.push(`app_${i}.png`); }
  for (const k of ['impacto', 'cristal', 'clasico']) if (!A.posts[k]) { A.posts[k] = placeholderPost(k); A.missing.push(`post_${k}.png`); }
  if (!A.newsvid.length) A.missing.push('newsvid/');
  if (!A.missing.includes('app_6.png')) { try { await document.fonts.load('44px UneDisplay'); } catch (e) {} A.app[6] = withSubirButton(A.app[6]); }
  if (!A.missing.includes('app_5.png')) { try { await document.fonts.load('30px UneText'); } catch (e) {} A.app[5] = withTypedBox(A.app[5]); }
  return A;
}

// ---------- placeholders
function placeholderApp(n) {
  const W = 780, H = 1688; const c = cnv(W, H); const g = c.getContext('2d');
  g.fillStyle = lg(g, 0, 0, 0, H, ['#0B2238', '#06121F']); g.fillRect(0, 0, W, H);
  g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '600 26px UneText'; g.textBaseline = 'middle';
  g.fillText('9:41', 46, 50);
  // header
  g.font = '44px UneDisplay'; g.fillStyle = '#ffffff'; g.fillText('ESTUDIO DE', 46, 140);
  g.fillStyle = BRAND.ambar; g.fillText('NOTICIAS', 46, 192);
  g.fillStyle = lg(g, 0, 236, W, 236, [BRAND.cian, BRAND.azul, BRAND.naranja]); g.fillRect(46, 232, W - 92, 4);
  if (n === 6) {
    g.font = '30px UneCond'; g.fillStyle = BRAND.cian; g.fillText('TU NOTICIA ESTÁ LISTA', 46, 290);
    const p = A.posts.impacto && !A.posts.impacto.isPlaceholder ? A.posts.impacto : placeholderPost('impacto');
    const pw = W - 92, ph = pw * 1350 / 1080;
    g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 30; g.drawImage(p, 46, 330, pw, ph); g.restore();
    g.fillStyle = lg(g, 0, 0, W, 0, [BRAND.ambar, BRAND.naranja, BRAND.brasa]);
    g.beginPath(); g.roundRect(46, H * HOTSPOT.subir.y - 56, W - 92, 112, 56); g.fill();
    g.fillStyle = '#ffffff'; g.font = '42px UneDisplay'; g.textAlign = 'center'; g.fillText('SUBIR', W / 2, H * HOTSPOT.subir.y + 2); g.textAlign = 'left';
    tag(g, n, W, H); return c;
  }
  // photo box
  const by = 270, bh = 400;
  g.fillStyle = 'rgba(255,255,255,0.05)'; g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.fill();
  if (n >= 2 && A.photo) {
    g.save(); g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.clip(); cover(g, A.photo, 46, by, W - 92, bh); g.restore();
    g.fillStyle = BRAND.cian; g.beginPath(); g.arc(W - 90, by + 44, 24, 0, 7); g.fill();
    g.strokeStyle = BRAND.noche; g.lineWidth = 6; g.beginPath(); g.moveTo(W - 102, by + 44); g.lineTo(W - 92, by + 54); g.lineTo(W - 76, by + 34); g.stroke();
  } else {
    g.setLineDash([16, 12]); g.strokeStyle = 'rgba(8,225,255,0.6)'; g.lineWidth = 3; g.beginPath(); g.roundRect(46, by, W - 92, bh, 28); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#ffffff'; g.font = '40px UneTextB, UneText'; g.textAlign = 'center'; g.fillText('Elegir foto o video', W / 2, by + bh / 2 - 10);
    g.fillStyle = 'rgba(255,255,255,0.6)'; g.font = '28px UneText'; g.fillText('desde tu teléfono', W / 2, by + bh / 2 + 40); g.textAlign = 'left';
  }
  // text area
  const ty = 710;
  g.fillStyle = BRAND.ambar; g.font = '30px UneCond'; g.fillText('¿QUÉ PASÓ? ESCRÍBELO TAL COMO TE LLEGÓ', 46, ty);
  g.fillStyle = 'rgba(255,255,255,0.07)'; g.beginPath(); g.roundRect(46, ty + 30, W - 92, 380, 22); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.15)'; g.lineWidth = 2; g.stroke();
  g.font = '34px UneText';
  let txt = n <= 2 ? '' : n === 3 ? REPORT_TEXT.slice(0, 74) : REPORT_TEXT;
  const lines = wrap(g, txt, W - 140);
  g.fillStyle = '#ffffff';
  lines.forEach((l, i) => g.fillText(l, 70, ty + 84 + i * 48));
  if (n === 3 || n === 2) { const lw = lines.length ? g.measureText(lines[lines.length - 1]).width : 0; g.fillStyle = BRAND.cian; g.fillRect(72 + lw, ty + 64 + Math.max(0, lines.length - 1) * 48, 4, 40); }
  if (!txt) { g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillText('Ej.: Cayó un árbol en la calle...', 70, ty + 84); }
  // button
  const bY = H * HOTSPOT.preparar.y;
  g.fillStyle = n >= 4 ? lg(g, 0, 0, W, 0, [BRAND.ambar, BRAND.naranja, BRAND.brasa]) : 'rgba(255,255,255,0.12)';
  g.beginPath(); g.roundRect(46, bY - 52, W - 92, 104, 52); g.fill();
  g.fillStyle = n >= 4 ? '#ffffff' : 'rgba(255,255,255,0.4)'; g.font = '38px UneDisplay'; g.textAlign = 'center'; g.fillText('PREPARAR NOTICIA', W / 2, bY + 2); g.textAlign = 'left';
  if (n === 5) {
    const y0 = bY + 90;
    g.fillStyle = BRAND.cian; g.font = '28px UneCond'; g.fillText('TITULAR', 46, y0);
    g.fillStyle = '#ffffff'; g.font = '40px UneDisplay'; g.fillText('ÁRBOL CAÍDO BLOQUEA', 46, y0 + 50); g.fillText('LA CALLE PRINCIPAL', 46, y0 + 100);
    g.fillStyle = BRAND.cian; g.font = '28px UneCond'; g.fillText('TEXTO PARA PUBLICAR', 46, y0 + 160);
    g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '28px UneText';
    wrap(g, 'Un árbol de gran tamaño cayó esta mañana sobre la calle principal y bloquea el paso de vehículos. Bomberos y personal de la alcaldía ya trabajan en el lugar.', W - 92).slice(0, 4).forEach((l, i) => g.fillText(l, 46, y0 + 205 + i * 40));
  }
  tag(g, n, W, H);
  return c;
}
function tag(g, n, W, H) {
  g.fillStyle = 'rgba(255,255,255,0.28)'; g.font = '22px UneText'; g.textAlign = 'center';
  g.fillText(`vista provisional · app_${n}.png`, W / 2, H - 30); g.textAlign = 'left';
}

function placeholderPost(kind) {
  const W = 1080, H = 1350; const c = cnv(W, H); c.isPlaceholder = true; const g = c.getContext('2d');
  g.fillStyle = BRAND.noche; g.fillRect(0, 0, W, H);
  if (A.photo) cover(g, A.photo, 0, 0, W, kind === 'clasico' ? 860 : H, 1.05);
  const date = 'MARTES 27 DE OCTUBRE';
  if (kind === 'clasico') {
    g.fillStyle = BRAND.marino; g.fillRect(0, 860, W, H - 860);
    g.fillStyle = BRAND.naranja; g.fillRect(0, 852, W, 10);
    g.fillStyle = BRAND.rojo; g.fillRect(60, 900, 240, 56);
    g.fillStyle = '#fff'; g.font = '34px UneCond'; g.textBaseline = 'middle'; g.fillText('NOTICIAS', 92, 929);
    g.font = '76px UneDisplay'; HEADLINE.forEach((l, i) => g.fillText(l, 60, 1020 + i * 84));
  } else if (kind === 'cristal') {
    g.fillStyle = 'rgba(6,18,31,0.25)'; g.fillRect(0, 0, W, H);
    g.save(); g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 40;
    g.fillStyle = 'rgba(20,50,90,0.55)'; g.beginPath(); g.roundRect(60, 820, W - 120, 440, 40); g.fill(); g.restore();
    g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 3; g.beginPath(); g.roundRect(60, 820, W - 120, 440, 40); g.stroke();
    g.fillStyle = BRAND.cian; g.font = '34px UneCond'; g.textBaseline = 'middle'; g.fillText('● NOTICIAS', 110, 880);
    g.fillStyle = '#fff'; g.font = '72px UneDisplay'; HEADLINE.forEach((l, i) => g.fillText(l, 110, 965 + i * 82));
  } else {
    const gr = lg(g, 0, 600, 0, H, ['rgba(6,18,31,0)', 'rgba(6,18,31,0.95)']); g.fillStyle = gr; g.fillRect(0, 600, W, H - 600);
    g.save(); g.translate(0, 820); g.rotate(-0.06); g.fillStyle = BRAND.rojo; g.fillRect(-20, 0, 340, 64);
    g.fillStyle = '#fff'; g.font = '36px UneCond'; g.textBaseline = 'middle'; g.fillText('● NOTICIAS', 40, 33); g.restore();
    g.fillStyle = '#fff'; g.font = '86px UneDisplay'; g.textBaseline = 'middle';
    g.fillText(HEADLINE[0], 60, 960); g.fillStyle = '#ff5a74'; g.fillText(HEADLINE[1], 60, 1055); g.fillStyle = '#fff'; g.fillText(HEADLINE[2], 60, 1150);
  }
  g.fillStyle = 'rgba(255,255,255,0.85)'; g.font = '28px UneCond'; g.textBaseline = 'middle'; g.fillText(date, 60, 60);
  g.font = '44px UneLogo'; g.fillStyle = BRAND.ambar; g.textAlign = 'right'; g.fillText('PROAUDIH', W - 60, 64); g.textAlign = 'left';
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.font = '22px UneText'; g.fillText(`vista provisional · post_${kind}.png`, 60, H - 34);
  return c;
}

// news video frame (real frames if present; placeholder animation otherwise)
export function newsFrame(g, tt, W, H, win = 6.4) {
  if (A.newsvid.length) {
    const N = A.newsvid.length, L = N / 15;
    const fr = (x) => A.newsvid[Math.max(0, Math.min(N - 1, Math.floor(x * 15)))];
    // whole clip (intro -> photos -> outro) fitted into the slot: ~1.8x speed
    const speed = Math.max(1, L / win);
    g.drawImage(fr(Math.min(tt * speed, L - 0.01)), 0, 0, W, H);
    return;
  }
  const L = 7.0; const t = ((tt % L) + L) % L;
  g.fillStyle = BRAND.noche; g.fillRect(0, 0, W, H);
  if (A.photo) {
    const z = 1.15 + t * 0.03;
    cover(g, A.photo, 0, 0, W, H, z, 0.35 + t * 0.03, 0.55);
  }
  // lower third
  const lt = easeOut(prog(t, 1.4, 1.9)) * (1 - prog(t, 5.6, 5.9));
  if (lt > 0) {
    g.save(); g.globalAlpha = lt;
    g.fillStyle = BRAND.rojo; g.fillRect(-10 + (1 - lt) * -300, H - 330, 230, 48);
    g.fillStyle = '#fff'; g.font = '30px UneCond'; g.textBaseline = 'middle'; g.fillText('ÚLTIMA HORA', 24 + (1 - lt) * -300, H - 305);
    g.fillStyle = 'rgba(6,18,31,0.88)'; g.fillRect(0, H - 280, W * lt, 170);
    g.fillStyle = '#fff'; g.font = '40px UneDisplay'; g.fillText('ÁRBOL CAÍDO', 24, H - 240); g.fillText('BLOQUEA LA CALLE', 24, H - 190);
    g.fillStyle = BRAND.ambar; g.fillRect(0, H - 112, W * lt, 6);
    g.restore();
  }
  // intro curtain
  const cu = t < 1.3 ? 1 - easeInOut(prog(t, 0.6, 1.3)) : t > 5.9 ? easeInOut(prog(t, 5.9, 6.5)) : 0;
  if (cu > 0) {
    const cols = [BRAND.rojo, BRAND.marino, BRAND.azul, BRAND.rojo, BRAND.marino];
    cols.forEach((c, i) => { g.fillStyle = c; const h = H / cols.length; g.fillRect((i % 2 ? 1 : -1) * (1 - cu) * W, i * h, W, h + 1); });
    if (cu > 0.6) { g.globalAlpha = (cu - 0.6) / 0.4; g.fillStyle = '#fff'; g.font = '64px UneDisplay'; g.textAlign = 'center'; g.fillText('NOTICIAS', W / 2, H / 2); g.textAlign = 'left'; g.globalAlpha = 1; }
  }
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.font = '18px UneText'; g.fillText('vista provisional · newsvid', 16, H - 20);
}

// ---------------------------------------------------------------- pressed key / button feedback (WP4)
// On-screen keyboard layout, normalized to the phone screen (same geometry main.js used).
export const KB = { top: 0.70, rowH: 0.072, rows: ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'], x0: [0.05, 0.07, 0.17], kw: 0.09 };
// normalized rect {x, y, w, h} (top-left origin) + centre {cx, cy} of key (row, col)
export function keyRect(row, col, k = 1) {
  const top = KB.top + (1 - k) * 0.32;
  const x = KB.x0[row] + KB.kw * col, y = top + 0.03 + KB.rowH * row;
  return { x, y, w: KB.kw, h: KB.rowH, cx: x + KB.kw / 2, cy: y + KB.rowH / 2 };
}
// Keyboard (k = slide-in 0..1). key = {row, col} is lit cyan with an enlarged key balloon above;
// p = 0..1 pulse strength of the press (1 = fully pressed).
export function drawKeyboard(x, w, h, k, key, p = 1, typed = null) {
  if (typed != null) drawTyped(x, w, h, typed);
  const top = h * (KB.top + (1 - k) * 0.32);
  x.save();
  x.fillStyle = '#0d1a2b'; x.fillRect(0, top, w, h - top);
  x.fillStyle = 'rgba(255,255,255,0.08)'; x.fillRect(0, top, w, 3);
  x.font = '600 34px UneText'; x.textAlign = 'center'; x.textBaseline = 'middle';
  let hit = null;
  KB.rows.forEach((row, ri) => {
    for (let c = 0; c < row.length; c++) {
      const kx = w * (KB.x0[ri] + KB.kw * c) + 4, ky = top + h * (0.03 + KB.rowH * ri) + 6, kw = w * KB.kw - 8, kh = h * KB.rowH - 12;
      const on = key && !key.space && key.row === ri && key.col === c;
      if (on) hit = { kx, ky, kw, kh, ch: row[c] };
      x.fillStyle = on ? `rgba(61,224,255,${0.35 + 0.65 * p})` : 'rgba(255,255,255,0.16)';
      x.beginPath(); x.roundRect(kx, ky + (on ? 3 * p : 0), kw, kh, 10); x.fill();
      x.fillStyle = on ? '#06121F' : '#ffffff'; x.fillText(row[c], kx + kw / 2, ky + kh / 2 + 1 + (on ? 3 * p : 0));
    }
  });
  const sy = top + h * (0.03 + KB.rowH * 3) + 6, sOn = !!(key && key.space);
  x.fillStyle = sOn ? `rgba(61,224,255,${0.35 + 0.65 * p})` : 'rgba(255,255,255,0.16)'; x.beginPath(); x.roundRect(w * 0.25, sy + (sOn ? 3 * p : 0), w * 0.5, h * KB.rowH - 12, 10); x.fill();
  if (sOn) { x.save(); x.globalAlpha = p; x.strokeStyle = '#3DE0FF'; x.lineWidth = 4; x.shadowColor = '#3DE0FF'; x.shadowBlur = 18; x.beginPath(); x.roundRect(w * 0.25 - 3, sy - 3 + 3 * p, w * 0.5 + 6, h * KB.rowH - 6, 12); x.stroke(); x.restore(); }
  x.fillStyle = sOn ? '#06121F' : 'rgba(255,255,255,0.7)'; x.font = '600 26px UneText'; x.fillText('espacio', w * 0.5, sy + (h * KB.rowH - 12) / 2 + (sOn ? 3 * p : 0));
  if (hit && p > 0.05) { // key balloon (iOS-style preview), readable on TV
    const bw = hit.kw * 1.55, bh = hit.kh * 1.6, bx = Math.min(w - bw - 6, Math.max(6, hit.kx + hit.kw / 2 - bw / 2)), by = hit.ky - bh - 6;
    x.globalAlpha = Math.min(1, p * 1.5);
    x.shadowColor = 'rgba(0,0,0,0.5)'; x.shadowBlur = 18; x.shadowOffsetY = 6;
    x.fillStyle = '#ffffff'; x.beginPath(); x.roundRect(bx, by, bw, bh, 16); x.fill();
    x.shadowColor = 'transparent';
    x.strokeStyle = '#3DE0FF'; x.lineWidth = 5; x.beginPath(); x.roundRect(bx, by, bw, bh, 16); x.stroke();
    x.fillStyle = '#0B2238'; x.font = '800 60px UneText'; x.fillText(hit.ch, bx + bw / 2, by + bh / 2 + 2);
  }
  x.restore();
}
// Pressed-button highlight on the phone screen texture. which = HOTSPOT key ('preparar', 'subir',
// 'shutter'), k = 0..1 press amount. Draw it after the screenshot, before the texture update.
export function drawPress(x, w, h, which, k) {
  const hp = HOTSPOT[which]; if (!hp || k <= 0) return;
  const bx = (hp.x - hp.w / 2) * w, by = (hp.y - hp.h / 2) * h, bw = hp.w * w, bh = hp.h * h;
  const r = hp.round ? Math.min(bw, bh) / 2 : Math.min(28, bh / 2);
  x.save();
  x.globalAlpha = 0.5 * k; x.fillStyle = '#ffffff';
  if (hp.round) { x.beginPath(); x.arc(bx + bw / 2, by + bh / 2, Math.min(bw, bh) / 2 * (1 - 0.08 * k), 0, 7); x.fill(); }
  else { x.beginPath(); x.roundRect(bx + bw * 0.02 * k, by + bh * 0.04 * k, bw * (1 - 0.04 * k), bh * (1 - 0.08 * k), r); x.fill(); }
  x.globalAlpha = k; x.strokeStyle = '#3DE0FF'; x.lineWidth = 6; x.shadowColor = '#3DE0FF'; x.shadowBlur = 24;
  x.beginPath();
  if (hp.round) x.arc(bx + bw / 2, by + bh / 2, Math.min(bw, bh) / 2 + 6, 0, 7); else x.roundRect(bx - 5, by - 5, bw + 10, bh + 10, r + 5);
  x.stroke();
  x.restore();
}

// ---------------------------------------------------------------- typing (WP4): report box filled letter by letter
// text = typing.js typedTextAt(t) (WP2); main.js passes it as drawKeyboard's 7th argument (desc.typed).
// paints the report box of app_3/app_4 (layout 'app3', with caret) or app_5 (layout 'app5', box scrolled to the top
// edge, no caret) empty and fills it with `text` (last 3 lines visible, bottom-aligned for app5)
const BOX = { app3: { x: 97, y: 761, w: 586, h: 166, y0: 806, caret: true }, app5: { x: 100, y: 0, w: 580, h: 151, y0: 40, caret: false } };
export function drawTyped(x, w, h, text, layout = 'app3') {
  const B = BOX[layout] || BOX.app3, sx = w / 780, sy = h / 1688;
  x.save();
  x.fillStyle = '#06121F'; x.beginPath(); x.roundRect(B.x * sx, B.y * sy, B.w * sx, B.h * sy, 12 * sx); x.fill();
  x.beginPath(); x.rect(B.x * sx, B.y * sy, B.w * sx, B.h * sy); x.clip();
  x.font = `400 ${Math.round(30 * sx)}px UneText`; x.textBaseline = 'middle'; x.fillStyle = '#ffffff';
  const lines = text ? wrap(x, text, 540 * sx) : [''];
  const vis = lines.slice(-3);
  vis.forEach((l, i) => x.fillText(l, 126 * sx, (B.y0 + i * 46) * sy));
  if (B.caret) {
    const li = vis.length - 1, lw = x.measureText(vis[li]).width;
    x.fillStyle = '#3DE0FF'; x.fillRect(126 * sx + lw + 3 * sx, (B.y0 + li * 46 - 17) * sy, 3 * sx, 34 * sy);
  }
  x.restore();
}
// app_5 keeps the sentence the reporter typed (TYPED_TEXT) in its report box → text continuous 12–24.6 s
function withTypedBox(im) {
  const c = cnv(im.width, im.height), g = c.getContext('2d'); g.drawImage(im, 0, 0);
  drawTyped(g, im.width, im.height, TYPED_TEXT, 'app5'); return c;
}

// app_6: the tapped button reads SUBIR / PUBLICAR (orange CTA) instead of "DESCARGAR VIDEO NOTICIA"
function withSubirButton(im) {
  const W = im.width, H = im.height, k = W / 780; const c = cnv(W, H); const g = c.getContext('2d');
  g.drawImage(im, 0, 0);
  const x0 = 66 * k, y0 = 216 * k, bw = 648 * k, bh = 106 * k;
  g.fillStyle = '#091d31'; g.fillRect(x0 - 4 * k, y0 - 4 * k, bw + 8 * k, bh + 8 * k);
  g.save(); g.shadowColor = 'rgba(253,174,3,0.55)'; g.shadowBlur = 26 * k;
  g.fillStyle = lg(g, x0, 0, x0 + bw, 0, ['#FDAE03', '#F6901C', '#E8541A']); g.beginPath(); g.roundRect(x0, y0, bw, bh, 22 * k); g.fill(); g.restore();
  g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 3 * k; g.beginPath(); g.roundRect(x0 + 1.5 * k, y0 + 1.5 * k, bw - 3 * k, bh - 3 * k, 21 * k); g.stroke();
  // upload arrow icon + label
  g.font = `${Math.round(44 * k)}px UneDisplay`; g.textBaseline = 'middle';
  const label = 'SUBIR / PUBLICAR', tw = g.measureText(label).width, ic = 40 * k, gap = 18 * k;
  const sx = W / 2 - (ic + gap + tw) / 2, cy = y0 + bh / 2;
  g.strokeStyle = '#ffffff'; g.lineWidth = 6 * k; g.lineCap = 'round'; g.lineJoin = 'round';
  g.beginPath(); g.moveTo(sx + ic / 2, cy + ic * 0.32); g.lineTo(sx + ic / 2, cy - ic * 0.42); g.moveTo(sx + ic * 0.16, cy - ic * 0.1); g.lineTo(sx + ic / 2, cy - ic * 0.44); g.lineTo(sx + ic * 0.84, cy - ic * 0.1);
  g.moveTo(sx, cy + ic * 0.2); g.lineTo(sx, cy + ic * 0.5); g.lineTo(sx + ic, cy + ic * 0.5); g.lineTo(sx + ic, cy + ic * 0.2); g.stroke();
  g.fillStyle = 'rgba(122,46,12,0.55)'; g.fillText(label, sx + ic + gap + 2 * k, cy + 4 * k);
  g.fillStyle = '#ffffff'; g.fillText(label, sx + ic + gap, cy + 2 * k);
  return c;
}
