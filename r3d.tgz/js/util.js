// Shared deterministic helpers
export function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (t) => { t = clamp(t); return t * t * (3 - 2 * t); };
export const easeInOut = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
export const easeOut = (t) => { t = clamp(t); return 1 - Math.pow(1 - t, 3); };
export const easeIn = (t) => { t = clamp(t); return t * t * t; };
export const easeOutBack = (t, s = 1.70158) => { t = clamp(t); const c3 = s + 1; return 1 + c3 * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2); };
// springy bounce-in 0..1 (overshoot then settle)
export const pop = (t) => {
  if (t <= 0) return 0; if (t >= 1) return 1;
  return 1 - Math.exp(-6.5 * t) * Math.cos(t * 11.5);
};
// progress of t in [a,b]
export const prog = (t, a, b) => clamp((t - a) / (b - a));
// window envelope: 0 before a, ramps in over ri, holds, ramps out over ro ending at b
export function env(t, a, b, ri = 0.3, ro = 0.3) {
  if (t < a || t > b) return 0;
  return Math.min(clamp((t - a) / ri), clamp((b - t) / ro));
}
export function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

// keyframe track: keys = [[time, value(number|array|object)], ...] eased in/out between keys
export function track(keys, t, ease = easeInOut) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
    if (t <= t1) {
      const e = keys[i + 1][2] === 'back' ? (x) => easeOutBack(x, 1.4) : keys[i + 1][2] === 'out' ? easeOut : ease;
      const k = e((t - t0) / Math.max(1e-6, t1 - t0));
      return mix(v0, v1, k);
    }
  }
  return keys[keys.length - 1][1];
}
export function mix(a, b, k) {
  if (typeof a === 'number') return a + (b - a) * k;
  if (Array.isArray(a)) return a.map((v, i) => v + (b[i] - v) * k);
  const o = {};
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const key of keys) {
    const va = a[key] ?? b[key], vb = b[key] ?? a[key];
    o[key] = mix(va, vb, k);
  }
  return o;
}
export const BRAND = {
  noche: '#06121F', marino: '#0B2238', cian: '#08E1FF', azul: '#4C8FE2',
  ambar: '#FDAE03', naranja: '#F6901C', brasa: '#EA4F3D', rojo: '#E3173E',
};

export function loadImage(src) {
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = () => res(null);
    im.src = src;
  });
}

// ---------------------------------------------------------------- motion design helpers (WP2)
export const easeInOutQuad = (t) => { t = clamp(t); return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; };
export const easeOutExpo = (t) => { t = clamp(t); return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t); };
export const easeInCubic = (t) => { t = clamp(t); return t * t * t; };
// deterministic 1D value noise (quintic fade) and 3-octave fbm in [-1,1]
function hash1(i, seed) { let x = Math.imul((i | 0) ^ Math.imul((seed | 0) + 1, 0x9E3779B1), 0x85EBCA6B); x ^= x >>> 13; x = Math.imul(x, 0xC2B2AE35); x ^= x >>> 16; return (x >>> 0) / 4294967296 * 2 - 1; }
export function noise1(x, seed = 0) { const i = Math.floor(x), f = x - i; const u = f * f * f * (f * (f * 6 - 15) + 10); return hash1(i, seed) + (hash1(i + 1, seed) - hash1(i, seed)) * u; }
export function fbm(t, seed = 0, f0 = 0.5) { return noise1(t * f0, seed) * 0.6 + noise1(t * f0 * 2.13 + 3.1, seed + 17) * 0.28 + noise1(t * f0 * 4.37 + 7.7, seed + 31) * 0.12; }
// underdamped spring step response from 0 to 1 (x(0)=0, v(0)=0)
export function springStep(tau, zeta = 0.62, omega = 10) {
  if (tau <= 0) return 0;
  const wd = omega * Math.sqrt(1 - zeta * zeta), a = zeta * omega;
  return 1 - Math.exp(-a * tau) * (Math.cos(wd * tau) + (a / wd) * Math.sin(wd * tau));
}
// Per-segment transition weight. type: undefined|'ease' (easeInOutQuad 0.4–0.7 s, arrives at the key),
// 'back' (anticipation 13 % for 0.12 s + spring with 8 % overshoot peaking at the key, settles ~0.4 s after),
// 'out' (easeOutCubic ≤0.5 s), 'drift' (whole interval), 'cut' (instant at the key). noAnt: skip anticipation.
const SPR_Z = 0.645, SPR_PEAK = 0.4, SPR_WD = Math.PI / SPR_PEAK, SPR_W = SPR_WD / Math.sqrt(1 - SPR_Z * SPR_Z), ANT = 0.12, ANT_A = 0.13;
export function segWeight(type, t, t0, t1, noAnt = false) {
  const dur = Math.max(1e-6, t1 - t0);
  if (type === 'cut') return t >= t1 ? 1 : 0;
  if (type === 'drift') return easeInOutQuad((t - t0) / dur);
  if (type === 'back') {
    const s = t1 - SPR_PEAK - ANT; const tau = t - s;
    if (tau <= 0) return 0;
    if (tau < ANT) return noAnt ? 0 : -ANT_A * easeInOutQuad(tau / ANT);
    const a0 = noAnt ? 0 : -ANT_A;
    return a0 + (1 - a0) * springStep(tau - ANT, SPR_Z, SPR_W);
  }
  if (type === 'out') { const D = Math.min(dur, 0.5); return easeOut((t - (t1 - D)) / D); }
  const D = Math.min(dur, 0.7); return easeInOutQuad((t - (t1 - D)) / D);
}
// linear combination helpers for numbers / arrays / objects
function addScaled(acc, a, b, w) { // acc + (b-a)*w (returns new value)
  if (typeof acc === 'number') return acc + ((b ?? a) - a) * w;
  if (Array.isArray(acc)) return acc.map((v, i) => v + ((b ?? a)[i] - a[i]) * w);
  const o = {}; for (const k of Object.keys(acc)) o[k] = addScaled(acc[k], a[k] ?? acc[k], (b ?? a)[k] ?? a[k] ?? acc[k], w); return o;
}
// Per-channel pose track: keys = [[time, pose(obj), type?], ...]. Each channel is the first key value plus the
// superposition of every segment delta × its transition weight, evaluated at (t - delay(channel)).
// So transitions overlap freely, overshoot/settle tails continue into the next hold, nothing stops dead.
export function trackCh(keys, t, delayOf = () => 0, noAntOf = () => false) {
  const out = {};
  const chans = new Set(); for (const k of keys) for (const c of Object.keys(k[1])) chans.add(c);
  for (const c of chans) {
    const tc = t - delayOf(c); const na = noAntOf(c);
    let v = keys[0][1][c]; let prev = v;
    for (let i = 0; i < keys.length - 1; i++) {
      const a = keys[i][1][c] ?? prev, b = keys[i + 1][1][c] ?? a; prev = b;
      if (a === b) continue;
      const w = segWeight(keys[i + 1][2], tc, keys[i][0], keys[i + 1][0], na);
      if (w !== 0) v = addScaled(v, a, b, w);
    }
    out[c] = v;
  }
  return out;
}
