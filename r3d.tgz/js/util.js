// Shared deterministic helpers
export function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (t) => { t = clamp(t); return t * t * (3 - 2 * t); };
export const easeInOut = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
export const easeOut = (t) => { t = clamp(t); return 1 - Math.pow(1 - t, 3); };
export const easeIn = (t) => { t = clamp(t); return t * t * t; };
export const easeOutBack = (t, s = 1.70158) => { t = clamp(t); const c3 = s + 1; return 1 + c3 * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2); };
// springy bounce-in 0..1 (overshoot then settle)
export const pop = (t) => {
  if (t <= 0) return 0; if (t >= 1) return 1;
  return 1 - Math.exp(-6.5 * t) * Math.cos(t * 11.5);
};
// progress of t in [a,b]
export const prog = (t, a, b) => clamp((t - a) / (b - a));
// window envelope: 0 before a, ramps in over ri, holds, ramps out over ro ending at b
export function env(t, a, b, ri = 0.3, ro = 0.3) {
  if (t < a || t > b) return 0;
  return Math.min(clamp((t - a) / ri), clamp((b - t) / ro));
}
export function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

// keyframe track: keys = [[time, value(number|array|object)], ...] eased in/out between keys
export function track(keys, t, ease = easeInOut) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
    if (t <= t1) {
      const e = keys[i + 1][2] === 'back' ? (x) => easeOutBack(x, 1.4) : keys[i + 1][2] === 'out' ? easeOut : ease;
      const k = e((t - t0) / Math.max(1e-6, t1 - t0));
      return mix(v0, v1, k);
    }
  }
  return keys[keys.length - 1][1];
}
export function mix(a, b, k) {
  if (typeof a === 'number') return a + (b - a) * k;
  if (Array.isArray(a)) return a.map((v, i) => v + (b[i] - v) * k);
  const o = {};
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const key of keys) {
    const va = a[key] ?? b[key], vb = b[key] ?? a[key];
    o[key] = mix(va, vb, k);
  }
  return o;
}
export const BRAND = {
  noche: '#06121F', marino: '#0B2238', cian: '#08E1FF', azul: '#4C8FE2',
  ambar: '#FDAE03', naranja: '#F6901C', brasa: '#EA4F3D', rojo: '#E3173E',
};

export function loadImage(src) {
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = () => res(null);
    im.src = src;
  });
}
