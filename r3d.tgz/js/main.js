// Estudio de Noticias — 62 s vertical 3D explainer. Deterministic: window.render(t) draws exactly time t.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildStreet, buildLights, glowTex } from './set.js';
import { buildReporter, DEFAULT_POSE, HANDS, PHONE } from './character.js';
import { TYPING_TAPS } from './typing.js';
import { A, HOTSPOT, loadAssets, newsFrame } from './screens.js';
import * as O from './overlay.js';
import { rng, clamp, lerp, smooth, easeInOut, easeOut, easeIn, easeOutBack, pop, prog, env, track, mix, BRAND } from './util.js';

const Q = new URLSearchParams(location.search);
const W = +(Q.get('w') || 1080), H = +(Q.get('h') || 1920);
const SC = W / 1080;
const DUR = 62;
const FOV = 35;

const bg = document.getElementById('bg'), gl = document.getElementById('gl'), fx = document.getElementById('fx');
for (const c of [bg, gl, fx]) { c.width = W; c.height = H; c.style.width = W + 'px'; c.style.height = H + 'px'; }
document.getElementById('stage').style.width = W + 'px'; document.getElementById('stage').style.height = H + 'px';
const bgg = bg.getContext('2d'), g = fx.getContext('2d');

const AA = Q.get('aa') !== '0';
const SHADOW = +(Q.get('sh') || 2048);
const renderer = new THREE.WebGLRenderer({ canvas: gl, antialias: AA, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.setClearColor(0x000000, 0);
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = SHADOW > 0; renderer.shadowMap.type = Q.get('pcf') === '1' ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap; renderer.shadowMap.autoUpdate = true;

const scene = new THREE.Scene();
const ENV = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(renderer), 0.04).texture;
const FOG_STREET = new THREE.Fog('#5d86bd', 16, 70);
const camera = new THREE.PerspectiveCamera(FOV, W / H, 0.03, 220);
scene.add(camera);
const hud = new THREE.Group(); camera.add(hud);

let street, studio, rig, L, lights;
const CHAR_Z = 2.3;

// ---------------------------------------------------------------- HUD helpers
const TAN = Math.tan(THREE.MathUtils.degToRad(FOV / 2));
function hudPlace(obj, xpx, ypx, hpx, D = 2.2) {
  const visH = 2 * D * TAN, visW = visH * W / H;
  obj.position.set((xpx / 1080 - 0.5) * visW, (0.5 - ypx / 1920) * visH, -D);
  obj.scale.setScalar(Math.max(1e-4, hpx / 1920 * visH));
}
const _v = new THREE.Vector3();
function toPx(v3) { _v.copy(v3).project(camera); return { x: (_v.x * 0.5 + 0.5) * 1080, y: (0.5 - _v.y * 0.5) * 1920, z: _v.z }; }

function roundedShape(w, h, r) {
  const s = new THREE.Shape(); const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r); s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h); s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y); return s;
}
function faceGeo(w, h, r) {
  const geo = new THREE.ShapeGeometry(roundedShape(w, h, r), 6);
  const p = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / w + 0.5, p.getY(i) / h + 0.5);
  return geo;
}
// card with unit height: body (extruded, bevelled) + image face
function makeCard(aspect, { body = '#ffffff', border = 0.04, depth = 0.035, radius = 0.05, canvasW = 1080, glass = false } = {}) {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const w = aspect, h = 1;
  const bw = w + border * 2, bh = h + border * 2;
  const ext = new THREE.ExtrudeGeometry(roundedShape(bw, bh, radius + border), { depth, bevelEnabled: true, bevelThickness: 0.012, bevelSize: 0.012, bevelSegments: 3, curveSegments: 8 });
  ext.translate(0, 0, -depth);
  const bodyMat = new THREE.MeshPhysicalMaterial({ color: body, roughness: glass ? 0.1 : 0.35, clearcoat: 1, clearcoatRoughness: 0.15, metalness: 0.0, envMapIntensity: 1.0, transmission: 0, sheen: 0.2 });
  const bodyM = new THREE.Mesh(ext, bodyMat); inner.add(bodyM);
  const cv = document.createElement('canvas'); cv.width = canvasW; cv.height = Math.round(canvasW / aspect);
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const face = new THREE.Mesh(faceGeo(w, h, radius), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false, transparent: true }));
  face.position.z = 0.0135; inner.add(face);
  // gloss sweep plane
  const gl2 = new THREE.Mesh(faceGeo(w, h, radius), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending }));
  gl2.position.z = 0.015; inner.add(gl2);
  // soft contact shadow behind
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(bw * 1.35, bh * 1.35), new THREE.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false, opacity: 0.6 }));
  sh.position.set(0.04, -0.06, -depth - 0.25); inner.add(sh);
  grp.visible = false;
  return { grp, inner, cv, ctx: cv.getContext('2d'), tex, face, bodyMat, aspect, key: '' };
}
let _shadowTex;
function shadowTex() {
  if (_shadowTex) return _shadowTex;
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
  const gr = x.createRadialGradient(64, 64, 10, 64, 64, 64); gr.addColorStop(0, 'rgba(0,0,0,0.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128); _shadowTex = new THREE.CanvasTexture(c); return _shadowTex;
}

// ---------------------------------------------------------------- coin
let coin;
function makeCoin() {
  const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d');
  const gr = x.createRadialGradient(200, 180, 20, 256, 256, 260); gr.addColorStop(0, '#fff3b0'); gr.addColorStop(0.5, '#ffc93a'); gr.addColorStop(1, '#d88a00');
  x.fillStyle = gr; x.fillRect(0, 0, 512, 512);
  x.strokeStyle = 'rgba(140,80,0,0.8)'; x.lineWidth = 14; x.beginPath(); x.arc(256, 256, 214, 0, 7); x.stroke();
  x.strokeStyle = 'rgba(255,245,200,0.9)'; x.lineWidth = 6; x.beginPath(); x.arc(256, 256, 200, 0, 7); x.stroke();
  // lightning bolt in relief
  const bolt = new Path2D('M286,92 L160,284 L246,284 L214,420 L352,214 L262,214 Z');
  x.save(); x.translate(8, 10); x.fillStyle = 'rgba(120,60,0,0.75)'; x.fill(bolt); x.restore();
  const bg2 = x.createLinearGradient(160, 92, 352, 420); bg2.addColorStop(0, '#fffbe6'); bg2.addColorStop(1, '#ffb300');
  x.fillStyle = bg2; x.fill(bolt); x.strokeStyle = '#a35f00'; x.lineWidth = 6; x.stroke(bolt);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const faceMat = new THREE.MeshPhysicalMaterial({ map: tex, metalness: 0.75, roughness: 0.28, clearcoat: 1, envMapIntensity: 1.5, color: '#ffffff' });
  const sideMat = new THREE.MeshPhysicalMaterial({ color: '#f0a400', metalness: 0.9, roughness: 0.25, envMapIntensity: 1.6 });
  const m = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.11, 48, 1), [sideMat, faceMat, faceMat]);
  m.rotation.x = Math.PI / 2;
  const grp = new THREE.Group(); const spin = new THREE.Group(); spin.add(m); grp.add(spin);
  // rim ridges
  const ridge = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.03, 10, 64), sideMat); spin.add(ridge);
  grp.visible = false; return { grp, spin };
}

// ---------------------------------------------------------------- studio
function buildStudio() {
  const s = new THREE.Group(); s.name = 'studio';
  const top = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.32, 0.22, 64), new THREE.MeshPhysicalMaterial({ color: '#0e2c4d', roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.1, envMapIntensity: 1 }));
  top.position.y = -0.11; top.receiveShadow = true; s.add(top);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.27, 0.022, 10, 96), new THREE.MeshBasicMaterial({ color: '#08E1FF', toneMapped: false }));
  ring.rotation.x = Math.PI / 2; ring.position.y = 0.0; s.add(ring);
  const ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.33, 0.015, 8, 96), new THREE.MeshBasicMaterial({ color: '#F6901C', toneMapped: false }));
  ring2.rotation.x = Math.PI / 2; ring2.position.y = -0.2; s.add(ring2);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(1.2, 64), new THREE.MeshPhysicalMaterial({ color: '#123a63', roughness: 0.3, clearcoat: 1, envMapIntensity: 0.8 }));
  disc.rotation.x = -Math.PI / 2; disc.position.y = 0.002; disc.receiveShadow = true; s.add(disc);
  // glow under the rim
  const gs = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 4.2), new THREE.MeshBasicMaterial({ map: glowTex('8,225,255'), transparent: true, opacity: 0.35, depthWrite: false, blending: THREE.AdditiveBlending }));
  gs.rotation.x = -Math.PI / 2; gs.position.y = -0.21; s.add(gs);
  s.visible = false; return s;
}

// ---------------------------------------------------------------- objects
let photoCard, postCard, styleCards, vidPhone, sponsorCard, logoPlate;
function makeLogoPlate() {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const asp = 929 / 959, pad = 0.12, w = asp + pad * 2, h = 1 + pad * 2;
  const ext = new THREE.ExtrudeGeometry(roundedShape(w, h, 0.14), { depth: 0.06, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 4, curveSegments: 10 });
  ext.translate(0, 0, -0.06);
  const body = new THREE.Mesh(ext, new THREE.MeshPhysicalMaterial({ color: '#0b1a33', roughness: 0.18, metalness: 0.3, clearcoat: 1, clearcoatRoughness: 0.05, envMap: ENV, envMapIntensity: 1.4 }));
  inner.add(body);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1, 0.012, 6, 64), new THREE.MeshBasicMaterial({ color: '#3B71FB', toneMapped: false }));
  const cv = document.createElement('canvas'); cv.width = 1024; cv.height = Math.round(1024 * h / w); const x = cv.getContext('2d');
  const gr = x.createRadialGradient(cv.width / 2, cv.height * 0.4, 20, cv.width / 2, cv.height / 2, cv.width * 0.8); gr.addColorStop(0, '#13305e'); gr.addColorStop(1, '#070f1e');
  x.fillStyle = gr; x.fillRect(0, 0, cv.width, cv.height);
  x.strokeStyle = '#3B71FB'; x.lineWidth = 10; x.beginPath(); x.roundRect(8, 8, cv.width - 16, cv.height - 16, 120); x.stroke();
  if (A.logo) { const lw = cv.width * asp / w, lh = lw / asp; x.drawImage(A.logo, (cv.width - lw) / 2, (cv.height - lh) / 2, lw, lh); }
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const face = new THREE.Mesh(faceGeo(w, h, 0.14), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); face.position.z = 0.021; inner.add(face);
  const sweep = new THREE.Mesh(faceGeo(w, h, 0.14), new THREE.MeshBasicMaterial({ map: sweepTex(), transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false })); sweep.position.z = 0.023; inner.add(sweep);
  const glow = new THREE.Mesh(new THREE.PlaneGeometry(w * 2.6, h * 2.2), new THREE.MeshBasicMaterial({ map: glowTex('59,113,251'), transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending })); glow.position.z = -0.35; inner.add(glow);
  // reflection (flipped, fading) under the plate
  const rc = document.createElement('canvas'); rc.width = cv.width; rc.height = cv.height; const rx = rc.getContext('2d');
  rx.translate(0, rc.height); rx.scale(1, -1); rx.drawImage(cv, 0, 0); rx.setTransform(1, 0, 0, 1, 0, 0);
  rx.globalCompositeOperation = 'destination-in'; const fg = rx.createLinearGradient(0, 0, 0, rc.height); fg.addColorStop(0, 'rgba(0,0,0,0.35)'); fg.addColorStop(0.45, 'rgba(0,0,0,0)'); rx.fillStyle = fg; rx.fillRect(0, 0, rc.width, rc.height);
  const rt = new THREE.CanvasTexture(rc); rt.colorSpace = THREE.SRGBColorSpace;
  const refl = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: rt, transparent: true, depthWrite: false, toneMapped: false })); refl.position.set(0, -h - 0.06, 0); inner.add(refl);
  grp.visible = false;
  return { grp, inner, sweep, glow, refl };
}
function sweepTex() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256; const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 256, 256); g.addColorStop(0.35, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.55)'); g.addColorStop(0.65, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 256, 256); const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; return t;
}
function makePhoneHud() {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const aspect = 9 / 16;
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(roundedShape(aspect + 0.07, 1.07, 0.09), { depth: 0.05, bevelEnabled: true, bevelThickness: 0.015, bevelSize: 0.015, bevelSegments: 3 }),
    new THREE.MeshPhysicalMaterial({ color: '#1a2230', metalness: 0.6, roughness: 0.25, clearcoat: 1, envMapIntensity: 1.2 }));
  body.position.z = -0.05; inner.add(body);
  const cv = document.createElement('canvas'); cv.width = 540; cv.height = 960;
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const face = new THREE.Mesh(faceGeo(aspect, 1, 0.05), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
  face.position.z = 0.017; inner.add(face);
  const notch = new THREE.Mesh(new THREE.CapsuleGeometry(0.012, 0.06, 4, 8), new THREE.MeshBasicMaterial({ color: '#000' })); notch.rotation.z = Math.PI / 2; notch.position.set(0, 0.47, 0.02); inner.add(notch);
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.5), new THREE.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false, opacity: 0.6 }));
  sh.position.set(0.04, -0.06, -0.3); inner.add(sh);
  grp.visible = false;
  return { grp, inner, cv, ctx: cv.getContext('2d'), tex };
}

// ---------------------------------------------------------------- init
async function init() {
  for (const f of ['80px UneDisplay', '60px UneCond', 'italic 60px UneCond', '40px UneText', '40px UneTextB', '80px UneLogo']) await document.fonts.load(f);
  await loadAssets();
  A.logo = await new Promise(r => { const im = new Image(); im.onload = () => r(im); im.onerror = () => r(null); im.src = 'assets/proaudih_logo_blanco.png'; });
  // logo symbol only (rounded square with slashes), cropped without distortion
  A.logoSym = document.createElement('canvas'); A.logoSym.width = 650; A.logoSym.height = 704;
  if (A.logo) A.logoSym.getContext('2d').drawImage(A.logo, 140, 0, 650, 704, 0, 0, 650, 704);
  const S = buildStreet(); street = S.root; scene.add(street);
  studio = buildStudio(); scene.add(studio);
  lights = buildLights(scene);
  lights.key.shadow.mapSize.set(SHADOW || 1, SHADOW || 1);
  rig = buildReporter(); scene.add(rig.root); scene.add(rig.blob);
  coin = makeCoin(); hud.add(coin.grp);
  photoCard = makeCard(4 / 3, { body: '#ffffff', border: 0.045, canvasW: 1200 }); hud.add(photoCard.grp);
  postCard = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 1080 }); hud.add(postCard.grp);
  styleCards = [0, 1, 2].map(() => { const c = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 720 }); hud.add(c.grp); return c; });
  sponsorCard = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 720 }); hud.add(sponsorCard.grp);
  vidPhone = makePhoneHud(); hud.add(vidPhone.grp);
  // static card faces
  fillCard(photoCard, (x, w, h) => { x.drawImage(A.photo, 0, 0, w, h); });
  fillCard(postCard, (x, w, h) => { x.drawImage(A.posts.impacto, 0, 0, w, h); });
  ['clasico', 'cristal', 'impacto'].forEach((k, i) => fillCard(styleCards[i], (x, w, h) => x.drawImage(A.posts[k], 0, 0, w, h)));
  drawLaptop();
  // mic flag cube: real logo symbol on navy
  { const c = rig.flagCanvas, x = c.getContext('2d'); const gr = x.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#0e2a48'); gr.addColorStop(1, '#06121F');
    x.fillStyle = gr; x.fillRect(0, 0, 256, 256); x.fillStyle = '#3DE0FF'; x.fillRect(0, 0, 256, 12); x.fillRect(0, 244, 256, 12);
    if (A.logo) { const hh = 196, ww = hh * 929 / 959; x.drawImage(A.logo, 128 - ww / 2, 30, ww, hh); }
    rig.flagTex.needsUpdate = true; }
  // hero logo plate for the close
  logoPlate = makeLogoPlate(); hud.add(logoPlate.grp);
  // Image-based reflections only on small shiny props (full-screen PMREM sampling is too slow on a CPU rasterizer)
  scene.traverse(o => { const ms = Array.isArray(o.material) ? o.material : o.material ? [o.material] : []; for (const m of ms) if (m.isMeshStandardMaterial && m.metalness >= 0.5) { m.envMap = ENV; m.needsUpdate = true; } });
  if (Q.get('env') === '1') scene.environment = ENV;
  if (Q.get('basic') === '1') scene.overrideMaterial = new THREE.MeshBasicMaterial({ color: '#888' });
  if (Q.get('std') === '1') scene.traverse(o => { if (o.material && !Array.isArray(o.material) && o.material.isMeshPhysicalMaterial) { const m = o.material; o.material = new THREE.MeshStandardMaterial({ color: m.color, map: m.map, roughness: m.roughness, metalness: m.metalness, emissive: m.emissive, emissiveIntensity: m.emissiveIntensity, transparent: m.transparent, opacity: m.opacity }); } });
  // warm-up compile
  renderer.compile(scene, camera);
}
function fillCard(card, fn) { const w = card.cv.width, h = card.cv.height; card.ctx.clearRect(0, 0, w, h); fn(card.ctx, w, h); card.tex.needsUpdate = true; }

function drawLaptop() {
  const c = rig.lapCanvas, x = c.getContext('2d'); const w = c.width, h = c.height;
  const gr = x.createLinearGradient(0, 0, w, h); gr.addColorStop(0, '#0B2238'); gr.addColorStop(1, '#06121F'); x.fillStyle = gr; x.fillRect(0, 0, w, h);
  // top bar
  x.fillStyle = 'rgba(255,255,255,0.06)'; x.fillRect(0, 0, w, 54);
  x.font = '30px UneDisplay'; x.fillStyle = '#fff'; x.textBaseline = 'middle'; x.fillText('ESTUDIO DE', 30, 28);
  x.fillStyle = BRAND.ambar; x.fillText('NOTICIAS', 30 + x.measureText('ESTUDIO DE ').width, 28);
  if (A.logo) x.drawImage(A.logo, w - 30 - 48 * 929 / 959, 3, 48 * 929 / 959, 48);
  // app_6 (phone-size screen) centered-left, post on right
  const ah = h - 90, aw = ah * 780 / 1688;
  x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 30;
  x.beginPath(); x.roundRect(120, 72, aw, ah, 22); x.clip(); x.drawImage(A.app[6], 120, 72, aw, ah); x.restore();
  const ph = h - 130, pw = ph * 0.8;
  x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 40; x.drawImage(A.posts.impacto, w - pw - 110, 92, pw, ph); x.restore();
  x.strokeStyle = 'rgba(8,225,255,0.5)'; x.lineWidth = 3; x.strokeRect(w - pw - 110, 92, pw, ph);
  rig.lapTex.needsUpdate = true;
}

// ---------------------------------------------------------------- phone screen states
let screenKey = '';
function drawScreen(desc) {
  const key = JSON.stringify(desc);
  if (key === screenKey) return; screenKey = key;
  const c = rig.screenCanvas, x = c.getContext('2d'); const w = c.width, h = c.height;
  x.fillStyle = '#000'; x.fillRect(0, 0, w, h);
  if (desc.kind === 'app') {
    const a = A.app[desc.a], b = A.app[desc.b ?? desc.a];
    x.globalAlpha = 1; x.drawImage(a, 0, -desc.k * 40, w, h);
    if (desc.k > 0 && b) { x.globalAlpha = desc.k; x.drawImage(b, 0, (1 - desc.k) * 40, w, h); x.globalAlpha = 1; }
    if (desc.press) { // pressed button glow
      const hp = HOTSPOT[desc.press.which];
      x.globalAlpha = desc.press.k * 0.45; x.fillStyle = '#fff'; x.beginPath(); x.roundRect((hp.x - hp.w / 2) * w, (hp.y - hp.h / 2) * h, hp.w * w, hp.h * h, 24); x.fill(); x.globalAlpha = 1;
    }
  } else if (desc.kind === 'viewfinder' || desc.kind === 'photo') {
    const im = A.photo; const s = Math.max(w / im.width, h / im.height) * (desc.kind === 'viewfinder' ? 1.0 + desc.z * 0.12 : 1.0);
    const dw = im.width * s, dh = im.height * s;
    x.drawImage(im, (w - dw) / 2 + (desc.ox || 0), (h - dh) / 2, dw, dh);
    // camera UI
    x.fillStyle = 'rgba(0,0,0,0.45)'; x.fillRect(0, 0, w, 150); x.fillRect(0, h - 330, w, 330);
    x.strokeStyle = 'rgba(255,255,255,0.35)'; x.lineWidth = 2;
    for (const f of [1 / 3, 2 / 3]) { x.beginPath(); x.moveTo(w * f, 150); x.lineTo(w * f, h - 330); x.stroke(); x.beginPath(); x.moveTo(0, 150 + (h - 480) * f); x.lineTo(w, 150 + (h - 480) * f); x.stroke(); }
    { const sx = w * 0.6, sy = h * 0.46; x.fillStyle = 'rgba(0,0,0,0.25)'; x.beginPath(); x.arc(sx, sy, 96, 0, 7); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.arc(sx, sy, 78, 0, 7); x.fill();
      x.strokeStyle = 'rgba(0,0,0,0.4)'; x.lineWidth = 6; x.beginPath(); x.arc(sx, sy, 64, 0, 7); x.stroke(); }
    x.fillStyle = BRAND.ambar; x.font = '34px UneCond'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('FOTO', w / 2, h - 300); x.fillStyle = 'rgba(255,255,255,0.7)'; x.fillText('VIDEO', w / 2 - 160, h - 300); x.textAlign = 'left';
    // focus square
    if (desc.kind === 'viewfinder') { x.strokeStyle = BRAND.ambar; x.lineWidth = 5; const fs = 160 - desc.z * 30; x.strokeRect(w / 2 - fs / 2, h * 0.46 - fs / 2, fs, fs); }
    if (desc.kind === 'photo') { // thumbnail
      x.save(); x.beginPath(); x.roundRect(70, h - 220, 110, 110, 16); x.clip(); x.drawImage(im, 70 - 40, h - 220, 190, 110); x.restore();
      x.strokeStyle = '#fff'; x.lineWidth = 4; x.beginPath(); x.roundRect(70, h - 220, 110, 110, 16); x.stroke();
    }
    if (desc.flash) { x.fillStyle = `rgba(255,255,255,${desc.flash})`; x.fillRect(0, 0, w, h); }
  }
  rig.screenTex.needsUpdate = true;
}

// ---------------------------------------------------------------- poses
const HH = HANDS;
// over-the-shoulder phone hold (right hand grips, phone at chest, screen tilted up toward his face)
const OTS = { rotY: Math.PI - 0.24, aimW: 1, phX: -0.16, phY: 0.8, phZ: 0.28, aimYaw: 3.9, aimPitch: -0.8, handR: HH.grip, handL: HH.relax,
  rThumbW: 1, rThumbX: 1.02, rThumbY: 0.42, rThumbLift: 0.006, headX: 0.16, headY: -0.22, eyeY: -0.6, eyeX: -0.35, smile: 0.6,
  lFwd: 0.12, lOut: 0.16, lElbow: -0.35, mic: 0 };
const P = {
  back: { rotY: Math.PI, rFwd: 0.25, rOut: 0.15, rElbow: -0.6, rWristX: 0.2, lFwd: 0.35, lOut: 0.12, lElbow: -1.0, headX: 0.05, handR: HH.grip, handL: HH.mic, lWristY: -1.2 },
  crouch: { rotY: 0.2, rFwd: 0.3, rOut: 0.25, rElbow: -0.9, lFwd: 0.35, lOut: 0.2, lElbow: -1.1, rKnee: 0.35, lKnee: 0.35, rLeg: 0.18, lLeg: 0.18, bob: -0.045, headX: 0.12, brow: 0.6, eyeScale: 1.05, handR: HH.grip, handL: HH.mic, mouthOpen: 0.2, round: 0.6, smile: 0 },
  surprised: { rFwd: 0.6, rOut: 0.65, rElbow: -1.75, rWristX: -0.2, lFwd: 0.6, lOut: 0.65, lElbow: -1.75, brow: 1, browTilt: 0.4, mouthOpen: 0.85, round: 0.9, eyeScale: 1.14, lidUp: 1, lean: -0.06, headX: -0.06, smile: 0, handR: HH.grip, handL: HH.mic, lWristY: -1.2 },
  excited: { rFwd: 0.7, rOut: 0.35, rElbow: -1.5, lFwd: 0.6, lOut: 0.3, lElbow: -1.6, brow: 0.7, mouthOpen: 0.5, eyeScale: 1.06, smile: 1, headZ: 0.08, handR: HH.grip, handL: HH.mic, lWristY: -1.2, squint: 0.1 },
  reportR: { rotY: 0, rFwd: 0.55, rOut: 0.9, rElbow: -0.55, rWristZ: 0.3, lFwd: 1.05, lOut: 0.25, lElbow: -1.75, headY: -0.32, eyeX: -0.7, mouthOpen: 0.4, smile: 1, handR: HH.grip, handL: HH.mic, lWristY: -1.2, squint: 0.1 },
  celebrate: { rFwd: 2.75, rOut: 0.55, rElbow: -0.35, lFwd: 2.75, lOut: 0.55, lElbow: -0.35, mouthOpen: 1, brow: 1, eyeScale: 1.08, smile: 1, squint: 0.5, handR: HH.grip, handL: HH.open, mic: 0 },
  thumbsUp: { rFwd: 0.7, rOut: 0.35, rElbow: -1.5, lFwd: 1.1, lOut: 0.25, lElbow: -1.85, mouthOpen: 0.45, smile: 1, squint: 0.25, headZ: 0.12, handR: HH.grip, handL: HH.thumbsUp, mic: 0, brow: 0.5 },
  wow: { phone: 0, mic: 0, rFwd: 0.95, rOut: 0.3, rElbow: -2.15, rWristX: -0.3, lFwd: 0.95, lOut: 0.3, lElbow: -2.15, lWristX: -0.3, headX: -0.32, eyeY: 0.9, mouthOpen: 0.75, round: 0.5, brow: 1, eyeScale: 1.1, lidUp: 0.8, handR: HH.open, handL: HH.open },
  pointR: { rFwd: 1.5, rOut: 0.85, rElbow: -0.15, rWristZ: 0.15, phone: 0, mic: 0, lFwd: 0.3, lOut: 0.15, lElbow: -0.9, smile: 1, headY: -0.3, eyeX: -0.6, handR: HH.point, handL: HH.relax },
  pointL: { lFwd: 1.5, lOut: 0.85, lElbow: -0.15, lWristZ: 0.15, rFwd: 0.3, rOut: 0.15, rElbow: -0.9, phone: 0, mic: 0, smile: 1, headY: 0.3, eyeX: 0.6, handL: HH.point, handR: HH.relax },
  present: { phone: 0, mic: 0, rFwd: 0.5, rOut: 0.5, rElbow: -1.2, lFwd: 0.5, lOut: 0.5, lElbow: -1.2, handR: HH.open, handL: HH.open, smile: 1, mouthOpen: 0.4, brow: 0.6 },
  laptop: { rFwd: 0.85, rOut: 0.12, rElbow: -0.85, lFwd: 0.85, lOut: 0.12, lElbow: -0.85, phone: 0, mic: 0, laptop: 1, smile: 1, headX: 0.05, handR: HH.tray, handL: HH.tray, squint: 0.1 },
  ots: OTS,
};
const pose = (name, extra = {}) => ({ ...DEFAULT_POSE, ...P[name], ...extra });

// blinks at fixed times
const BLINKS = [1.9, 5.2, 8.9, 12.4, 15.8, 19.9, 23.1, 27.0, 30.2, 33.4, 36.9, 40.3, 43.6, 47.1, 50.8, 54.2, 57.7, 60.0];
function blinkAt(t) { for (const b of BLINKS) { const d = t - b; if (d >= 0 && d < 0.16) return Math.sin(d / 0.16 * Math.PI); } return 0; }
// small eye darts (saccades), deterministic
const DARTS = (() => { const r = rng(9); const a = []; let t = 0; while (t < 63) { t += 0.8 + r() * 0.9; a.push([t, (r() - 0.5) * 0.28, (r() - 0.5) * 0.18]); } return a; })();
function dartAt(t) { let x = 0, y = 0; for (let i = 0; i < DARTS.length; i++) { if (DARTS[i][0] > t) break; const k = Math.min(1, (t - DARTS[i][0]) / 0.05); const px = i ? DARTS[i - 1][1] : 0, py = i ? DARTS[i - 1][2] : 0; x = px + (DARTS[i][1] - px) * k; y = py + (DARTS[i][2] - py) * k; } return [x, y]; }

// thumb typing over the text box, synced to the typing SFX taps
const TAPX = (i) => 0.5 + 0.24 * ((i * 0.618) % 1), TAPY = (i) => 0.465 + 0.03 * ((i * 0.382) % 1);
function typing(t) {
  const T = TYPING_TAPS;
  if (t < T[0] - 0.4 || t > T[T.length - 1] + 0.5) return null;
  if (t < T[0]) { const k = smooth(prog(t, T[0] - 0.4, T[0])); return { x: lerp(1.02, TAPX(0), k), y: lerp(0.42, TAPY(0), k), lift: lerp(0.006, 0.0, k) + 0.008 * Math.sin(k * Math.PI), w: 1 }; }
  if (t > T[T.length - 1]) { const k = smooth(prog(t, T[T.length - 1], T[T.length - 1] + 0.5)); const n = T.length - 1; return { x: lerp(TAPX(n), 1.02, k), y: lerp(TAPY(n), 0.42, k), lift: 0.008 * Math.sin(k * Math.PI) + 0.006 * k, w: 1 }; }
  let i = 0; while (i < T.length - 1 && T[i + 1] <= t) i++;
  const t0 = T[i], t1 = T[i + 1]; const u = clamp((t - t0) / (t1 - t0));
  const k = smooth(clamp((u - 0.15) / 0.7));
  return { x: lerp(TAPX(i), TAPX(i + 1), k), y: lerp(TAPY(i), TAPY(i + 1), k), lift: 0.009 * Math.sin(Math.min(1, u * 1.15) * Math.PI), w: 1 };
}
// left index presses a point of the screen: approach, press, release
function indexTap(t, tPress, x, y) {
  const a = tPress - 0.75, b = tPress + 0.75;
  if (t < a || t > b) return null;
  const w = t < tPress ? smooth(prog(t, a, tPress - 0.25)) : 1 - smooth(prog(t, tPress + 0.25, b));
  let lift;
  if (t < tPress) lift = 0.045 * (1 - easeOut(prog(t, tPress - 0.45, tPress)));
  else lift = t < tPress + 0.14 ? 0 : 0.035 * easeOut(prog(t, tPress + 0.14, tPress + 0.5));
  return { w, x, y, lift };
}

// ---------------------------------------------------------------- timeline: character pose
function basePose(t) {
  let p;
  if (t < 4.5) {
    p = track([
      [0, pose('back')], [0.55, pose('back', { headY: 0.55, eyeX: 0.6 })],
      [0.95, pose('crouch')], [1.25, pose('surprised', { rotY: 0 }), 'back'], [2.2, pose('surprised')],
      [2.7, pose('excited'), 'back'], [4.5, pose('excited', { headZ: -0.05 })],
    ], t);
    if (t > 0.95 && t < 1.55) { const k = prog(t, 0.95, 1.55); p.y = Math.sin(k * Math.PI) * 0.09; p.rKnee = p.lKnee = 0.35 * (1 - Math.sin(k * Math.PI)) * (k < 0.15 || k > 0.85 ? 1 : 0.2); }
  } else if (t < 11) {
    const photo = pose('ots', { mic: 1, handL: HH.mic, lWristY: -1.2, lFwd: 0.25, lElbow: -0.8 });
    p = track([
      [4.5, pose('excited')], [5.6, photo], [6.55, photo],
      [6.8, pose('ots', { mic: 1, handL: HH.mic, lWristY: -1.2, lFwd: 0.25, lElbow: -0.8, brow: 0.3 })], [7.6, pose('ots', { mic: 1, handL: HH.mic, lWristY: -1.2, lFwd: 0.25, lElbow: -0.8, mouthOpen: 0.3, smile: 1 })],
      [8.7, pose('reportR', { aimW: 0 }), 'back'], [10.3, pose('reportR', { headY: -0.15, mouthOpen: 0.3 })], [11, pose('ots', { mic: 0 })],
    ], t);
    // shutter press with the thumb at 6.8 (camera SFX)
    const sh = env(t, 6.25, 7.35, 0.35, 0.35);
    if (sh > 0) { p.rThumbX = lerp(1.02, 0.6, sh); p.rThumbY = lerp(0.42, 0.46, sh); const d = Math.abs(t - 6.8); p.rThumbLift = d < 0.06 ? 0 : Math.min(0.012, (d - 0.06) * 0.06); }
    p.mic = t < 10.9 ? 1 : 0;
  } else if (t < 25) {
    p = track([
      [11, pose('ots')], [18, pose('ots')], [20.2, pose('ots', { mouthOpen: 0.7, round: 0.4, brow: 0.9, eyeScale: 1.1, lidUp: 0.6, smile: 0.3 }), 'back'], [22.5, pose('ots', { smile: 1, mouthOpen: 0.3, squint: 0.4 })], [25, pose('ots')],
    ], t);
    const ty = typing(t);
    if (ty) { p.rThumbX = ty.x; p.rThumbY = ty.y; p.rThumbLift = ty.lift; p.mouthOpen = Math.max(p.mouthOpen, 0.08); }
    const tp = indexTap(t, 19.4, HOTSPOT.preparar.x, HOTSPOT.preparar.y);
    if (tp) { p.lTapW = tp.w; p.lTapX = tp.x; p.lTapY = tp.y; p.lLift = tp.lift; p.handL = mix(HH.relax, HH.tap, Math.min(1, tp.w * 1.5)); }
  } else if (t < 31) {
    p = track([
      [25, pose('ots')], [26.6, pose('ots', { mouthOpen: 0.6, smile: 1, brow: 0.8 })], [27.5, pose('ots', { mouthOpen: 0.5, smile: 1 })],
      [27.95, pose('crouch', { aimW: 0, handL: HH.open, mic: 0, rotY: 0 })], [28.3, pose('celebrate'), 'back'], [29.5, pose('celebrate', { headZ: 0.1 })],
      [30.1, pose('thumbsUp'), 'back'], [31, pose('thumbsUp')],
    ], t);
    const tp = indexTap(t, 25.95, HOTSPOT.subir.x, HOTSPOT.subir.y);
    if (tp) { p.lTapW = tp.w; p.lTapX = tp.x; p.lTapY = tp.y; p.lLift = tp.lift; p.handL = mix(HH.relax, HH.tap, Math.min(1, tp.w * 1.5)); }
    if (t > 28.3 && t < 29.8) { const k = prog(t, 28.3, 29.8); const j = Math.abs(Math.sin(k * Math.PI * 2)); p.y = j * 0.22; p.rKnee = p.lKnee = 0.35 * (1 - j); }
  } else if (t < 37) {
    p = track([[31, pose('wow')], [33.2, pose('wow', { headY: 0.25, eyeX: 0.4 })], [34.3, pose('wow', { headY: 0, eyeX: 0, mouthOpen: 0.4 })], [35.4, pose('wow', { headY: -0.25, eyeX: -0.4 })], [37, pose('wow', { mouthOpen: 0.3 })]], t);
  } else if (t < 44) {
    p = track([[37, pose('pointL', { headX: -0.15, lFwd: 0.6, lElbow: -1.2 })], [37.8, pose('pointL', { lFwd: 1.6, lOut: 1.0, headY: 0.45, eyeX: 0.8, headX: -0.1 }), 'back'], [43, pose('pointL', { lFwd: 1.55, lOut: 1.05, headY: 0.35, eyeX: 0.5, mouthOpen: 0.4 })], [44, pose('pointL')]], t);
  } else if (t < 50) {
    p = track([[44, pose('pointR', { rFwd: 0.6, rElbow: -1.2 })], [44.8, pose('pointR', { rFwd: 1.6, rOut: 1.0, headY: -0.45, eyeX: -0.8 }), 'back'], [46.5, pose('pointR', { rFwd: 1.6, rOut: 1.05, headY: -0.3, mouthOpen: 0.4 })], [49, pose('pointR', { rFwd: 1.5, rOut: 0.95, headY: -0.2, eyeX: 0 })], [50, pose('present')]], t);
  } else if (t < 56) {
    p = track([[50, pose('present')], [51.5, pose('present', { headX: -0.2, eyeY: 0.8, mouthOpen: 0.5 })], [54.5, pose('present', { headZ: 0.12, headX: -0.15 })], [56, pose('laptop', { laptop: 0 })]], t);
  } else {
    p = track([[56, pose('laptop', { laptop: 0.0 })], [56.35, pose('laptop', { laptop: 1 })], [58.6, pose('laptop', { headZ: 0.08 })], [60.5, pose('laptop', { mouthOpen: 0.6, brow: 0.6, squint: 0.6 }), 'back'], [62, pose('laptop', { mouthOpen: 0.3 })]], t);
    p.laptop = easeOutBack(prog(t, 56.0, 56.45));
  }
  // procedural life: breathing, weight shift, head drift
  p.bob = (p.bob || 0) + Math.sin(t * 2.4) * 0.006;
  p.sway = (p.sway || 0) + Math.sin(t * 0.85) * 0.012;
  p.torsoZ = (p.torsoZ || 0) + Math.sin(t * 1.3) * 0.012;
  p.headZ = (p.headZ || 0) + Math.sin(t * 1.1 + 1) * 0.025;
  p.headX = (p.headX || 0) + Math.sin(t * 1.7) * 0.012;
  const [dx, dy] = dartAt(t); p.eyeX = (p.eyeX || 0) + dx; p.eyeY = (p.eyeY || 0) + dy;
  p.blink = Math.max(p.blink || 0, blinkAt(t));
  p.z = CHAR_Z; if (t >= 31) p.z = 0;
  return p;
}
function poseAt(t) {
  const p = basePose(t);
  // secondary motion: hair and vest follow-through from head/body velocity
  const q = basePose(Math.max(0, t - 0.07));
  const vX = (p.headX - q.headX) + (p.torsoX + p.lean - q.torsoX - q.lean), vZ = (p.headZ - q.headZ) + (p.torsoZ - q.torsoZ);
  const vY = ((p.y || 0) - (q.y || 0)) + ((p.bob || 0) - (q.bob || 0));
  p.hairLagX = clamp(-vX * 1.6 + vY * 1.2, -0.12, 0.12); p.hairLagZ = clamp(-vZ * 1.6, -0.12, 0.12);
  p.vestLag = clamp(vY * 2.0, -0.15, 0.15);
  return p;
}

// ---------------------------------------------------------------- timeline: camera
// key: {p:[x,y,z], t:[x,y,z]} or {phone:{d, ox, oy}} (camera locked to the phone screen)
function phoneCam(d, ox = 0, oy = 0) {
  rig.root.updateMatrixWorld(true);
  const m = rig.phone.matrixWorld;
  const c = new THREE.Vector3().setFromMatrixPosition(m);
  const n = new THREE.Vector3(0, 0, 1).transformDirection(m);
  const up = new THREE.Vector3(0, 1, 0).transformDirection(m);
  const right = new THREE.Vector3(1, 0, 0).transformDirection(m);
  up.lerp(new THREE.Vector3(0, 1, 0), 0.5).normalize();
  const target = c.clone().addScaledVector(right, ox).addScaledVector(up, oy);
  return { p: target.clone().addScaledVector(n, d).toArray(), t: target.toArray(), up: up.toArray() };
}
function resolveCam(k) { return k.phone ? phoneCam(k.phone.d, k.phone.ox, k.phone.oy) : { p: k.p, t: k.t, up: k.up || [0, 1, 0] }; }
const CAM = [
  [0.0, { p: [0.9, 1.6, 9.5], t: [0, 0.9, 1.0] }],
  [1.3, { p: [0.05, 1.0, 5.75], t: [0, 1.05, CHAR_Z] }],
  [4.4, { p: [0.1, 1.02, 5.35], t: [0, 1.05, CHAR_Z] }],
  [5.15, { p: [1.3, 1.45, 4.3], t: [0.15, 0.95, 1.8] }],
  [5.9, { phone: { d: 0.86, ox: 0.0, oy: 0.024 } }],
  [7.3, { phone: { d: 0.8, ox: 0.0, oy: 0.024 } }],
  [8.8, { p: [-0.35, 1.05, 5.6], t: [0.42, 1.05, CHAR_Z] }],
  [10.6, { p: [-0.3, 1.07, 5.4], t: [0.4, 1.05, CHAR_Z] }],
  [11.9, { phone: { d: 0.84, ox: 0.0, oy: 0.024 } }],
  [17.8, { phone: { d: 0.82, ox: 0.0, oy: 0.024 } }],
  [20.6, { phone: { d: 0.88, ox: 0.0, oy: 0.024 } }],
  [24.8, { phone: { d: 0.84, ox: 0.0, oy: 0.024 } }],
  [26.4, { phone: { d: 0.84, ox: 0.0, oy: 0.024 } }],
  [27.8, { p: [0.0, 1.12, 6.0], t: [0, 1.3, CHAR_Z] }],
  [30.9, { p: [0.0, 1.14, 5.7], t: [0, 1.3, CHAR_Z] }],
  // studio (character at origin) — head at bottom, space above for graphics
  [31.0, { p: [0.0, 1.55, 5.0], t: [0.0, 1.92, 0] }],
  [36.9, { p: [0.0, 1.5, 4.7], t: [0.0, 1.88, 0] }],
  [37.0, { p: [-0.55, 1.18, 3.3], t: [0.45, 1.05, 0] }],
  [43.9, { p: [-0.6, 1.2, 3.15], t: [0.45, 1.05, 0] }],
  [44.0, { p: [0.6, 1.18, 3.3], t: [-0.45, 1.05, 0] }],
  [49.9, { p: [0.65, 1.2, 3.15], t: [-0.45, 1.05, 0] }],
  [50.0, { p: [0.0, 1.9, 3.3], t: [0.0, 2.08, 0] }],
  [55.9, { p: [0.0, 1.85, 3.15], t: [0.0, 2.04, 0] }],
  [56.0, { p: [0.0, 1.05, 4.2], t: [0.0, 1.17, 0] }],
  [58.5, { p: [0.0, 1.06, 4.05], t: [0.0, 1.16, 0] }],
  [59.3, { p: [0.0, 1.25, 4.6], t: [0.0, 1.62, 0] }],
  [62.0, { p: [0.0, 1.25, 4.4], t: [0.0, 1.6, 0] }],
];
const CUTS = [31.0, 37.0, 44.0, 50.0, 56.0];
function camAt(t) {
  let i = 0; while (i < CAM.length - 1 && t > CAM[i + 1][0]) i++;
  const [t0, k0] = CAM[i], [t1, k1] = CAM[Math.min(i + 1, CAM.length - 1)];
  const a = resolveCam(k0), b = resolveCam(k1);
  const cut = CUTS.some(c => Math.abs(c - t1) < 1e-6 && t1 - t0 < 0.2);
  let k = t1 > t0 ? easeInOut((t - t0) / (t1 - t0)) : 0;
  if (cut) k = 0;
  return { p: mix(a.p, b.p, k), t: mix(a.t, b.t, k), up: mix(a.up, b.up, k) };
}

// ---------------------------------------------------------------- background
const BOKEH = (() => { const r = rng(42); return Array.from({ length: 26 }, () => ({ x: r() * 1080, y: r() * 1920, r: 30 + r() * 110, c: [BRAND.cian, BRAND.azul, BRAND.ambar, '#ffffff'][Math.floor(r() * 4)], a: 0.05 + r() * 0.12, sp: 0.2 + r() * 0.6, ph: r() * 6 })); })();
function drawBG(t, studioOn) {
  const x = bgg; x.setTransform(SC, 0, 0, SC, 0, 0);
  const gr = x.createLinearGradient(0, 0, 0, 1920);
  if (studioOn) { gr.addColorStop(0, BRAND.marino); gr.addColorStop(0.55, '#1d4f8f'); gr.addColorStop(1, BRAND.azul); }
  else { gr.addColorStop(0, BRAND.marino); gr.addColorStop(0.35, '#1a467f'); gr.addColorStop(0.62, '#4C8FE2'); gr.addColorStop(1, '#a9c6ea'); }
  x.fillStyle = gr; x.fillRect(0, 0, 1080, 1920);
  x.globalCompositeOperation = 'lighter';
  for (const b of BOKEH) {
    const yy = ((b.y - t * 18 * b.sp) % 1920 + 1920) % 1920; const xx = b.x + Math.sin(t * 0.4 + b.ph) * 20;
    const rg = x.createRadialGradient(xx, yy, 0, xx, yy, b.r);
    const al = b.a * (0.7 + 0.3 * Math.sin(t * 1.3 + b.ph));
    rg.addColorStop(0, hexA(b.c, al)); rg.addColorStop(0.7, hexA(b.c, al * 0.6)); rg.addColorStop(1, hexA(b.c, 0));
    x.fillStyle = rg; x.beginPath(); x.arc(xx, yy, b.r, 0, 7); x.fill();
  }
  x.globalCompositeOperation = 'source-over';
}
function hexA(h, a) { const n = parseInt(h.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }
function vignette(x) {
  const rg = x.createRadialGradient(540, 900, 500, 540, 960, 1250);
  rg.addColorStop(0, 'rgba(6,18,31,0)'); rg.addColorStop(1, 'rgba(6,18,31,0.55)');
  x.fillStyle = rg; x.fillRect(0, 0, 1080, 1920);
  // top darkening so the mark always reads
  const tg = x.createLinearGradient(0, 0, 0, 300); tg.addColorStop(0, 'rgba(6,18,31,0.55)'); tg.addColorStop(1, 'rgba(6,18,31,0)');
  x.fillStyle = tg; x.fillRect(0, 0, 1080, 300);
}

// ---------------------------------------------------------------- per-frame 3D graphics
function setCardGloss(card, t) { card.face.material.opacity = 1; }
function updateHud(t) {
  // coin (S1 click, S4 click)
  coin.grp.visible = false;
  const coinShow = (t0, t1, x, y) => {
    if (t < t0 || t > t1) return false;
    const s = pop(prog(t, t0, t0 + 0.5)) * (t > t1 - 0.15 ? 1 - prog(t, t1 - 0.15, t1) : 1);
    const press = t > t1 - 0.32 ? Math.sin(prog(t, t1 - 0.32, t1 - 0.15) * Math.PI) * 0.18 : 0;
    coin.grp.visible = true;
    hudPlace(coin.grp, x, y + Math.sin(t * 3) * 8, 250 * s * (1 - press), 2.2);
    coin.spin.rotation.y = Math.sin(t * 2.2) * 0.5 + (1 - prog(t, t0, t0 + 0.6)) * 6;
    coin.spin.rotation.x = 0.15 + Math.sin(t * 1.7) * 0.12;
    return true;
  };
  coinShow(1.9, 2.95, 760, 1330);
  // photo card: pops out of the phone at 7.5 → floats right → returns 10.7
  photoCard.grp.visible = false;
  if (t > 7.45 && t < 11.0) {
    photoCard.grp.visible = true;
    const sp = rig.phone.getWorldPosition(new THREE.Vector3());
    const from = toPx(sp);
    const k = easeOutBack(prog(t, 7.45, 8.25), 1.2);
    const tx = 735, ty = 1020;
    const out = easeIn(prog(t, 10.55, 11.0));
    let x = lerp(from.x, tx, k), y = lerp(from.y, ty, k), hpx = lerp(60, 380, clamp(k));
    x = lerp(x, from.x, out); y = lerp(y, from.y, out); hpx = lerp(hpx, 40, out);
    hudPlace(photoCard.grp, x, y + Math.sin(t * 2) * 6, hpx, 2.0);
    photoCard.inner.rotation.set(0.12 + Math.sin(t * 1.4) * 0.06, -0.25 + Math.sin(t * 1.1) * 0.12, 0.12 - (1 - clamp(k)) * 0.6);
  }
  // post card: from phone at 20.9 → big center → back at 24.6; S5: flies up at 26.2
  postCard.grp.visible = false;
  if (t > 20.9 && t < 24.9) {
    postCard.grp.visible = true;
    const from = toPx(rig.phone.getWorldPosition(new THREE.Vector3()));
    const k = easeOutBack(prog(t, 20.9, 21.7), 1.1); const out = easeIn(prog(t, 24.45, 24.9));
    let x = lerp(from.x, 540, k), y = lerp(from.y, 905, k), hpx = lerp(120, 800, clamp(k));
    x = lerp(x, from.x, out); y = lerp(y, from.y, out); hpx = lerp(hpx, 80, out);
    hudPlace(postCard.grp, x, y + Math.sin(t * 2) * 6, hpx, 0.42);
    postCard.inner.rotation.set(0.05 + Math.sin(t * 1.3) * 0.05, Math.sin((t - 21) * 0.9) * 0.32, (1 - clamp(k)) * 0.4 - 0.02);
  } else if (t > 26.15 && t < 27.4) {
    postCard.grp.visible = true;
    const from = toPx(rig.phone.getWorldPosition(new THREE.Vector3()));
    const k = easeIn(prog(t, 26.15, 27.2));
    const kk = easeOut(prog(t, 26.15, 26.45));
    hudPlace(postCard.grp, lerp(from.x, 600, kk), lerp(from.y, 700, kk) - k * 1500, lerp(200, 560, kk) * (1 - k * 0.4), 0.42);
    postCard.inner.rotation.set(-0.3 * k, k * 2.2, 0.1 - k * 0.3);
  }
  // style cards S6
  styleCards.forEach(c => c.grp.visible = false);
  if (t > 31.15 && t < 37.0) {
    const names = [0, 1, 2];
    names.forEach((i) => {
      const c = styleCards[i]; c.grp.visible = true;
      const t0 = 31.25 + i * 0.22;
      const k = easeOutBack(prog(t, t0, t0 + 0.7), 1.3);
      const out = easeIn(prog(t, 36.6, 37.0));
      const spread = easeInOut(prog(t, 32.0, 32.8));
      const xs = [270, 540, 810][i], rot = [-0.16, 0, 0.16][i];
      const focus = [33.2, 34.3, 35.4][i];
      const f = env(t, focus, focus + 1.2, 0.3, 0.3);
      const x = lerp(540, xs, spread);
      const y = lerp(1500, 830, k) - f * 30 + Math.sin(t * 1.8 + i) * 8 + out * -900;
      const hp = 520 + f * 90 + (i === 1 ? 30 : 0);
      hudPlace(c.grp, x, y, hp * (1 - out * 0.3), 2.2 - (i === 1 ? 0.05 : 0) - f * 0.1);
      c.inner.rotation.set(0.05 + Math.sin(t * 1.2 + i) * 0.05, lerp(0, [0.42, 0, -0.42][i], spread) * (1 - f) + Math.sin(t * 0.9 + i * 2) * 0.12, rot * spread * (1 - f * 0.6));
    });
  }
  // video phone S7
  vidPhone.grp.visible = false;
  if (t > 37.0 && t < 44.0) {
    vidPhone.grp.visible = true;
    const k = easeOutBack(prog(t, 37.15, 37.85), 1.2); const out = easeIn(prog(t, 43.6, 44.0));
    hudPlace(vidPhone.grp, 735 + (1 - k) * 500, 905 + out * -1200, 800, 2.2);
    vidPhone.inner.rotation.set(0.04 + Math.sin(t * 1.1) * 0.04, -0.2 + Math.sin(t * 0.8) * 0.1, 0.03);
    newsFrame(vidPhone.ctx, Math.max(0, t - 37.2), 540, 960, 43.9 - 37.2); vidPhone.tex.needsUpdate = true;
  }
  // sponsor card S8
  sponsorCard.grp.visible = false;
  if (t > 44.0 && t < 50.0) {
    sponsorCard.grp.visible = true;
    const k = easeOutBack(prog(t, 44.15, 44.85), 1.2); const out = easeIn(prog(t, 49.6, 50.0));
    hudPlace(sponsorCard.grp, 320 - (1 - k) * 500, 890 + out * -1200, 640, 2.2);
    sponsorCard.inner.rotation.set(0.05 + Math.sin(t * 1.1) * 0.04, 0.22 + Math.sin(t * 0.8) * 0.1, -0.03);
    drawSponsor(t);
  }
  // hero logo plate: drops in on the 60.5 s hit with glow, gloss sweep and reflection
  logoPlate.grp.visible = false;
  if (t > 60.05) {
    logoPlate.grp.visible = true;
    const k = prog(t, 60.05, 60.5);
    const y = lerp(-250, 455, easeIn(k)) + (t > 60.5 ? -Math.exp(-(t - 60.5) * 6) * Math.sin((t - 60.5) * 20) * 22 : 0);
    const sq = t > 60.5 ? Math.exp(-(t - 60.5) * 7) * Math.sin((t - 60.5) * 22) * 0.06 : 0;
    hudPlace(logoPlate.grp, 540, y, 330, 2.0);
    logoPlate.inner.scale.set(1 + sq, 1 - sq, 1);
    logoPlate.inner.rotation.set(0.06 + Math.sin(t * 1.3) * 0.04, Math.sin(t * 0.9) * 0.18 * (1 - Math.exp(-Math.max(0, t - 60.5) * 2)), -0.03);
    logoPlate.glow.material.opacity = t > 60.5 ? 0.55 + 0.45 * Math.exp(-(t - 60.5) * 3) : 0.2 * k;
    logoPlate.sweep.material.opacity = t > 60.6 ? 0.9 * Math.sin(Math.min(1, (t - 60.6) / 0.7) * Math.PI) : 0;
    logoPlate.sweep.material.map.offset.x = -0.6 + Math.min(1, Math.max(0, (t - 60.6) / 0.7)) * 1.2;
  }
}
const SPONSORS = ['TU NEGOCIO AQUÍ', 'ESPACIO PATROCINADO', 'TU MARCA EN CADA NOTICIA', 'ANUNCIA CON NOSOTROS'];
function drawSponsor(t) {
  const c = sponsorCard, x = c.ctx, w = c.cv.width, h = c.cv.height;
  x.drawImage(A.posts.clasico, 0, 0, w, h);
  // sponsor ribbon (scrolling)
  const rh = 74, ry = h - rh - 70;
  x.fillStyle = BRAND.ambar; x.fillRect(0, ry, w, rh);
  x.fillStyle = BRAND.noche; x.fillRect(0, ry, 170, rh);
  x.fillStyle = '#fff'; x.font = '26px UneCond'; x.textBaseline = 'middle'; x.fillText('PATROCINA', 20, ry + rh / 2);
  x.save(); x.beginPath(); x.rect(170, ry, w - 170, rh); x.clip();
  x.fillStyle = BRAND.noche; x.font = '34px UneDisplay';
  const txt = SPONSORS.join('   •   ') + '   •   ';
  const tw = x.measureText(txt).width; const off = ((t - 44) * 120) % tw;
  for (let k = -1; k < 3; k++) x.fillText(txt, 190 - off + k * tw, ry + rh / 2 + 2);
  x.restore();
  // logo bug
  x.fillStyle = 'rgba(6,18,31,0.75)'; x.beginPath(); x.roundRect(w - 220, 30, 190, 64, 14); x.fill();
  x.font = '30px UneDisplay'; x.fillStyle = '#fff'; x.textAlign = 'center'; x.fillText('TU LOGO', w - 125, 64); x.textAlign = 'left';
  c.tex.needsUpdate = true;
}

// ---------------------------------------------------------------- phone screen per time
function screenAt(t) {
  if (t < 5.6) return { kind: 'app', a: 1, k: 0 };
  if (t < 6.85) return { kind: 'viewfinder', z: smooth(prog(t, 5.8, 6.8)), ox: Math.sin(t * 3) * 6 };
  if (t < 7.15) return { kind: 'photo', flash: Math.round((1 - prog(t, 6.85, 7.15)) * 10) / 10 };
  if (t < 10.9) return { kind: 'photo' };
  if (t < 11.6) return { kind: 'app', a: 1, b: 2, k: Math.round(smooth(prog(t, 10.9, 11.4)) * 15) / 15 };
  if (t < 12.0) return { kind: 'app', a: 2, k: 0 };
  if (t < 12.45) return { kind: 'app', a: 2, b: 3, k: Math.round(smooth(prog(t, 12.0, 12.4)) * 15) / 15 };
  if (t < 14.6) return { kind: 'app', a: 3, k: 0 };
  if (t < 15.05) return { kind: 'app', a: 3, b: 4, k: Math.round(smooth(prog(t, 14.6, 15.0)) * 15) / 15 };
  if (t < 19.75) return { kind: 'app', a: 4, k: 0, press: t > 19.38 ? { which: 'preparar', k: Math.round(Math.sin(prog(t, 19.38, 19.7) * Math.PI) * 6) / 6 } : null };
  if (t < 20.4) return { kind: 'app', a: 4, b: 5, k: Math.round(smooth(prog(t, 19.75, 20.3)) * 15) / 15 };
  if (t < 24.6) return { kind: 'app', a: 5, k: 0 };
  if (t < 25.2) return { kind: 'app', a: 5, b: 6, k: Math.round(smooth(prog(t, 24.6, 25.1)) * 15) / 15 };
  return { kind: 'app', a: 6, k: 0, press: t > 25.93 && t < 26.25 ? { which: 'subir', k: Math.round(Math.sin(prog(t, 25.93, 26.25) * Math.PI) * 6) / 6 } : null };
}
function phoneHotspotPx(which) {
  const hp = HOTSPOT[which];
  const v = new THREE.Vector3((hp.x - 0.5) * PHONE.SW, (0.5 - hp.y) * PHONE.SH, PHONE.T / 2 + 0.001);
  rig.phone.localToWorld(v);
  return toPx(v);
}

// ---------------------------------------------------------------- overlay timeline
const ORANGE = [BRAND.ambar, BRAND.naranja];
const FIRE = [BRAND.ambar, BRAND.naranja, BRAND.brasa];
function drawOverlay(t) {
  g.setTransform(SC, 0, 0, SC, 0, 0);
  g.clearRect(0, 0, 1080, 1920);
  vignette(g);

  // ---- S1 hook
  O.sticker(g, t, { t0: 0.55, t1: 4.45, x: 540, y: 430, rot: -4, lines: ['¿LA NOTICIA ESTÁ', 'PASANDO AHORA?'], size: 80, face: FIRE, side: '#7a1e10', maxW: 960 });
  // cursor clicks the coin at 2.65
  if (t > 2.1 && t < 3.1) {
    const k = easeOut(prog(t, 2.1, 2.55));
    const press = env(t, 2.55, 2.85, 0.08, 0.15);
    O.cursor(g, lerp(1150, 800, k), lerp(1650, 1360, k), 1.05, press, 1 - prog(t, 2.95, 3.1));
  }
  O.ripple(g, 760, 1330, t - 2.7);
  burst(g, t - 2.85, 760, 1330);
  O.sticker(g, t, { t0: 2.85, t1: 4.45, x: 560, y: 1390, rot: 4, lines: [[['PUBLÍCALA EN ', null], ['1 MINUTO', FIRE]]], size: 74, face: ['#ffffff', '#e4f2ff'], side: '#0B2238', textFace: [BRAND.marino, '#163d66'], textSide: 'rgba(8,225,255,0.9)', textDepth: 6, maxW: 980 });

  // ---- S2..S5 step banners
  O.banner(g, t, { t0: 4.55, t1: 10.9, num: 1, lines: ['TOMA LA FOTO O', 'GRABA EL VIDEO'], y: 375 });
  O.banner(g, t, { t0: 11.0, t1: 17.9, num: 2, lines: ['ESCRIBE', 'LO QUE PASÓ'], y: 375, rot: 2 });
  O.banner(g, t, { t0: 18.0, t1: 24.9, num: 3, lines: ['EL SISTEMA ARMA', 'LA NOTICIA SOLO'], y: 375 });
  O.banner(g, t, { t0: 25.0, t1: 26.95, num: 4, lines: ['SOLO DALE', 'SUBIR'], y: 375, rot: 2 });

  // flash
  if (t > 6.83 && t < 7.25) { g.fillStyle = `rgba(255,255,255,${(1 - prog(t, 6.83, 7.25)) * 0.75})`; g.fillRect(0, 0, 1080, 1920); }
  // S3 note
  O.note(g, t, { t0: 13.0, t1: 17.9, x: 540, y: 1562, rot: -3, lines: ['Tal como te llegó la información'], size: 46, maxW: 700 });
  // S3: thumb taps while typing (synced to the typing SFX)
  for (const tt of TYPING_TAPS) { const d = t - tt; if (d >= 0 && d < 0.28 && TIPS.thumb) tapRing(g, TIPS.thumb.x, TIPS.thumb.y, d / 0.28); }
  // S4: the index finger presses "Preparar noticia"
  if (t > 19.38 && t < 19.8 && TIPS.index) O.ripple(g, TIPS.index.x, TIPS.index.y, t - 19.42, BRAND.ambar);
  O.list(g, t, { t0: 21.6, t1: 24.9, x: 90, y: 1350, lines: ['– TITULAR', '– TEXTO PARA FACEBOOK', '– DISEÑO CON TU MARCA'], size: 70, step: 0.5, maxW: 900 });
  // S5: the index finger taps the finished post
  if (t > 25.93 && t < 26.35 && TIPS.index) O.ripple(g, TIPS.index.x, TIPS.index.y, t - 25.97, BRAND.cian);
  reactions(g, t);
  O.sticker(g, t, { t0: 27.0, t1: 30.75, x: 540, y: 470, rot: -5, lines: ['¡PUBLICADO!'], size: 110, face: ['#3DE0FF', '#3B71FB'], side: '#0B2238', maxW: 900 });

  // ---- S6 styles
  O.sticker(g, t, { t0: 31.15, t1: 36.9, x: 540, y: 360, rot: -3, lines: ['ELIGE EL ESTILO'], size: 84, face: FIRE, side: '#7a1e10', maxW: 960 });
  const labels = [['CLÁSICO', 270, -6, [BRAND.azul, '#2c63b0']], ['CRISTAL 3D', 540, 3, [BRAND.cian, '#06a9c4']], ['IMPACTO 4D', 810, -4, FIRE]];
  labels.forEach(([txt, x, r, face], i) => {
    const f = env(t, [33.2, 34.3, 35.4][i], [33.2, 34.3, 35.4][i] + 1.2, 0.3, 0.3);
    O.sticker(g, t, { t0: 32.4 + i * 0.25, t1: 36.9, x, y: 1150 + f * 6, rot: r, lines: [txt], fam: O.FONTS.cond, italic: true, size: 58 * (1 + f * 0.12), face, side: '#06121F', maxW: 255, padX: 22, padY: 14, depth: 12, rimW: 4 });
  });

  // ---- S7 video
  O.sticker(g, t, { t0: 37.1, t1: 43.9, x: 540, y: 372, rot: -3, lines: ['VIDEO NOTICIA CON', 'CORTINA Y SONIDO'], size: 70, face: [BRAND.rojo, '#a80f2c'], side: '#4a0612', maxW: 980 });
  O.note(g, t, { t0: 37.7, t1: 43.9, x: 250, y: 560, rot: -5, lines: ['Plan Pro'], size: 56 });
  O.list(g, t, { t0: 39.0, t1: 43.9, x: 70, y: 1330, lines: ['– VARIAS FOTOS EN UN VIDEO', '– CORTINAS DE NOTICIERO', '– EFECTOS DE SONIDO'], size: 66, step: 0.55, maxW: 920 });

  // ---- S8 publicidad
  O.sticker(g, t, { t0: 44.1, t1: 49.9, x: 540, y: 372, rot: 3, lines: ['VENDE PUBLICIDAD'], size: 82, face: FIRE, side: '#7a1e10', maxW: 980 });
  O.list(g, t, { t0: 45.4, t1: 49.9, x: 70, y: 1330, lines: ['– CINTAS DE PATROCINADORES', '– VIDEOS SUELTOS UNIDOS', '– CON TU LOGO Y TUS COLORES'], size: 66, step: 0.55, maxW: 940 });

  // ---- S9 planes
  O.sticker(g, t, { t0: 50.1, t1: 55.9, x: 540, y: 360, rot: -3, lines: ['PLANES'], size: 96, face: ['#6f9bff', '#3B71FB'], side: '#0B2238', maxW: 900 });
  const plans = [['BÁSICO', 'L 990', [BRAND.azul, '#2c63b0'], '#0B2238'], ['PREMIUM', 'L 1,990', [BRAND.cian, '#06a9c4'], '#0B2238'], ['PRO', 'L 3,490', FIRE, '#7a1e10']];
  plans.forEach(([name, price, face, side], i) => {
    const y = 600 + i * 215;
    O.sticker(g, t, { t0: 50.6 + i * 0.45, t1: 55.9, x: 540 + (i - 1) * 18, y, rot: [-3, 2, -2][i], lines: [[[name + '  ', [ '#ffffff', '#e8f6ff']], [price, i === 2 ? ['#ffffff', '#fff1d6'] : [BRAND.ambar, BRAND.naranja]], ['/mes', ['#ffffff', '#dfefff']]]], size: 70, face, side, maxW: 900, w: 860, h: 170, textSide: '#06121F' });
  });
  O.note(g, t, { t0: 52.4, t1: 55.9, x: 540, y: 1270, rot: -2, lines: ['Instalación única desde L 2,000', 'Pago anual: 2 meses gratis'], size: 50, maxW: 760 });

  // ---- S10 close
  O.sticker(g, t, { t0: 56.05, t1: 58.75, x: 540, y: 335, rot: -4, lines: ['ENVÍA TU LOGO'], size: 92, face: FIRE, side: '#7a1e10', maxW: 960 });
  O.sticker(g, t, { t0: 56.45, t1: 58.75, x: 540, y: 475, rot: 3, lines: [[['EN ', null], ['48 HORAS', FIRE], [' TIENES', null]]], size: 64, face: ['#ffffff', '#e4f2ff'], side: '#0B2238', textFace: [BRAND.marino, '#163d66'], textSide: 'rgba(8,225,255,0.9)', textDepth: 5, maxW: 980 });
  O.sticker(g, t, { t0: 56.75, t1: 58.75, x: 540, y: 580, rot: -2, lines: ['TU SISTEMA'], size: 64, face: [BRAND.cian, BRAND.azul], side: '#0B2238', maxW: 700 });
  // domain sticker (round font, bouncing)
  if (t > 58.8) {
    const bounce = Math.abs(Math.sin((t - 58.8) * 3.2)) * 18 * Math.exp(-(t - 58.8) * 0.5);
    const hit = env(t, 60.5, 61.1, 0.06, 0.5) * 0.08;
    g.save(); g.translate(540, 735 - bounce); g.scale(1 + hit, 1 + hit); g.translate(-540, -735);
    O.sticker(g, t, { t0: 58.8, t1: 62.5, x: 540, y: 735, rot: -3, lines: [[['proaudih', ['#ffffff', '#e8f0ff']], ['.com', ['#3DE0FF', '#7fb0ff']]]], fam: O.FONTS.logo, size: 112, face: ['#0d1e3d', '#0A0F1E'], side: '#020a12', rim: '#3B71FB', rimW: 7, maxW: 900, textSide: '#020a12' });
    g.restore();
  }
  O.sticker(g, t, { t0: 59.3, t1: 62.5, x: 540, y: 875, rot: 0, lines: ['Escríbenos y pide tu demostración'], fam: O.FONTS.text, size: 54, face: ['#ffffff', '#e8f1fb'], side: '#0B2238', textFace: [BRAND.marino, '#0B2238'], textSide: 'rgba(0,0,0,0)', textDepth: 0, maxW: 960, padY: 22, rimW: 0 });

  // transition wipe into the studio
  wipe(g, t, 30.72, 31.3);
  O.topMark(g, A.logo);
}

const TIPS = {};
function tapRing(x, cx, cy, k) {
  x.save(); x.globalAlpha = (1 - k) * 0.9; x.strokeStyle = BRAND.cian; x.lineWidth = 6 * (1 - k) + 1.5;
  x.beginPath(); x.arc(cx, cy, 10 + k * 34, 0, 7); x.stroke();
  x.globalAlpha = (1 - k) * 0.5; x.fillStyle = '#ffffff'; x.beginPath(); x.arc(cx, cy, 9 * (1 - k), 0, 7); x.fill(); x.restore();
}
function burst(x, dt, cx, cy) {
  if (dt < 0 || dt > 0.7) return;
  const r = rng(5);
  x.save();
  for (let i = 0; i < 18; i++) {
    const a = r() * Math.PI * 2, sp = 300 + r() * 500, k = dt;
    const px = cx + Math.cos(a) * sp * k, py = cy + Math.sin(a) * sp * k + 600 * k * k;
    x.globalAlpha = 1 - dt / 0.7; x.fillStyle = [BRAND.ambar, '#fff3b0', BRAND.naranja][i % 3];
    x.beginPath(); x.arc(px, py, 10 * (1 - k), 0, 7); x.fill();
  }
  x.restore();
}
function reactions(x, t) {
  if (t < 26.5 || t > 30.8) return;
  const r = rng(11);
  const kinds = ['heart', 'like', 'comment', 'heart', 'star', 'like', 'heart', 'comment', 'like', 'heart', 'star', 'heart', 'like', 'comment'];
  kinds.forEach((kd, i) => {
    const t0 = 26.55 + i * 0.16 + r() * 0.1; const life = 1.9 + r() * 0.8;
    const k = (t - t0) / life; if (k < 0 || k > 1) return;
    const side = i % 2 ? 1 : -1; const sx = 540 + side * (230 + r() * 260); const drift = (r() - 0.5) * 160;
    const y = 1650 - easeOut(k) * (900 + r() * 400);
    const s = pop(clamp(k * 4)) * (0.8 + r() * 0.5) * (1 - easeIn(clamp((k - 0.8) / 0.2)));
    O.reaction(x, kd, sx + drift * k + Math.sin(k * 8 + i) * 18, y, s, 1);
  });
}
function wipe(x, t, t0, t1) {
  if (t < t0 || t > t1) return;
  const k = (t - t0) / (t1 - t0);
  const cols = [BRAND.cian, BRAND.azul, BRAND.marino, BRAND.naranja, BRAND.ambar];
  x.save(); x.translate(540, 960); x.rotate(-0.35);
  cols.forEach((c, i) => {
    const d = i * 0.06; const kk = easeInOut(clamp((k - d) / (1 - 0.24)));
    const xx = lerp(-2400, 2400, kk);
    x.fillStyle = c; x.fillRect(xx - 1200 + (i - 2) * 90, -1600, 1700 - i * 120, 3200);
  });
  x.restore();
}

// ---------------------------------------------------------------- render
function render(t) {
  t = clamp(t, 0, DUR);
  const studioOn = t >= 31.0;
  street.visible = !studioOn; studio.visible = studioOn;
  scene.fog = studioOn ? null : FOG_STREET;
  // light framing
  if (studioOn) { lights.key.position.set(-3, 6, 5); lights.key.target.position.set(0, 0.6, 0); lights.rim.position.set(4, 4, -5); lights.hemi.intensity = 1.9; }
  else { lights.key.position.set(-7, 8, 2.5); lights.key.target.position.set(0, 0, 0); lights.rim.position.set(5, 4, -8); lights.hemi.intensity = 1.6; }
  const sc = lights.key.shadow.camera;
  if (studioOn) { sc.left = -2; sc.right = 2; sc.top = 3; sc.bottom = -1; } else { sc.left = -7; sc.right = 7; sc.top = 7; sc.bottom = -7; }
  sc.updateProjectionMatrix();

  rig.setPose(poseAt(t));
  drawScreen(screenAt(t));
  rig.lapTex.needsUpdate = false;

  const c = camAt(t);
  camera.position.fromArray(c.p); camera.up.fromArray(c.up).normalize(); camera.lookAt(new THREE.Vector3().fromArray(c.t));
  camera.updateMatrixWorld(true);
  rig.root.updateMatrixWorld(true);
  updateHud(t);
  // fingertip screen positions for touch feedback
  if (t > 12 && t < 17) { const v = rig.arms.r.H.thumb.tip.getWorldPosition(new THREE.Vector3()); TIPS.thumb = toPx(v); } else TIPS.thumb = null;
  if ((t > 19 && t < 20.2) || (t > 25.5 && t < 26.7)) { const v = rig.arms.l.H.fingers.i.tip.getWorldPosition(new THREE.Vector3()); TIPS.index = toPx(v); } else TIPS.index = null;
  drawBG(t, studioOn);
  renderer.render(scene, camera);
  drawOverlay(t);
}

window.ready = init().then(() => { render(0); return true; });
window.render = (t) => render(t);
window.DUR = DUR;
window.missingAssets = () => A.missing;
