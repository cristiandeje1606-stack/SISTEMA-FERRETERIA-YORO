// Estudio de Noticias — 62 s vertical 3D explainer. Deterministic: window.render(t) draws exactly time t.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildStreet, buildLights, glowTex } from './set.js';
import { buildReporter, DEFAULT_POSE, HANDS, PHONE } from './character.js';
const SHUTTER = { x: 0.8, y: 0.56 };
import { TYPING_TAPS, TYPED_TEXT, TAP_CHARS, keyOfChar, typedTextAt } from './typing.js';
import { A, HOTSPOT, loadAssets, newsFrame } from './screens.js';
import * as S from './screens.js';
import * as O from './overlay.js';
import { rng, clamp, lerp, smooth, easeInOut, easeOut, easeIn, easeOutBack, pop, prog, env, track, mix, BRAND, easeInOutQuad, easeOutExpo, easeInCubic, easeOut as easeOutCubic, fbm, noise1, trackCh } from './util.js';

const Q = new URLSearchParams(location.search);
const W = +(Q.get('w') || 1080), H = +(Q.get('h') || 1920);
const TV = W > H;                       // 16:9 television layout
const DW = TV ? 1920 : 1080, DH = TV ? 1080 : 1920;   // design space
const SC = W / DW;
const LT = (portrait, tv) => TV ? tv : portrait;
const DUR = 62;
const FOV = TV ? 30 : 35;

const bg = document.getElementById('bg'), gl = document.getElementById('gl'), fx = document.getElementById('fx');
for (const c of [bg, gl, fx]) { c.width = W; c.height = H; c.style.width = W + 'px'; c.style.height = H + 'px'; }
document.getElementById('stage').style.width = W + 'px'; document.getElementById('stage').style.height = H + 'px';
const bgg = bg.getContext('2d'), g = fx.getContext('2d');

const AA = Q.get('aa') !== '0';
const SHADOW = +(Q.get('sh') || 2048);
const renderer = new THREE.WebGLRenderer({ canvas: gl, antialias: AA, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.setClearColor(0x000000, 0);
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = SHADOW > 0; renderer.shadowMap.type = Q.get('pcf') === '1' ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap; renderer.shadowMap.autoUpdate = true;

const scene = new THREE.Scene();
const ENV = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(renderer), 0.04).texture;
const FOG_STREET = new THREE.Fog('#5d86bd', 16, 70);
const camera = new THREE.PerspectiveCamera(FOV, W / H, 0.03, 220);
scene.add(camera);
const hud = new THREE.Group(); camera.add(hud);

let street, studio, rig, L, lights;
const CHAR_Z = 2.3;

// ---------------------------------------------------------------- HUD helpers
const TAN = Math.tan(THREE.MathUtils.degToRad(FOV / 2));
function hudPlace(obj, xpx, ypx, hpx, D = 2.2) {
  const visH = 2 * D * TAN, visW = visH * W / H;
  obj.position.set((xpx / DW - 0.5) * visW, (0.5 - ypx / DH) * visH, -D);
  obj.scale.setScalar(Math.max(1e-4, hpx / DH * visH));
}
const _v = new THREE.Vector3();
function toPx(v3) { _v.copy(v3).project(camera); return { x: (_v.x * 0.5 + 0.5) * DW, y: (0.5 - _v.y * 0.5) * DH, z: _v.z }; }

function roundedShape(w, h, r) {
  const s = new THREE.Shape(); const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r); s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h); s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y); return s;
}
function faceGeo(w, h, r) {
  const geo = new THREE.ShapeGeometry(roundedShape(w, h, r), 6);
  const p = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / w + 0.5, p.getY(i) / h + 0.5);
  return geo;
}
// card with unit height: body (extruded, bevelled) + image face
function makeCard(aspect, { body = '#ffffff', border = 0.04, depth = 0.035, radius = 0.05, canvasW = 1080, glass = false } = {}) {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const w = aspect, h = 1;
  const bw = w + border * 2, bh = h + border * 2;
  const ext = new THREE.ExtrudeGeometry(roundedShape(bw, bh, radius + border), { depth, bevelEnabled: true, bevelThickness: 0.012, bevelSize: 0.012, bevelSegments: 3, curveSegments: 8 });
  ext.translate(0, 0, -depth);
  const bodyMat = new THREE.MeshPhysicalMaterial({ color: body, roughness: glass ? 0.1 : 0.35, clearcoat: 1, clearcoatRoughness: 0.15, metalness: 0.0, envMapIntensity: 1.0, transmission: 0, sheen: 0.2 });
  const bodyM = new THREE.Mesh(ext, bodyMat); inner.add(bodyM);
  const cv = document.createElement('canvas'); cv.width = canvasW; cv.height = Math.round(canvasW / aspect);
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const face = new THREE.Mesh(faceGeo(w, h, radius), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false, transparent: true }));
  face.position.z = 0.0135; inner.add(face);
  // gloss sweep plane
  const gl2 = new THREE.Mesh(faceGeo(w, h, radius), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending }));
  gl2.position.z = 0.015; inner.add(gl2);
  // soft contact shadow behind
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(bw * 1.35, bh * 1.35), new THREE.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false, opacity: 0.6 }));
  sh.position.set(0.04, -0.06, -depth - 0.25); inner.add(sh);
  grp.visible = false;
  return { grp, inner, cv, ctx: cv.getContext('2d'), tex, face, bodyMat, aspect, key: '' };
}
let _shadowTex;
function shadowTex() {
  if (_shadowTex) return _shadowTex;
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
  const gr = x.createRadialGradient(64, 64, 10, 64, 64, 64); gr.addColorStop(0, 'rgba(0,0,0,0.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128); _shadowTex = new THREE.CanvasTexture(c); return _shadowTex;
}

// ---------------------------------------------------------------- coin
let coin;
function makeCoin() {
  const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d');
  const gr = x.createRadialGradient(200, 180, 20, 256, 256, 260); gr.addColorStop(0, '#fff3b0'); gr.addColorStop(0.5, '#ffc93a'); gr.addColorStop(1, '#d88a00');
  x.fillStyle = gr; x.fillRect(0, 0, 512, 512);
  x.strokeStyle = 'rgba(140,80,0,0.8)'; x.lineWidth = 14; x.beginPath(); x.arc(256, 256, 214, 0, 7); x.stroke();
  x.strokeStyle = 'rgba(255,245,200,0.9)'; x.lineWidth = 6; x.beginPath(); x.arc(256, 256, 200, 0, 7); x.stroke();
  // lightning bolt in relief
  const bolt = new Path2D('M286,92 L160,284 L246,284 L214,420 L352,214 L262,214 Z');
  x.save(); x.translate(8, 10); x.fillStyle = 'rgba(120,60,0,0.75)'; x.fill(bolt); x.restore();
  const bg2 = x.createLinearGradient(160, 92, 352, 420); bg2.addColorStop(0, '#fffbe6'); bg2.addColorStop(1, '#ffb300');
  x.fillStyle = bg2; x.fill(bolt); x.strokeStyle = '#a35f00'; x.lineWidth = 6; x.stroke(bolt);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const faceMat = new THREE.MeshPhysicalMaterial({ map: tex, metalness: 0.75, roughness: 0.28, clearcoat: 1, envMapIntensity: 1.5, color: '#ffffff' });
  const sideMat = new THREE.MeshPhysicalMaterial({ color: '#f0a400', metalness: 0.9, roughness: 0.25, envMapIntensity: 1.6 });
  const m = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.11, 48, 1), [sideMat, faceMat, faceMat]);
  m.rotation.x = Math.PI / 2;
  const grp = new THREE.Group(); const spin = new THREE.Group(); spin.add(m); grp.add(spin);
  // rim ridges
  const ridge = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.03, 10, 64), sideMat); spin.add(ridge);
  grp.visible = false; return { grp, spin };
}

// ---------------------------------------------------------------- studio
function buildStudio() {
  const s = new THREE.Group(); s.name = 'studio';
  const top = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.32, 0.22, 64), new THREE.MeshPhysicalMaterial({ color: '#0e2c4d', roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.1, envMapIntensity: 1 }));
  top.position.y = -0.11; top.receiveShadow = true; s.add(top);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.27, 0.022, 10, 96), new THREE.MeshBasicMaterial({ color: '#08E1FF', toneMapped: false }));
  ring.rotation.x = Math.PI / 2; ring.position.y = 0.0; s.add(ring);
  const ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.33, 0.015, 8, 96), new THREE.MeshBasicMaterial({ color: '#F6901C', toneMapped: false }));
  ring2.rotation.x = Math.PI / 2; ring2.position.y = -0.2; s.add(ring2);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(1.2, 64), new THREE.MeshPhysicalMaterial({ color: '#123a63', roughness: 0.3, clearcoat: 1, envMapIntensity: 0.8 }));
  disc.rotation.x = -Math.PI / 2; disc.position.y = 0.002; disc.receiveShadow = true; s.add(disc);
  // glow under the rim
  const gs = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 4.2), new THREE.MeshBasicMaterial({ map: glowTex('8,225,255'), transparent: true, opacity: 0.35, depthWrite: false, blending: THREE.AdditiveBlending }));
  gs.rotation.x = -Math.PI / 2; gs.position.y = -0.21; s.add(gs);
  s.visible = false; return s;
}

// ---------------------------------------------------------------- objects
let photoCard, postCard, styleCards, vidPhone, sponsorCard, logoPlate;
function makeLogoPlate() {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const asp = 929 / 959, pad = 0.12, w = asp + pad * 2, h = 1 + pad * 2;
  const ext = new THREE.ExtrudeGeometry(roundedShape(w, h, 0.14), { depth: 0.06, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 4, curveSegments: 10 });
  ext.translate(0, 0, -0.06);
  const body = new THREE.Mesh(ext, new THREE.MeshPhysicalMaterial({ color: '#0b1a33', roughness: 0.18, metalness: 0.3, clearcoat: 1, clearcoatRoughness: 0.05, envMap: ENV, envMapIntensity: 1.4 }));
  inner.add(body);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1, 0.012, 6, 64), new THREE.MeshBasicMaterial({ color: '#3B71FB', toneMapped: false }));
  const cv = document.createElement('canvas'); cv.width = 1024; cv.height = Math.round(1024 * h / w); const x = cv.getContext('2d');
  const gr = x.createRadialGradient(cv.width / 2, cv.height * 0.4, 20, cv.width / 2, cv.height / 2, cv.width * 0.8); gr.addColorStop(0, '#13305e'); gr.addColorStop(1, '#070f1e');
  x.fillStyle = gr; x.fillRect(0, 0, cv.width, cv.height);
  x.strokeStyle = '#3B71FB'; x.lineWidth = 10; x.beginPath(); x.roundRect(8, 8, cv.width - 16, cv.height - 16, 120); x.stroke();
  if (A.logo) { const lw = cv.width * asp / w, lh = lw / asp; x.drawImage(A.logo, (cv.width - lw) / 2, (cv.height - lh) / 2, lw, lh); }
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const face = new THREE.Mesh(faceGeo(w, h, 0.14), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); face.position.z = 0.021; inner.add(face);
  const sweep = new THREE.Mesh(faceGeo(w, h, 0.14), new THREE.MeshBasicMaterial({ map: sweepTex(), transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false })); sweep.position.z = 0.023; inner.add(sweep);
  const glow = new THREE.Mesh(new THREE.PlaneGeometry(w * 2.6, h * 2.2), new THREE.MeshBasicMaterial({ map: glowTex('59,113,251'), transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending })); glow.position.z = -0.35; inner.add(glow);
  // reflection (flipped, fading) under the plate
  const rc = document.createElement('canvas'); rc.width = cv.width; rc.height = cv.height; const rx = rc.getContext('2d');
  rx.translate(0, rc.height); rx.scale(1, -1); rx.drawImage(cv, 0, 0); rx.setTransform(1, 0, 0, 1, 0, 0);
  rx.globalCompositeOperation = 'destination-in'; const fg = rx.createLinearGradient(0, 0, 0, rc.height); fg.addColorStop(0, 'rgba(0,0,0,0.35)'); fg.addColorStop(0.45, 'rgba(0,0,0,0)'); rx.fillStyle = fg; rx.fillRect(0, 0, rc.width, rc.height);
  const rt = new THREE.CanvasTexture(rc); rt.colorSpace = THREE.SRGBColorSpace;
  const refl = null;
  grp.visible = false;
  return { grp, inner, sweep, glow, refl };
}
function sweepTex() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256; const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 256, 256); g.addColorStop(0.35, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.55)'); g.addColorStop(0.65, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 256, 256); const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; return t;
}
function makePhoneHud() {
  const grp = new THREE.Group(); const inner = new THREE.Group(); grp.add(inner);
  const aspect = 9 / 16;
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(roundedShape(aspect + 0.07, 1.07, 0.09), { depth: 0.05, bevelEnabled: true, bevelThickness: 0.015, bevelSize: 0.015, bevelSegments: 3 }),
    new THREE.MeshPhysicalMaterial({ color: '#1a2230', metalness: 0.6, roughness: 0.25, clearcoat: 1, envMapIntensity: 1.2 }));
  body.position.z = -0.05; inner.add(body);
  const cv = document.createElement('canvas'); cv.width = 540; cv.height = 960;
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const face = new THREE.Mesh(faceGeo(aspect, 1, 0.05), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
  face.position.z = 0.017; inner.add(face);
  const notch = new THREE.Mesh(new THREE.CapsuleGeometry(0.012, 0.06, 4, 8), new THREE.MeshBasicMaterial({ color: '#000' })); notch.rotation.z = Math.PI / 2; notch.position.set(0, 0.47, 0.02); inner.add(notch);
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.5), new THREE.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false, opacity: 0.6 }));
  sh.position.set(0.04, -0.06, -0.3); inner.add(sh);
  grp.visible = false;
  return { grp, inner, cv, ctx: cv.getContext('2d'), tex };
}

// ---------------------------------------------------------------- init
async function init() {
  for (const f of ['80px UneDisplay', '60px UneCond', 'italic 60px UneCond', '40px UneText', '40px UneTextB', '80px UneLogo']) await document.fonts.load(f);
  await loadAssets();
  A.logo = await new Promise(r => { const im = new Image(); im.onload = () => r(im); im.onerror = () => r(null); im.src = 'assets/proaudih_logo_blanco.png'; });
  // top-mark logo pre-scaled in halving steps (keeps the thin 'AUDIOVISUAL' letters clean)
  if (A.logo) { const target = Math.round((TV ? 118 : 150) * SC); let c = document.createElement('canvas'); c.width = 929; c.height = 959; c.getContext('2d').drawImage(A.logo, 0, 0);
    while (c.height / 2 >= target) { const n = document.createElement('canvas'); n.width = Math.round(c.width / 2); n.height = Math.round(c.height / 2); const x = n.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c, 0, 0, n.width, n.height); c = n; }
    const f = document.createElement('canvas'); f.height = target; f.width = Math.round(target * 929 / 959); const fx2 = f.getContext('2d'); fx2.imageSmoothingQuality = 'high'; fx2.drawImage(c, 0, 0, f.width, f.height); A.logoSmall = f; }
  // logo symbol only (rounded square with slashes), cropped without distortion
  A.logoSym = document.createElement('canvas'); A.logoSym.width = 650; A.logoSym.height = 704;
  if (A.logo) A.logoSym.getContext('2d').drawImage(A.logo, 140, 0, 650, 704, 0, 0, 650, 704);
  const S = buildStreet(); street = S.root; scene.add(street);
  studio = buildStudio(); scene.add(studio);
  lights = buildLights(scene);
  lights.key.shadow.mapSize.set(SHADOW || 1, SHADOW || 1);
  rig = buildReporter(); scene.add(rig.root); scene.add(rig.blob);
  coin = makeCoin(); hud.add(coin.grp);
  photoCard = makeCard(4 / 3, { body: '#ffffff', border: 0.045, canvasW: 1200 }); hud.add(photoCard.grp);
  postCard = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 1080 }); hud.add(postCard.grp);
  styleCards = [0, 1, 2].map(() => { const c = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 720 }); hud.add(c.grp); return c; });
  sponsorCard = makeCard(0.8, { body: '#ffffff', border: 0.02, canvasW: 720 }); hud.add(sponsorCard.grp);
  vidPhone = makePhoneHud(); hud.add(vidPhone.grp);
  // static card faces
  fillCard(photoCard, (x, w, h) => { x.drawImage(A.photo, 0, 0, w, h); });
  fillCard(postCard, (x, w, h) => { x.drawImage(A.posts.impacto, 0, 0, w, h); });
  ['clasico', 'cristal', 'impacto'].forEach((k, i) => fillCard(styleCards[i], (x, w, h) => x.drawImage(A.posts[k], 0, 0, w, h)));
  drawLaptop();
  // mic flag cube: real logo symbol on navy
  { const c = rig.flagCanvas, x = c.getContext('2d'); const gr = x.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#0e2a48'); gr.addColorStop(1, '#06121F');
    x.fillStyle = gr; x.fillRect(0, 0, 256, 256); x.fillStyle = '#3DE0FF'; x.fillRect(0, 0, 256, 12); x.fillRect(0, 244, 256, 12);
    if (A.logo) { const hh = 196, ww = hh * 929 / 959; x.drawImage(A.logo, 128 - ww / 2, 30, ww, hh); }
    rig.flagTex.needsUpdate = true; }
  // hero logo plate for the close
  logoPlate = makeLogoPlate(); hud.add(logoPlate.grp);
  // Image-based reflections only on small shiny props (full-screen PMREM sampling is too slow on a CPU rasterizer)
  scene.traverse(o => { const ms = Array.isArray(o.material) ? o.material : o.material ? [o.material] : []; for (const m of ms) if (m.isMeshStandardMaterial && m.metalness >= 0.5) { m.envMap = ENV; m.needsUpdate = true; } });
  if (Q.get('env') === '1') scene.environment = ENV;
  if (Q.get('basic') === '1') scene.overrideMaterial = new THREE.MeshBasicMaterial({ color: '#888' });
  if (Q.get('std') === '1') scene.traverse(o => { if (o.material && !Array.isArray(o.material) && o.material.isMeshPhysicalMaterial) { const m = o.material; o.material = new THREE.MeshStandardMaterial({ color: m.color, map: m.map, roughness: m.roughness, metalness: m.metalness, emissive: m.emissive, emissiveIntensity: m.emissiveIntensity, transparent: m.transparent, opacity: m.opacity }); } });
  // warm-up compile
  renderer.compile(scene, camera);
}
function fillCard(card, fn) { const w = card.cv.width, h = card.cv.height; card.ctx.clearRect(0, 0, w, h); fn(card.ctx, w, h); card.tex.needsUpdate = true; }

function drawLaptop() {
  const c = rig.lapCanvas, x = c.getContext('2d'); const w = c.width, h = c.height;
  const gr = x.createLinearGradient(0, 0, w, h); gr.addColorStop(0, '#0B2238'); gr.addColorStop(1, '#06121F'); x.fillStyle = gr; x.fillRect(0, 0, w, h);
  // top bar
  x.fillStyle = 'rgba(255,255,255,0.06)'; x.fillRect(0, 0, w, 54);
  x.font = '30px UneDisplay'; x.fillStyle = '#fff'; x.textBaseline = 'middle'; x.fillText('ESTUDIO DE', 30, 28);
  x.fillStyle = BRAND.ambar; x.fillText('NOTICIAS', 30 + x.measureText('ESTUDIO DE ').width, 28);
  if (A.logo) x.drawImage(A.logo, w - 30 - 48 * 929 / 959, 3, 48 * 929 / 959, 48);
  // app_6 (phone-size screen) centered-left, post on right
  const ah = h - 90, aw = ah * 780 / 1688;
  x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 30;
  x.beginPath(); x.roundRect(120, 72, aw, ah, 22); x.clip(); x.drawImage(A.app[6], 0, 150, 780, 1688 - 150, 120, 72, aw, ah); x.restore();
  const ph = h - 130, pw = ph * 0.8;
  x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 40; x.drawImage(A.posts.impacto, w - pw - 110, 92, pw, ph); x.restore();
  x.strokeStyle = 'rgba(8,225,255,0.5)'; x.lineWidth = 3; x.strokeRect(w - pw - 110, 92, pw, ph);
  rig.lapTex.needsUpdate = true;
}

// ---------------------------------------------------------------- phone screen states
let screenKey = '';
function drawScreen(desc) {
  const key = JSON.stringify(desc);
  if (key === screenKey) return; screenKey = key;
  const c = rig.screenCanvas, x = c.getContext('2d'); const w = c.width, h = c.height;
  x.fillStyle = '#000'; x.fillRect(0, 0, w, h);
  if (desc.kind === 'app') {
    const a = A.app[desc.a], b = A.app[desc.b ?? desc.a];
    x.globalAlpha = 1; x.drawImage(a, 0, -desc.k * 40, w, h);
    if (desc.k > 0 && b) { x.globalAlpha = desc.k; x.drawImage(b, 0, (1 - desc.k) * 40, w, h); x.globalAlpha = 1; }
    if (desc.full && !desc.kb && S.drawTyped) S.drawTyped(x, w, h, TYPED_TEXT);   // box text stays after the keyboard leaves
    if (desc.press && S.drawPress) S.drawPress(x, w, h, desc.press.which, desc.press.k);
    else if (desc.press) { // pressed button glow
      const hp = HOTSPOT[desc.press.which];
      x.globalAlpha = desc.press.k * 0.45; x.fillStyle = '#fff'; x.beginPath(); x.roundRect((hp.x - hp.w / 2) * w, (hp.y - hp.h / 2) * h, hp.w * w, hp.h * h, 24); x.fill(); x.globalAlpha = 1;
    }
  } else if (desc.kind === 'viewfinder' || desc.kind === 'photo') {
    const im = A.photo; const s = Math.max(w / im.width, h / im.height) * (desc.kind === 'viewfinder' ? 1.0 + desc.z * 0.12 : 1.0);
    const dw = im.width * s, dh = im.height * s;
    x.drawImage(im, (w - dw) / 2 + (desc.ox || 0), (h - dh) / 2, dw, dh);
    // camera UI
    x.fillStyle = 'rgba(0,0,0,0.45)'; x.fillRect(0, 0, w, 150); x.fillRect(0, h - 330, w, 330);
    x.strokeStyle = 'rgba(255,255,255,0.35)'; x.lineWidth = 2;
    for (const f of [1 / 3, 2 / 3]) { x.beginPath(); x.moveTo(w * f, 150); x.lineTo(w * f, h - 330); x.stroke(); x.beginPath(); x.moveTo(0, 150 + (h - 480) * f); x.lineTo(w, 150 + (h - 480) * f); x.stroke(); }
    { const sx = w * SHUT().x, sy = h * SHUT().y; x.fillStyle = 'rgba(0,0,0,0.25)'; x.beginPath(); x.arc(sx, sy, 96, 0, 7); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.arc(sx, sy, 78, 0, 7); x.fill();
      x.strokeStyle = 'rgba(0,0,0,0.4)'; x.lineWidth = 6; x.beginPath(); x.arc(sx, sy, 64, 0, 7); x.stroke(); }
    x.fillStyle = BRAND.ambar; x.font = '34px UneCond'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('FOTO', w / 2, h - 300); x.fillStyle = 'rgba(255,255,255,0.7)'; x.fillText('VIDEO', w / 2 - 160, h - 300); x.textAlign = 'left';
    // focus square
    if (desc.kind === 'viewfinder') { x.strokeStyle = BRAND.ambar; x.lineWidth = 5; const fs = 160 - desc.z * 30; x.strokeRect(w / 2 - fs / 2, h * 0.46 - fs / 2, fs, fs); }
    if (desc.kind === 'photo') { // thumbnail
      x.save(); x.beginPath(); x.roundRect(70, h - 220, 110, 110, 16); x.clip(); x.drawImage(im, 70 - 40, h - 220, 190, 110); x.restore();
      x.strokeStyle = '#fff'; x.lineWidth = 4; x.beginPath(); x.roundRect(70, h - 220, 110, 110, 16); x.stroke();
    }
    if (desc.press && S.drawPress && HOTSPOT.shutter) S.drawPress(x, w, h, 'shutter', desc.press.k);
    else if (desc.press) { const sx = w * SHUT().x, sy = h * SHUT().y; x.globalAlpha = desc.press.k; x.strokeStyle = BRAND.cian; x.lineWidth = 10; x.beginPath(); x.arc(sx, sy, 100, 0, 7); x.stroke(); x.globalAlpha = 1; }
    if (desc.flash) { x.fillStyle = `rgba(255,255,255,${desc.flash})`; x.fillRect(0, 0, w, h); }
  }
  if (desc.kb) { if (S.drawKeyboard) S.drawKeyboard(x, w, h, desc.kb, desc.key, desc.kp ?? 1, desc.typed); else drawKeyboard(x, w, h, desc.kb, desc.key); }
  rig.screenTex.needsUpdate = true;
}
function drawKeyboard(x, w, h, k, key) {
  const top = h * (0.70 + (1 - k) * 0.32);
  x.save();
  x.fillStyle = 'rgba(16,24,38,0.97)'; x.fillRect(0, top, w, h - top);
  x.fillStyle = 'rgba(255,255,255,0.08)'; x.fillRect(0, top, w, 3);
  const rows = ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'];
  x.font = '600 34px UneText'; x.textAlign = 'center'; x.textBaseline = 'middle';
  rows.forEach((row, ri) => {
    const x0 = ri === 2 ? 0.17 : ri === 1 ? 0.07 : 0.05;
    for (let c = 0; c < row.length; c++) {
      const kx = w * (x0 + 0.09 * c) + 4, ky = top + h * (0.03 + 0.072 * ri) + 6, kw = w * 0.09 - 8, kh = h * 0.072 - 12;
      const hit = key && key.row === ri && key.col === c;
      x.fillStyle = hit ? '#3DE0FF' : 'rgba(255,255,255,0.16)'; x.beginPath(); x.roundRect(kx, ky, kw, kh, 10); x.fill();
      x.fillStyle = hit ? '#06121F' : '#ffffff'; x.fillText(row[c], kx + kw / 2, ky + kh / 2 + 1);
    }
  });
  const sy = top + h * (0.03 + 0.072 * 3) + 6;
  x.fillStyle = 'rgba(255,255,255,0.16)'; x.beginPath(); x.roundRect(w * 0.25, sy, w * 0.5, h * 0.072 - 12, 10); x.fill();
  x.fillStyle = 'rgba(255,255,255,0.7)'; x.font = '600 26px UneText'; x.fillText('espacio', w * 0.5, sy + (h * 0.072 - 12) / 2);
  x.restore();
}

// ---------------------------------------------------------------- poses
const HH = HANDS;
// over-the-shoulder phone hold (right hand grips, phone at chest, screen tilted up toward his face)
const OTS = { rotY: Math.PI - 0.24, aimW: 1, phX: -0.16, phY: 0.8, phZ: 0.28, aimYaw: 3.9, aimPitch: -0.8, handR: HH.grip, handL: HH.relax,
  rThumbW: 0, headX: 0.16, headY: -0.22, eyeY: -0.6, eyeX: -0.35, smile: 0.6,
  lFwd: 0.12, lOut: 0.16, lElbow: -0.35, mic: 0 };
const P = {
  back: { rotY: Math.PI, rFwd: 0.25, rOut: 0.15, rElbow: -0.6, rWristX: 0.2, lFwd: 0.35, lOut: 0.12, lElbow: -1.0, headX: 0.05, handR: HH.grip, handL: HH.mic, lWristY: -1.2 },
  crouch: { rotY: 0.2, rFwd: 0.3, rOut: 0.3, rElbow: -0.9, rWristY: -0.6, lFwd: 0.35, lOut: 0.2, lElbow: -1.1, rKnee: 0.35, lKnee: 0.35, rLeg: 0.18, lLeg: 0.18, bob: -0.045, headX: 0.12, brow: 0.6, eyeScale: 1.05, handR: HH.grip, handL: HH.mic, mouthOpen: 0.2, round: 0.6, smile: 0 },
  surprised: { rFwd: 0.3, rOut: 0.32, rElbow: -0.9, rWristX: 0.1, rWristY: -0.6, lFwd: 0.6, lOut: 0.65, lElbow: -1.75, brow: 1, browTilt: 0.4, mouthOpen: 0.85, round: 0.9, eyeScale: 1.14, lidUp: 1, lean: -0.06, headX: -0.06, smile: 0, handR: HH.grip, handL: HH.mic, lWristY: -1.2 },
  excited: { rFwd: 0.35, rOut: 0.3, rElbow: -1.1, rWristY: -0.6, lFwd: 0.6, lOut: 0.3, lElbow: -1.6, brow: 0.7, mouthOpen: 0.5, eyeScale: 1.06, smile: 1, headZ: 0.08, handR: HH.grip, handL: HH.mic, lWristY: -1.2, squint: 0.1 },
  reportR: { rotY: 0, rFwd: 0.55, rOut: 0.9, rElbow: -0.55, rWristZ: 0.3, lFwd: 1.05, lOut: 0.25, lElbow: -1.75, headY: -0.32, eyeX: -0.7, mouthOpen: 0.4, smile: 1, handR: HH.grip, handL: HH.mic, lWristY: -1.2, squint: 0.1 },
  celebrate: { rFwd: 2.75, rOut: 0.55, rElbow: -0.35, lFwd: 2.75, lOut: 0.55, lElbow: -0.35, mouthOpen: 1, brow: 1, eyeScale: 1.08, smile: 1, squint: 0.5, handR: HH.grip, handL: HH.open, mic: 0 },
  thumbsUp: { rFwd: 0.7, rOut: 0.35, rElbow: -1.5, lFwd: 1.1, lOut: 0.25, lElbow: -1.85, mouthOpen: 0.45, smile: 1, squint: 0.25, headZ: 0.12, handR: HH.grip, handL: HH.thumbsUp, mic: 0, brow: 0.5 },
  wow: { phone: 0, mic: 0, rFwd: 0.95, rOut: 0.3, rElbow: -2.15, rWristX: -0.3, lFwd: 0.95, lOut: 0.3, lElbow: -2.15, lWristX: -0.3, headX: -0.32, eyeY: 0.9, mouthOpen: 0.75, round: 0.5, brow: 1, eyeScale: 1.1, lidUp: 0.8, handR: HH.open, handL: HH.open },
  pointR: { rFwd: 1.5, rOut: 0.85, rElbow: -0.15, rWristZ: 0.15, phone: 0, mic: 0, lFwd: 0.3, lOut: 0.15, lElbow: -0.9, smile: 1, headY: -0.3, eyeX: -0.6, handR: HH.point, handL: HH.relax },
  pointL: { lFwd: 1.5, lOut: 0.85, lElbow: -0.15, lWristZ: 0.15, rFwd: 0.3, rOut: 0.15, rElbow: -0.9, phone: 0, mic: 0, smile: 1, headY: 0.3, eyeX: 0.6, handL: HH.point, handR: HH.relax },
  present: { phone: 0, mic: 0, rFwd: 0.5, rOut: 0.5, rElbow: -1.2, lFwd: 0.5, lOut: 0.5, lElbow: -1.2, handR: HH.open, handL: HH.open, smile: 1, mouthOpen: 0.4, brow: 0.6 },
  laptop: { rFwd: 0.85, rOut: 0.12, rElbow: -0.85, lFwd: 0.85, lOut: 0.12, lElbow: -0.85, phone: 0, mic: 0, laptop: 1, smile: 1, headX: 0.05, handR: HH.side, handL: HH.side, squint: 0.1 },
  ots: OTS,
};
const pose = (name, extra = {}) => ({ ...DEFAULT_POSE, ...P[name], ...extra });

// ---------------------------------------------------------------- life: blinks, darts, weight shift, noise (WP2)
// asymmetric blink: 2 frames closing, 1 closed, 4 opening (30 fps); every 2.5–5 s and on every big head turn
const HEAD_TURNS = [0.6, 1.2, 8.55, 10.75, 27.2, 33.05, 34.15, 35.25, 37.65, 44.65, 51.3];
const BLINKS = (() => { const r = rng(4242); const a = [...HEAD_TURNS]; let t = 1.9; while (t < 62) { a.push(t); t += 2.5 + r() * 2.5; }
  a.sort((x, y) => x - y); const o = []; for (const b of a) if (!o.length || b - o[o.length - 1] > 1.1) o.push(b); return o; })();
function blinkAt(t) {
  for (const b of BLINKS) { const d = t - b; if (d < 0 || d > 0.24) continue;
    if (d < 0.067) return easeIn(d / 0.067); if (d < 0.1) return 1; return 1 - easeOut((d - 0.1) / 0.134); }
  return 0;
}
// saccades: quick 1.5-frame darts, small amplitude (never cross-eyed)
const DARTS = (() => { const r = rng(9); const a = []; let t = 0; while (t < 63) { t += 0.7 + r() * 1.1; a.push([t, (r() - 0.5) * 0.16, (r() - 0.5) * 0.1]); } return a; })();
function dartAt(t) { let x = 0, y = 0; for (let i = 0; i < DARTS.length; i++) { if (DARTS[i][0] > t) break; const k = Math.min(1, (t - DARTS[i][0]) / 0.05); const px = i ? DARTS[i - 1][1] : 0, py = i ? DARTS[i - 1][2] : 0; x = px + (DARTS[i][1] - px) * k; y = py + (DARTS[i][2] - py) * k; } return [x, y]; }
// weight shift every 3–4 s (hips slide to the other leg with a small dip)
const SHIFTS = (() => { const r = rng(77); const a = []; let t = 1.6, s = 1; while (t < 63) { a.push([t, s * (0.010 + r() * 0.006)]); s = -s; t += 3 + r(); } return a; })();
function weightShift(t) { let v = 0, dip = 0; for (let i = 0; i < SHIFTS.length; i++) { const [ts, val] = SHIFTS[i]; if (t < ts) break; const u = clamp((t - ts) / 0.8); v = lerp(i ? SHIFTS[i - 1][1] : 0, val, easeInOutQuad(u)); dip = -0.006 * Math.sin(Math.PI * u); } return [v, dip]; }
// hop with stretch in the air and squash on landing
function hop(t, t0, dur, h) {
  const u = (t - t0) / dur; if (u < 0 || u > 1) return null;
  const air = 0.72;
  if (u < air) { const a = u / air; const v = Math.abs(1 - 2 * a); return { y: h * 4 * a * (1 - a), sy: 1 + 0.1 * v * v, knee: 0.05 }; }
  const s = Math.sin(Math.PI * (u - air) / (1 - air)); return { y: 0, sy: 1 - 0.13 * s, knee: 0.5 * s };
}

// ---- typing (WP2): 3D fingers never touch the phone; taps are 2D cursor + ring + lit key
const KB = { top: 0.70, rowH: 0.072, rows: ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'] };
function keyPos(i) {
  // key of the last typeable character of tap i's chunk (punctuation → previous letter); space → space bar
  let j = TAP_CHARS[i] - 1, k = null; while (j >= 0 && !(k = keyOfChar(TYPED_TEXT[j]))) j--;
  k = k || { row: 3, col: -1, space: true };
  if (k.space) return { x: 0.5, y: KB.top + 0.03 + KB.rowH * 3.5, row: 3, col: -1, space: true };
  if (S.keyRect) { const kr = S.keyRect(k.row, k.col); return { x: kr.x + kr.w / 2, y: kr.y + kr.h / 2, row: k.row, col: k.col }; }
  const x0 = [0.05, 0.07, 0.17][k.row]; return { x: x0 + 0.09 * (k.col + 0.5), y: KB.top + 0.03 + KB.rowH * (k.row + 0.5), row: k.row, col: k.col };
}
export function typedKey(t) { const T = TYPING_TAPS; for (let i = 0; i < T.length; i++) { const d = t - T[i]; if (d >= 0 && d < 0.1) return keyPos(i); } return null; }
window.__typedKey = typedKey;

// ---------------------------------------------------------------- timeline: character pose
// per-channel delays (overlapping action: hips → torso → head → arms → hands; eyes 3 frames before the head)
function DELAY(c) {
  if (c === 'headX' || c === 'headY' || c === 'headZ') return 0.067;
  if (c === 'eyeX' || c === 'eyeY') return -0.033;
  if (c.startsWith('torso')) return 0.033;
  if (c.includes('Wrist') || c === 'handR' || c === 'handL') return 0.133;
  if (/^[rl](Fwd|Out|Twist|Elbow)$/.test(c) || c.startsWith('aim') || /^ph[XYZ]$/.test(c)) return 0.1;
  if (/^(brow|browTilt|mouthOpen|smile|round|eyeScale|lidUp|squint)$/.test(c)) return 0.05;
  return 0;
}
const NOANT = (c) => /^(brow|browTilt|mouthOpen|smile|round|eyeScale|lidUp|squint|handR|handL|mic|phone|laptop|aimW|eyeX|eyeY|blink|z)$/.test(c);
const PHOTO = pose('ots', { mic: 1, handL: HH.mic, lWristY: -1.2, lFwd: 0.25, lElbow: -0.8 });
const K_STREET = [
  [0, pose('back')], [0.55, pose('back', { headY: 0.55, eyeX: 0.45 }), 'out'],
  [0.95, pose('crouch')], [1.25, pose('surprised', { rotY: 0 }), 'back'], [2.2, pose('surprised'), 'drift'],
  [2.7, pose('excited'), 'back'], [4.5, pose('excited', { headZ: -0.05 }), 'drift'],
  [5.6, PHOTO], [6.55, PHOTO], [6.8, { ...PHOTO, brow: 0.3 }], [7.6, { ...PHOTO, mouthOpen: 0.3, smile: 1 }],
  [8.7, pose('reportR', { aimW: 0, eyeX: -0.4 }), 'back'], [10.3, pose('reportR', { headY: -0.15, eyeX: -0.25, mouthOpen: 0.3 }), 'drift'], [11, pose('ots', { mic: 0 })],
  [18, pose('ots')], [20.2, pose('ots', { mouthOpen: 0.7, round: 0.4, brow: 0.9, eyeScale: 1.1, lidUp: 0.6, smile: 0.3 }), 'back'],
  [22.5, pose('ots', { smile: 1, mouthOpen: 0.3, squint: 0.4 }), 'drift'], [25, pose('ots'), 'drift'],
  [26.6, pose('ots', { mouthOpen: 0.6, smile: 1, brow: 0.8 })],
  [27.35, pose('excited', { rotY: 0, aimW: 0, mic: 0, handL: HH.open, lFwd: 0.4, lOut: 0.4, lElbow: -1.2 }), 'back'],
  [27.95, pose('crouch', { aimW: 0, handL: HH.open, mic: 0, rotY: 0 })], [28.3, pose('celebrate'), 'back'], [29.5, pose('celebrate', { headZ: 0.1 }), 'drift'],
  [30.1, pose('thumbsUp'), 'back'], [31, pose('thumbsUp'), 'drift'],
];
const K_STYLES = [[31, pose('wow')], [33.2, pose('wow', { headY: 0.25, eyeX: 0.35 }), 'back'], [34.3, pose('wow', { headY: 0, eyeX: 0, mouthOpen: 0.4 }), 'back'], [35.4, pose('wow', { headY: -0.25, eyeX: -0.35 }), 'back'], [37, pose('wow', { mouthOpen: 0.3 }), 'drift']];
const K_VIDEO = [[37, pose('pointL', { headX: -0.15, lFwd: 0.6, lElbow: -1.2, eyeX: 0.3 })], [37.8, pose('pointL', { lFwd: 1.35, lOut: 0.88, lElbow: -0.7, headY: 0.45, eyeX: 0.35, headX: -0.1 }), 'back'], [43, pose('pointL', { lFwd: 1.32, lOut: 0.9, lElbow: -0.7, headY: 0.35, eyeX: 0.3, mouthOpen: 0.4 }), 'drift'], [44, pose('pointL'), 'drift']];
const K_SPONSOR = TV
  ? [[44, pose('pointL', { lFwd: 0.6, lElbow: -1.2, eyeX: 0.3 })], [44.8, pose('pointL', { lFwd: 1.4, lOut: 0.92, lElbow: -0.65, headY: 0.42, eyeX: 0.35 }), 'back'], [46.5, pose('pointL', { lFwd: 1.36, lOut: 0.95, lElbow: -0.65, headY: 0.3, mouthOpen: 0.4 }), 'drift'], [49, pose('pointL', { lFwd: 1.32, lOut: 0.9, lElbow: -0.65, headY: 0.2, eyeX: 0.15 }), 'drift'], [50, pose('present'), 'drift']]
  : [[44, pose('pointR', { rFwd: 0.6, rElbow: -1.2, eyeX: -0.3 })], [44.8, pose('pointR', { rFwd: 1.45, rOut: 0.95, rElbow: -0.6, headY: -0.45, eyeX: -0.35 }), 'back'], [46.5, pose('pointR', { rFwd: 1.4, rOut: 1.0, rElbow: -0.6, headY: -0.3, mouthOpen: 0.4 }), 'drift'], [49, pose('pointR', { rFwd: 1.35, rOut: 0.9, rElbow: -0.6, headY: -0.2, eyeX: 0 }), 'drift'], [50, pose('present'), 'drift']];
const K_PLANS = [[50, pose('present', { headX: -0.1, eyeY: 0.3 })], [51.5, pose('present', { headX: -0.2, eyeY: 0.4, mouthOpen: 0.5 }), 'back'], [54.5, pose('present', { headZ: 0.12, headX: -0.05, eyeY: 0 }), 'drift']];
const K_CLOSE = [[56, pose('laptop')], [56.35, pose('laptop'), 'drift'],   // laptop already full size in his grip under the 56 s wipe
  [58.6, pose('laptop', { headZ: 0.06 }), 'drift'], [60.5, pose('laptop', { mouthOpen: 0.6, brow: 0.6, squint: 0.6 }), 'back'], [62, pose('laptop', { mouthOpen: 0.3 }), 'drift']];

function basePose(t) {
  let p, lifeK = 1;
  if (t < 31) {
    p = { ...DEFAULT_POSE, ...trackCh(K_STREET, t, DELAY, NOANT) };
    p.mic = t < 10.98 ? 1 : 0;
    p.phone = 1;
    const h1 = hop(t, 0.95, 0.6, 0.1);
    const h2 = hop(t, 28.3, 0.75, 0.22) || hop(t, 29.05, 0.75, 0.2);
    const h = h1 || h2;
    if (h) { p.y = h.y; p.rKnee = p.lKnee = Math.max(p.rKnee, h.knee); p.bob = (p.bob || 0) - 0.05 * h.knee; p.sqY = h.sy; }
    if (t > 28.12 && t < 28.3) { const s = Math.sin(Math.PI * prog(t, 28.12, 28.3)); p.sqY = 1 - 0.1 * s; }
    if (t > 12.4 && t < 16.6) p.mouthOpen = Math.max(p.mouthOpen, 0.08);
  } else if (t < 37) p = { ...DEFAULT_POSE, ...trackCh(K_STYLES, t, DELAY, NOANT) };
  else if (t < 44) p = { ...DEFAULT_POSE, ...trackCh(K_VIDEO, t, DELAY, NOANT) };
  else if (t < 50) p = { ...DEFAULT_POSE, ...trackCh(K_SPONSOR, t, DELAY, NOANT) };
  else if (t < 56) p = { ...DEFAULT_POSE, ...trackCh(K_PLANS, t, DELAY, NOANT) };
  else { p = { ...DEFAULT_POSE, ...trackCh(K_CLOSE, t, DELAY, NOANT) }; p.laptop = 1; lifeK = 0.25; }
  // procedural life: irregular breathing, weight shift, multi-frequency noise on torso/head
  const [ws, dip] = weightShift(t);
  p.bob = (p.bob || 0) + (0.004 + 0.002 * fbm(t, 5, 0.2)) * Math.sin(t * 2.3 + 0.8 * fbm(t, 6, 0.3)) + dip;
  p.sway = (p.sway || 0) + ws * lifeK + 0.004 * fbm(t, 7, 0.4) * lifeK;
  p.torsoZ = (p.torsoZ || 0) + 0.012 * fbm(t, 1, 0.4) * lifeK;
  p.torsoX = (p.torsoX || 0) + 0.008 * fbm(t, 11, 0.35) * lifeK;
  p.headZ = (p.headZ || 0) + 0.022 * fbm(t, 2, 0.35);
  p.headX = (p.headX || 0) + 0.012 * fbm(t, 3, 0.5);
  p.headY = (p.headY || 0) + 0.018 * fbm(t, 4, 0.3);
  const [dx, dy] = dartAt(t); p.eyeX = clamp((p.eyeX || 0) + dx, -0.5, 0.5); p.eyeY = clamp((p.eyeY || 0) + dy, -0.6, 0.5);
  p.blink = Math.max(p.blink || 0, blinkAt(t));
  // the 3D hands never tap the phone (taps are drawn as the 2D cursor)
  p.lTapW = 0; p.rThumbW = 0; p.lThumbW = 0;
  p.z = t >= 31 ? 0 : CHAR_Z;
  return p;
}
function poseAt(t) {
  const p = basePose(t);
  // secondary motion: hair and vest follow-through from head/body velocity
  const q = basePose(Math.max(0, t - 0.07));
  const vX = (p.headX - q.headX) + (p.torsoX + p.lean - q.torsoX - q.lean), vZ = (p.headZ - q.headZ) + (p.torsoZ - q.torsoZ);
  const vY = ((p.y || 0) - (q.y || 0)) + ((p.bob || 0) - (q.bob || 0));
  p.hairLagX = clamp(-vX * 1.6 + vY * 1.2, -0.12, 0.12); p.hairLagZ = clamp(-vZ * 1.6, -0.12, 0.12);
  p.vestLag = clamp(vY * 2.0, -0.15, 0.15);
  return p;
}

// ---------------------------------------------------------------- timeline: camera (WP2)
// key: [time, {p,t} | {phone:{d, ox, oy}}, 'cut'?]. Inside a shot the path is a monotone cubic Hermite (Catmull-Rom style
// tangents from neighbouring keys) so velocity carries through every key; 'cut' starts a new shot exactly at that time.
// On top: easeOutExpo push-ins on the beats, 0.3° handheld drift (noise), and the shot never shows a wrong frame (t >= cut).
function phoneCam(d, ox = 0, oy = 0) {
  rig.root.updateMatrixWorld(true);
  const m = rig.phone.matrixWorld;
  const c = new THREE.Vector3().setFromMatrixPosition(m);
  const n = new THREE.Vector3(0, 0, 1).transformDirection(m);
  const up = new THREE.Vector3(0, 1, 0).transformDirection(m);
  const right = new THREE.Vector3(1, 0, 0).transformDirection(m);
  up.lerp(new THREE.Vector3(0, 1, 0), 0.5).normalize();
  const target = c.clone().addScaledVector(right, ox).addScaledVector(up, oy);
  return { p: target.clone().addScaledVector(n, d).toArray(), t: target.toArray(), up: up.toArray() };
}
function resolveCam(k) { return k.phone ? phoneCam(k.phone.d, k.phone.ox, k.phone.oy) : { p: k.p, t: k.t, up: k.up || [0, 1, 0] }; }
// phone close-ups: screen ≈ 65 % of the frame height (vertical FOV 35°: d = 0.151 / 0.65 / 0.63), pushed under the step banner
const CD = 0.369, COY = 0.019;
const CAM = [
  [0.0, { p: [0.9, 1.6, 9.5], t: [0, 0.9, 1.0] }],
  [1.3, { p: [0.05, 1.14, 5.75], t: [0, 1.19, CHAR_Z] }],
  [4.4, { p: [0.1, 1.15, 5.35], t: [0, 1.18, CHAR_Z] }],
  [5.15, { p: [1.3, 1.45, 4.3], t: [0.15, 0.95, 1.8] }],
  [5.9, { phone: { d: 0.47, ox: 0.0, oy: 0.017 } }],
  [7.59, { phone: { d: 0.44, ox: 0.0, oy: 0.017 } }],
  [7.6, { p: [-0.4, 1.06, 5.75], t: [0.42, 1.05, CHAR_Z] }, 'cut'],
  [8.8, { p: [-0.35, 1.05, 5.6], t: [0.42, 1.05, CHAR_Z] }],
  [10.99, { p: [-0.28, 1.07, 5.3], t: [0.4, 1.05, CHAR_Z] }],
  [11.0, { phone: { d: 0.44, ox: 0.0, oy: COY } }, 'cut'],
  [12.2, { phone: { d: CD, ox: 0.0, oy: COY } }],
  [17.8, { phone: { d: CD * 0.98, ox: 0.0, oy: COY } }],
  [20.6, { phone: { d: CD * 1.03, ox: 0.0, oy: COY } }],
  [24.8, { phone: { d: CD, ox: 0.0, oy: COY } }],
  [26.99, { phone: { d: CD * 0.96, ox: 0.0, oy: COY } }],
  [27.0, { p: [0.0, 1.12, 6.3], t: [0, 1.25, CHAR_Z] }, 'cut'],
  [30.99, { p: [0.0, 1.14, 5.7], t: [0, 1.3, CHAR_Z] }],
  // studio (character at origin) — head at bottom, space above for graphics
  [31.0, { p: [0.0, 1.55, 5.0], t: [0.0, 1.92, 0] }, 'cut'],
  [36.99, { p: [0.0, 1.5, 4.7], t: [0.0, 1.88, 0] }],
  [37.0, { p: [-0.55, 1.18, 3.3], t: [0.45, 1.05, 0] }, 'cut'],
  [43.99, { p: [-0.6, 1.2, 3.15], t: [0.45, 1.05, 0] }],
  [44.0, { p: [0.6, 1.18, 3.3], t: [-0.45, 1.05, 0] }, 'cut'],
  [49.99, { p: [0.65, 1.2, 3.15], t: [-0.45, 1.05, 0] }],
  [50.0, { p: [0.0, 1.8, 4.2], t: [0.0, 1.98, 0] }, 'cut'],
  [55.99, { p: [0.0, 1.77, 4.05], t: [0.0, 1.96, 0] }],
  [56.0, { p: [0.0, 1.08, 4.3], t: [0.0, 1.27, 0] }, 'cut'],
  [58.15, { p: [0.0, 1.07, 4.12], t: [0.0, 1.24, 0] }],
  [58.8, { p: [0.0, 1.5, 4.6], t: [0.0, 1.93, 0] }],   // head below the contact block before proaudih.com lands
  [62.0, { p: [0.0, 1.49, 4.4], t: [0.0, 1.91, 0] }],
];
// TV 16:9: same key times, recomposed. Focus point is pushed to screen-x `nx` (NDC) so the
// character sits on the left third and the right side carries the phone/cards/stickers.
const TAN_V = Math.tan(FOV * Math.PI / 360), TAN_H = TAN_V * W / H;
function tvKey(k) {
  if (k.phone) { const d = k.phone.d * 1.17; return { phone: { d, ox: 0.152 * d, oy: (k.phone.oy || 0) * 0.4 } }; } // TV FOV 30°: screen ≈ 65 % of height
  const f = new THREE.Vector3(...(k.f || k.t)), dir = new THREE.Vector3(...k.p).sub(new THREE.Vector3(...k.t)).normalize();
  const d = k.d ?? new THREE.Vector3(...k.p).distanceTo(new THREE.Vector3(...k.t)) * (k.s ?? 1.175);
  const right = new THREE.Vector3(0, 1, 0).cross(dir).normalize(), up = dir.clone().cross(right).normalize();
  const sh = right.multiplyScalar(-(k.nx ?? -0.36) * TAN_H * d).add(up.multiplyScalar(-(k.ny ?? 0) * TAN_V * d));
  const t = f.clone().add(sh), p = t.clone().addScaledVector(dir, d);
  return { p: p.toArray(), t: t.toArray() };
}
const CAM_TV_SRC = [
  [0.0, { p: [0.9, 1.6, 9.5], t: [0, 0.9, 1.0], nx: -0.25, s: 1.0 }],
  [1.3, { p: [0.05, 1.0, 5.75], t: [0, 1.05, CHAR_Z] }],
  [4.4, { p: [0.1, 1.02, 5.35], t: [0, 1.05, CHAR_Z] }],
  [5.15, { p: [1.3, 1.45, 4.3], t: [0.15, 0.95, 1.8], nx: -0.3 }],
  [5.9, { phone: { d: 0.47 * 0.92, oy: 0.015 } }],
  [7.59, { phone: { d: 0.44 * 0.92, oy: 0.015 } }],
  [7.6, { p: [-0.36, 1.05, 5.85], t: [-0.15, 1.05, CHAR_Z], f: [0, 1.05, CHAR_Z] }, 'cut'],
  [8.8, { p: [-0.35, 1.05, 5.6], t: [-0.15, 1.05, CHAR_Z], f: [0, 1.05, CHAR_Z] }],
  [10.99, { p: [-0.28, 1.07, 5.3], t: [-0.12, 1.05, CHAR_Z], f: [0, 1.05, CHAR_Z] }],
  [11.0, { phone: { d: 0.44, oy: 0.015 } }, 'cut'],
  [12.2, { phone: { d: CD, oy: 0.015 } }],
  [17.8, { phone: { d: CD * 0.98, oy: 0.015 } }],
  [20.6, { phone: { d: CD * 1.03, oy: 0.015 } }],
  [24.8, { phone: { d: CD, oy: 0.015 } }],
  [26.99, { phone: { d: CD * 0.96, oy: 0.015 } }],
  [27.0, { p: [0.0, 1.12, 6.3], t: [0, 1.12, CHAR_Z], f: [0, 1.1, CHAR_Z], s: 1.15 }, 'cut'],
  [30.99, { p: [0.0, 1.14, 5.7], t: [0, 1.14, CHAR_Z], f: [0, 1.1, CHAR_Z], s: 1.1 }],
  [31.0, { p: [0.0, 1.35, 5.0], t: [0.0, 1.25, 0], f: [0, 1.2, 0], d: 3.9, nx: -0.5 }, 'cut'],
  [36.99, { p: [0.0, 1.35, 5.0], t: [0.0, 1.25, 0], f: [0, 1.2, 0], d: 3.65, nx: -0.5 }],
  [37.0, { p: [-0.45, 1.25, 3.3], t: [0, 1.15, 0], f: [0, 1.1, 0], d: 3.3, nx: -0.74 }, 'cut'],
  [43.99, { p: [-0.5, 1.25, 3.3], t: [0, 1.15, 0], f: [0, 1.1, 0], d: 3.1, nx: -0.74 }],
  [44.0, { p: [-0.45, 1.25, 3.3], t: [0, 1.15, 0], f: [0, 1.1, 0], d: 3.3, nx: -0.48 }, 'cut'],
  [49.99, { p: [-0.5, 1.25, 3.3], t: [0, 1.15, 0], f: [0, 1.1, 0], d: 3.1, nx: -0.48 }],
  [50.0, { p: [0.0, 1.4, 3.3], t: [0.0, 1.3, 0], f: [0, 1.3, 0], d: 3.0, nx: -0.5 }, 'cut'],
  [55.99, { p: [0.0, 1.4, 3.3], t: [0.0, 1.3, 0], f: [0, 1.3, 0], d: 2.85, nx: -0.5 }],
  [56.0, { p: [0.0, 1.08, 4.3], t: [0.0, 1.0, 0], f: [0, 0.95, 0], d: 3.6, nx: -0.45 }, 'cut'],
  [58.5, { p: [0.0, 1.07, 4.1], t: [0.0, 1.0, 0], f: [0, 0.95, 0], d: 3.45, nx: -0.45 }],
  [59.3, { p: [0.0, 1.25, 4.6], t: [0.0, 1.15, 0], f: [0, 1.0, 0], d: 4.1, nx: -0.48 }],
  [62.0, { p: [0.0, 1.25, 4.6], t: [0.0, 1.15, 0], f: [0, 1.0, 0], d: 3.9, nx: -0.48 }],
];
if (TV) { CAM.length = 0; for (const [tk, k, c] of CAM_TV_SRC) CAM.push([tk, tvKey(k), c]); }
const CUTS = CAM.filter(k => k[2] === 'cut').map(k => k[0]);
// push-ins on the beats: [time, amount (fraction of the camera distance)]
const BEATS = [[1.3, 0.04], [2.85, 0.05], [4.55, 0.04], [7.6, 0.05], [11.0, 0.07], [18.0, 0.04], [20.2, 0.05], [25.0, 0.04], [27.0, 0.06], [31.0, 0.05], [37.0, 0.06], [44.0, 0.06], [50.0, 0.05], [56.0, 0.05], [60.5, 0.025]];
function shotStart(t) { let s = 0; for (const c of CUTS) if (t >= c - 1e-6) s = c; return s; }
function punchAt(t) {
  const s0 = shotStart(t); let k = 0;
  for (const [b, a] of BEATS) { if (b < s0 - 1e-6 || t < b) continue; k += a * (easeOutExpo(prog(t, b, b + 0.6)) - 0.55 * easeInOutQuad(prog(t, b + 0.6, b + 3.2))); }
  return k;
}
function camAt(t) {
  let i = 0; while (i < CAM.length - 1 && t >= CAM[i + 1][0] - 1e-6) i++;
  let s0 = i; while (s0 > 0 && CAM[s0][2] !== 'cut') s0--;
  let s1 = i + 1; while (s1 < CAM.length && CAM[s1][2] !== 'cut') s1++;
  const last = s1 - 1;
  const lo = Math.max(s0, i - 1), hi = Math.min(last, i + 2);
  const R = {}; for (let j = lo; j <= hi; j++) R[j] = resolveCam(CAM[j][1]);
  let out;
  if (i >= last) out = R[last];
  else {
    const T = (j) => CAM[j][0];
    const tangent = (j, f, c) => {
      const dPrev = j > s0 ? (R[j][f][c] - R[j - 1][f][c]) / (T(j) - T(j - 1)) : null;
      const dNext = j < last ? (R[j + 1][f][c] - R[j][f][c]) / (T(j + 1) - T(j)) : null;
      if (dPrev === null) return dNext; if (dNext === null) return dPrev;
      if (dPrev * dNext <= 0) return 0;
      const h0 = T(j) - T(j - 1), h1 = T(j + 1) - T(j);
      const m = (h1 * dPrev + h0 * dNext) / (h0 + h1);
      const lim = 3 * Math.min(Math.abs(dPrev), Math.abs(dNext));
      return Math.sign(m) * Math.min(Math.abs(m), lim);
    };
    const h = T(i + 1) - T(i), u = clamp((t - T(i)) / h), u2 = u * u, u3 = u2 * u;
    const h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
    out = {};
    for (const f of ['p', 't', 'up']) out[f] = [0, 1, 2].map(c => h00 * R[i][f][c] + h10 * h * tangent(i, f, c) + h01 * R[i + 1][f][c] + h11 * h * tangent(i + 1, f, c));
  }
  const pk = punchAt(t);
  const p = out.p.map((v, c) => out.t[c] + (v - out.t[c]) * (1 - pk));
  return { p, t: out.t, up: out.up };
}

// ---------------------------------------------------------------- background
const BOKEH = (() => { const r = rng(42); return Array.from({ length: 26 }, () => ({ x: r() * DW, y: r() * DH, r: 30 + r() * 110, c: [BRAND.cian, BRAND.azul, BRAND.ambar, '#ffffff'][Math.floor(r() * 4)], a: 0.05 + r() * 0.12, sp: 0.2 + r() * 0.6, ph: r() * 6 })); })();
const PAR = { x: 0, y: 0 };
function drawBG(t, studioOn) {
  { const f = camera.getWorldDirection(new THREE.Vector3()); PAR.x = -Math.atan2(f.x, -f.z) * 1400 - camera.position.x * 260; PAR.y = Math.asin(clamp(f.y, -1, 1)) * 1400 + camera.position.y * 120; }
  const x = bgg; x.setTransform(SC, 0, 0, SC, 0, 0);
  const gr = x.createLinearGradient(0, 0, 0, DH);
  if (studioOn) { gr.addColorStop(0, BRAND.marino); gr.addColorStop(0.55, '#1d4f8f'); gr.addColorStop(1, BRAND.azul); }
  else { gr.addColorStop(0, BRAND.marino); gr.addColorStop(0.35, '#1a467f'); gr.addColorStop(0.62, '#4C8FE2'); gr.addColorStop(1, '#a9c6ea'); }
  x.fillStyle = gr; x.fillRect(0, 0, DW, DH);
  x.globalCompositeOperation = 'lighter';
  for (const b of BOKEH) {
    const yy = ((b.y - t * 18 * b.sp + PAR.y * b.sp) % DH + DH) % DH; const xx = ((b.x + Math.sin(t * 0.4 + b.ph) * 20 + PAR.x * b.sp) % (DW + 200) + DW + 200) % (DW + 200) - 100;
    const rg = x.createRadialGradient(xx, yy, 0, xx, yy, b.r);
    const al = b.a * (0.7 + 0.3 * Math.sin(t * 1.3 + b.ph));
    rg.addColorStop(0, hexA(b.c, al)); rg.addColorStop(0.7, hexA(b.c, al * 0.6)); rg.addColorStop(1, hexA(b.c, 0));
    x.fillStyle = rg; x.beginPath(); x.arc(xx, yy, b.r, 0, 7); x.fill();
  }
  x.globalCompositeOperation = 'source-over';
}
function hexA(h, a) { const n = parseInt(h.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }
function vignette(x) {
  const rg = TV ? x.createRadialGradient(960, 520, 600, 960, 540, 1200) : x.createRadialGradient(540, 900, 500, 540, 960, 1250);
  rg.addColorStop(0, 'rgba(6,18,31,0)'); rg.addColorStop(1, 'rgba(6,18,31,0.55)');
  x.fillStyle = rg; x.fillRect(0, 0, DW, DH);
  // top darkening so the mark always reads
  const tg = x.createLinearGradient(0, 0, 0, 300); tg.addColorStop(0, 'rgba(6,18,31,0.55)'); tg.addColorStop(1, 'rgba(6,18,31,0)');
  x.fillStyle = tg; x.fillRect(0, 0, DW, 300);
}

// ---------------------------------------------------------------- per-frame 3D graphics
function setCardGloss(card, t) { card.face.material.opacity = 1; }
function updateHud(t) {
  // coin (S1 click, S4 click)
  coin.grp.visible = false;
  const coinShow = (t0, t1, x, y) => {
    if (t < t0 || t > t1) return false;
    const s = pop(prog(t, t0, t0 + 0.5)) * (t > t1 - 0.15 ? 1 - prog(t, t1 - 0.15, t1) : 1);
    const press = t > t1 - 0.32 ? Math.sin(prog(t, t1 - 0.32, t1 - 0.15) * Math.PI) * 0.18 : 0;
    coin.grp.visible = true;
    hudPlace(coin.grp, x, y + Math.sin(t * 3) * 8, 250 * s * (1 - press), 2.2);
    coin.spin.rotation.y = Math.sin(t * 2.2) * 0.5 + (1 - prog(t, t0, t0 + 0.6)) * 6;
    coin.spin.rotation.x = 0.15 + Math.sin(t * 1.7) * 0.12;
    return true;
  };
  coinShow(1.9, 2.95, LT(760, 1400), LT(1330, 640));
  // photo card: pops out of the phone at 7.5 → floats right → returns 10.7
  photoCard.grp.visible = false;
  if (t > 7.45 && t < 11.0) {
    photoCard.grp.visible = true;
    const sp = rig.phone.getWorldPosition(new THREE.Vector3());
    const from = toPx(sp);
    const k = easeOutBack(prog(t, 7.45, 8.25), 1.2);
    const tx = LT(735, 1400), ty = LT(1020, 600);
    const out = easeIn(prog(t, 10.55, 11.0));
    let x = lerp(from.x, tx, k), y = lerp(from.y, ty, k), hpx = lerp(60, 380, clamp(k));
    x = lerp(x, from.x, out); y = lerp(y, from.y, out); hpx = lerp(hpx, 40, out);
    hudPlace(photoCard.grp, x, y + Math.sin(t * 2) * 6, hpx, 2.0);
    photoCard.inner.rotation.set(0.12 + Math.sin(t * 1.4) * 0.06, -0.25 + Math.sin(t * 1.1) * 0.12, 0.12 - (1 - clamp(k)) * 0.6);
  }
  // post card: from phone at 20.9 → big center → back at 24.6; S5: flies up at 26.2
  postCard.grp.visible = false; PROOF.rect = null;
  if (t > LT(20.9, 21.2) && t < 24.9) {
    postCard.grp.visible = true;
    const from = toPx(rig.phone.getWorldPosition(new THREE.Vector3()));
    const k = TV ? easeOutBack(prog(t, 21.2, 21.95), 1.1) : easeOutBack(prog(t, 20.9, 21.7), 1.1); const out = easeIn(prog(t, 24.45, 24.9));
    let x = lerp(from.x, LT(540, 1060), k), y = lerp(from.y, LT(905, 610), k), hpx = lerp(120, LT(800, 740), clamp(k));
    x = lerp(x, from.x, out); y = lerp(y, from.y, out); hpx = lerp(hpx, 80, out);
    hudPlace(postCard.grp, x, y + Math.sin(t * 2) * 6, hpx, 0.2);   // in front of the phone (camera ≈0.37 m away)
    { const hh = hpx * 1.06, ww = hh * 0.8; PROOF.rect = { x: x - ww / 2, y: y - hh / 2, w: ww, h: hh }; }
    postCard.inner.rotation.set(0.05 + Math.sin(t * 1.3) * 0.05, Math.sin((t - 21) * 0.9) * 0.32, (1 - clamp(k)) * 0.4 - 0.02);
  } else if (t > 26.15 && t < 27.4) {
    postCard.grp.visible = true;
    const from = toPx(rig.phone.getWorldPosition(new THREE.Vector3()));
    const k = easeIn(prog(t, 26.15, 27.2));
    const kk = easeOut(prog(t, 26.15, 26.45));
    const gone = easeIn(prog(t, 26.45, 26.85)); const hp = lerp(200, LT(560, 520), kk) * (1 - k * 0.4) * (1 - gone);
    const yy = Math.max(lerp(from.y, LT(700, 520), kk) - k * LT(1500, 1000), LT(260, 220) + hp * 0.55);
    if (gone >= 1) postCard.grp.visible = false; else hudPlace(postCard.grp, lerp(from.x, LT(600, 1300), kk), yy, hp, 0.2);
    postCard.inner.rotation.set(-0.3 * k, k * 2.2, 0.1 - k * 0.3);
  }
  // style cards S6
  styleCards.forEach(c => c.grp.visible = false);
  if (t > 31.15 && t < 37.0) {
    const names = [0, 1, 2];
    names.forEach((i) => {
      const c = styleCards[i]; c.grp.visible = true;
      const t0 = 31.25 + i * 0.22;
      const k = easeOutBack(prog(t, t0, t0 + 0.7), 1.3);
      const out = easeIn(prog(t, 36.6, 37.0));
      const spread = easeInOut(prog(t, 32.0, 32.8));
      const xs = TV ? [880, 1220, 1560][i] : [270, 540, 810][i], rot = [-0.16, 0, 0.16][i];
      const focus = [33.2, 34.3, 35.4][i];
      const f = env(t, focus, focus + 1.2, 0.3, 0.3);
      const x = lerp(LT(540, 1220), xs, spread);
      const y = LT(830, 555) - f * 30 + Math.sin(t * 1.8 + i) * 8;
      const hp = LT(520, 470) + f * 90 + (i === 1 ? 30 : 0);
      const xin = i === 0 ? LT(-500, 700) : i === 2 ? LT(1580, 2400) : LT(540, 1220); const xo = lerp(lerp(xin, x, Math.min(1, k)), i === 0 ? LT(-600, 2500) : i === 2 ? LT(1680, 2600) : LT(1750, 2550), out); const yo = TV && i === 0 ? lerp(y, 1500, 1 - Math.min(1, k)) : y;
      hudPlace(c.grp, xo, yo, (i === 1 ? Math.max(0.001, k) : 1) * hp * (1 - out * 0.3), 2.2 + 0.1 * (1 - f) - f * 0.35 - (i === 1 ? 0.03 : 0));
      c.inner.rotation.set((0.05 + Math.sin(t * 1.2 + i) * 0.05) * (1 - f), (lerp(0, [0.42, 0, -0.42][i], spread) + Math.sin(t * 0.9 + i * 2) * 0.12) * (1 - f), rot * spread * (1 - f));
    });
  }
  // video phone S7
  vidPhone.grp.visible = false;
  if (t > 37.0 && t < 44.0) {
    vidPhone.grp.visible = true;
    const k = easeOutBack(prog(t, 37.15, 37.85), 1.2); const out = easeIn(prog(t, 43.6, 44.0));
    hudPlace(vidPhone.grp, LT(815, 860) + (1 - k) * LT(500, 1000) + out * LT(700, 1100), LT(905, 560), LT(780, 760), 2.2);
    vidPhone.inner.rotation.set(0.04 + Math.sin(t * 1.1) * 0.04, -0.2 + Math.sin(t * 0.8) * 0.1, 0.03);
    newsFrame(vidPhone.ctx, Math.max(0, t - 37.2), 540, 960, 43.9 - 37.2); vidPhone.tex.needsUpdate = true;
  }
  // sponsor card S8
  sponsorCard.grp.visible = false;
  if (t > 44.0 && t < 50.0) {
    sponsorCard.grp.visible = true;
    const k = easeOutBack(prog(t, 44.15, 44.85), 1.2); const out = easeIn(prog(t, 49.6, 50.0));
    hudPlace(sponsorCard.grp, LT(255, 1000) + (1 - k) * LT(-500, 1000) + out * LT(-700, 1100), LT(890, 560), LT(620, 640), 2.2);
    sponsorCard.inner.rotation.set(0.05 + Math.sin(t * 1.1) * 0.04, 0.22 + Math.sin(t * 0.8) * 0.1, -0.03);
    drawSponsor(t);
  }
  // hero logo plate: drops in on the 60.5 s hit with glow, gloss sweep and reflection
  logoPlate.grp.visible = false;
  if (t > 58.5) {
    // enters with proaudih.com at 58.5 (easeOutBack, never deformed), holds still, only a uniform pulse on the 60.5 hit
    logoPlate.grp.visible = true;
    const k = easeOutBack(prog(t, 58.5, 59.0), 1.4);
    const pulse = t > 60.5 ? 1 + 0.07 * Math.exp(-(t - 60.5) * 6) * Math.sin(Math.min(Math.PI, (t - 60.5) * 14)) : 1;
    const y = lerp(LT(260, 180), LT(425, 330), easeOutCubic(prog(t, 58.5, 58.95)));
    hudPlace(logoPlate.grp, LT(540, 1400), y, LT(330, 300) * Math.max(0.001, k) * pulse, 2.0);
    logoPlate.inner.scale.set(1, 1, 1);
    logoPlate.inner.rotation.set(0.06 + 0.02 * fbm(t, 61, 0.4), (1 - clamp(k)) * -0.5 + 0.06 * fbm(t, 62, 0.3), -0.03);
    logoPlate.glow.material.opacity = 0.3 * clamp(k) + (t > 60.5 ? 0.6 * Math.exp(-(t - 60.5) * 3) : 0);
    logoPlate.sweep.material.opacity = t > 60.55 ? 0.9 * Math.sin(Math.min(1, (t - 60.55) / 0.7) * Math.PI) : 0;
    logoPlate.sweep.material.map.offset.x = -0.6 + clamp((t - 60.55) / 0.7) * 1.2;
  }
}
const SPONSORS = ['TU NEGOCIO AQUÍ', 'ESPACIO PATROCINADO', 'TU MARCA EN CADA NOTICIA', 'ANUNCIA CON NOSOTROS'];
function drawSponsor(t) {
  const c = sponsorCard, x = c.ctx, w = c.cv.width, h = c.cv.height;
  x.drawImage(A.posts.clasico, 0, 0, w, h);
  // sponsor ribbon (scrolling)
  const rh = 66, ry = h - rh - 6;
  x.fillStyle = BRAND.ambar; x.fillRect(0, ry, w, rh);
  x.fillStyle = BRAND.noche; x.fillRect(0, ry, 170, rh);
  x.fillStyle = '#fff'; x.font = '26px UneCond'; x.textBaseline = 'middle'; x.fillText('PATROCINA', 20, ry + rh / 2);
  x.save(); x.beginPath(); x.rect(170, ry, w - 170, rh); x.clip();
  x.fillStyle = BRAND.noche; x.font = '34px UneDisplay';
  const txt = SPONSORS.join('   •   ') + '   •   ';
  const tw = x.measureText(txt).width; const off = ((t - 44) * 120) % tw;
  for (let k = -1; k < 3; k++) x.fillText(txt, 190 - off + k * tw, ry + rh / 2 + 2);
  x.restore();
  // logo bug
  x.fillStyle = 'rgba(6,18,31,0.8)'; x.beginPath(); x.roundRect(24, 64, 170, 54, 12); x.fill();
  x.strokeStyle = '#3DE0FF'; x.lineWidth = 2; x.setLineDash([6, 5]); x.stroke(); x.setLineDash([]);
  x.font = '26px UneDisplay'; x.fillStyle = '#fff'; x.textAlign = 'center'; x.fillText('TU LOGO', 109, 92); x.textAlign = 'left';
  c.tex.needsUpdate = true;
}

// ---------------------------------------------------------------- phone screen per time
function screenAt(t) {
  const d = screenAt0(t);
  const kb = Math.round(Math.min(smooth(prog(t, 12.05, 12.4)), 1 - smooth(prog(t, 16.65, 17.0))) * 20) / 20;
  if (kb > 0 && d.kind === 'app') { d.kb = kb; d.typed = typedTextAt(t); const k = typedKey(t); if (k) { d.key = { row: k.row, col: k.col, space: !!k.space }; const T = TYPING_TAPS.find(tt => t >= tt && t - tt < 0.1); d.kp = Math.round((1 - (t - T) / 0.1) * 4) / 4; } }
  return d;
}
function screenAt0(t) {
  if (t < 5.6) return { kind: 'app', a: 1, k: 0 };
  if (t < 6.85) return { kind: 'viewfinder', z: smooth(prog(t, 5.8, 6.8)), ox: Math.round(Math.sin(t * 3) * 6), press: t > 6.74 ? { which: 'shutter', k: Math.round(Math.sin(prog(t, 6.74, 6.95) * Math.PI) * 6) / 6 } : null };
  if (t < 7.15) return { kind: 'photo', flash: Math.round((1 - prog(t, 6.85, 7.15)) * 10) / 10 };
  if (t < 10.9) return { kind: 'photo' };
  if (t < 11.45) return { kind: 'app', a: 1, b: 3, k: Math.round(smooth(prog(t, 10.9, 11.4)) * 15) / 15 };   // app1 → app3 directly (no download screen)
  if (t < 14.6) return { kind: 'app', a: 3, k: 0 };
  if (t < 15.05) return { kind: 'app', a: 3, b: 4, k: Math.round(smooth(prog(t, 14.6, 15.0)) * 15) / 15 };
  if (t < 19.75) return { kind: 'app', a: 4, k: 0, full: t >= 16.6, press: t > 19.38 ? { which: 'preparar', k: Math.round(Math.sin(prog(t, 19.38, 19.7) * Math.PI) * 6) / 6 } : null };
  if (t < 20.4) return { kind: 'app', a: 4, b: 5, k: Math.round(smooth(prog(t, 19.75, 20.3)) * 15) / 15 };
  if (t < 24.6) return { kind: 'app', a: 5, k: 0 };
  if (t < 25.2) return { kind: 'app', a: 5, b: 6, k: Math.round(smooth(prog(t, 24.6, 25.1)) * 15) / 15 };
  return { kind: 'app', a: 6, k: 0, press: t > 25.93 && t < 26.25 ? { which: 'subir', k: Math.round(Math.sin(prog(t, 25.93, 26.25) * Math.PI) * 6) / 6 } : null };
}
function phoneHotspotPx(which) {
  const hp = HOTSPOT[which];
  const v = new THREE.Vector3((hp.x - 0.5) * PHONE.SW, (0.5 - hp.y) * PHONE.SH, PHONE.T / 2 + 0.001);
  rig.phone.localToWorld(v);
  return toPx(v);
}

// ---------------------------------------------------------------- overlay timeline
const ORANGE = [BRAND.ambar, BRAND.naranja];
const FIRE = [BRAND.ambar, BRAND.naranja, BRAND.brasa];
function drawOverlay(t) {
  g.setTransform(SC, 0, 0, SC, 0, 0);
  g.clearRect(0, 0, DW, DH);
  vignette(g);
  O.timeline(g, t, { TV, DW, DH, logo: A.logoSmall || A.logo, logoBig: A.logo, proofRect: PROOF.rect, wipes: CUTS });
  drawTaps(t);
  reactions(g, t);
}
// ---- screen taps (WP2): golden 2D hand-cursor + cyan ring at the projected hotspot; the key/button lights up on the phone
const SHUT = () => HOTSPOT.shutter || SHUTTER;
const TAPSEQ = [
  { enter: 6.35, exit: 7.15, taps: () => [[6.8, SHUT().x, SHUT().y]], btn: true },
  { enter: 12.0, exit: 16.85, taps: () => TYPING_TAPS.map((tt, i) => { const k = keyPos(i); return [tt, k.x, k.y]; }), btn: false },
  { enter: 18.95, exit: 19.85, taps: () => [[19.4, HOTSPOT.preparar.x, HOTSPOT.preparar.y]], btn: true, color: BRAND.ambar },
  { enter: 25.5, exit: 26.4, taps: () => [[25.95, HOTSPOT.subir.x, HOTSPOT.subir.y]], btn: true },
];
const CS = TV ? 0.5 : 0.6;   // cursor scale (design px)
function screenPx(nx, ny) { const v = new THREE.Vector3((nx - 0.5) * PHONE.SW, (0.5 - ny) * PHONE.SH, PHONE.T / 2 + 0.001); rig.phone.localToWorld(v); return toPx(v); }
function drawTaps(t) {
  for (const sq of TAPSEQ) {
    if (t < sq.enter - 0.2 || t > sq.exit + 0.6) continue;
    const taps = sq.taps();
    // WP4 tap (cursor + ring) for single button taps
    if (sq.btn && O.tapAt) { for (const [tt, nx, ny] of taps) { const q = screenPx(nx, ny); O.tapAt(g, t, tt, q.x, q.y, { scale: CS / 0.6, color: sq.color || BRAND.cian }); } continue; }
    // moving cursor (typing): hops key to key, presses on every typing click
    let x, y, press = 0, alpha = 1;
    const P0 = screenPx(taps[0][1], taps[0][2]), PL = screenPx(taps[taps.length - 1][1], taps[taps.length - 1][2]);
    const off = (q) => ({ x: q.x + LT(420, 520), y: q.y + LT(620, 520) });
    if (t < taps[0][0] - 0.08) { const k = easeOutCubic(prog(t, sq.enter, taps[0][0] - 0.08)); const o = off(P0); x = lerp(o.x, P0.x, k); y = lerp(o.y, P0.y, k); alpha = prog(t, sq.enter, sq.enter + 0.12); }
    else if (t > taps[taps.length - 1][0] + 0.1) { const k = easeInCubic(prog(t, taps[taps.length - 1][0] + 0.1, sq.exit)); const o = off(PL); x = lerp(PL.x, o.x, k); y = lerp(PL.y, o.y, k); alpha = 1 - prog(t, sq.exit - 0.1, sq.exit); }
    else {
      let i = 0; while (i < taps.length - 1 && t >= taps[i + 1][0]) i++;
      const A0 = screenPx(taps[i][1], taps[i][2]);
      if (i < taps.length - 1 && t > taps[i][0]) {
        const B = screenPx(taps[i + 1][1], taps[i + 1][2]); const dt = taps[i + 1][0] - taps[i][0];
        const u = easeInOutQuad(prog(t, taps[i][0] + 0.3 * dt, taps[i + 1][0] - 0.15 * dt));
        x = lerp(A0.x, B.x, u); y = lerp(A0.y, B.y, u) - 14 * Math.sin(Math.PI * u);
      } else { x = A0.x; y = A0.y; }
      for (const [tt] of taps) { const d = t - tt; if (d > -0.05 && d < 0.08) press = Math.max(press, d < 0 ? 1 + d / 0.05 : 1 - d / 0.08); }
    }
    if (alpha <= 0) continue;
    // rings at each click
    for (const [tt, nx, ny] of taps) { const d = t - tt; if (d < 0 || d > 0.45) continue; const q = screenPx(nx, ny);
      if (O.drawTap) O.drawTap(g, q.x, q.y, (d + 0.12) / 0.45, { scale: CS / 0.6 * 0.7, cursor: false }); else tapRing(g, q.x, q.y, d / 0.45); }
    O.cursor(g, x, y, CS * (1 - 0.06 * press), press, clamp(alpha));
  }
  // legacy fallback rings for single taps when WP4's tapAt is missing
  if (!O.tapAt) for (const sq of TAPSEQ) if (sq.btn) for (const [tt, nx, ny] of sq.taps()) {
    const d = t - tt; if (d < -0.45 || d > 0.6) continue; const q = screenPx(nx, ny);
    if (d >= 0) O.ripple(g, q.x, q.y, d, sq.color || BRAND.cian);
    const k = d < 0 ? easeOutCubic(prog(t, tt - 0.45, tt - 0.05)) : 1; const o = { x: q.x + LT(420, 520), y: q.y + LT(620, 520) };
    O.cursor(g, lerp(o.x, q.x, k), lerp(o.y, q.y, k), CS, d > -0.05 && d < 0.1 ? 1 : 0, 1 - prog(t, tt + 0.35, tt + 0.6));
  }
}
const PROOF = { rect: null };
function tapRing(x, cx, cy, k) {
  x.save(); x.globalAlpha = (1 - k) * 0.9; x.strokeStyle = BRAND.cian; x.lineWidth = 6 * (1 - k) + 1.5;
  x.beginPath(); x.arc(cx, cy, 10 + k * 34, 0, 7); x.stroke();
  x.globalAlpha = (1 - k) * 0.5; x.fillStyle = '#ffffff'; x.beginPath(); x.arc(cx, cy, 9 * (1 - k), 0, 7); x.fill(); x.restore();
}
function burst(x, dt, cx, cy) {
  if (dt < 0 || dt > 0.7) return;
  const r = rng(5);
  x.save();
  for (let i = 0; i < 18; i++) {
    const a = r() * Math.PI * 2, sp = 300 + r() * 500, k = dt;
    const px = cx + Math.cos(a) * sp * k, py = cy + Math.sin(a) * sp * k + 600 * k * k;
    x.globalAlpha = 1 - dt / 0.7; x.fillStyle = [BRAND.ambar, '#fff3b0', BRAND.naranja][i % 3];
    x.beginPath(); x.arc(px, py, 10 * (1 - k), 0, 7); x.fill();
  }
  x.restore();
}
function reactions(x, t) {
  if (t < 27.3 || t > 30.8) return;   // after the 27 s navy wipe has opened
  const r = rng(11);
  const kinds = ['heart', 'like', 'comment', 'heart', 'star', 'like', 'heart', 'comment', 'like', 'heart', 'star', 'heart', 'like', 'comment'];
  kinds.forEach((kd, i) => {
    const t0 = 27.3 + i * 0.16 + r() * 0.1; const life = 1.9 + r() * 0.8;
    const k = (t - t0) / life; if (k < 0 || k > 1) return;
    const side = i % 2 ? 1 : -1; const sx = TV ? 1400 + side * (90 + r() * 330) : 540 + side * (230 + r() * 260); const drift = (r() - 0.5) * 160;
    const y = LT(1650, 1080) - easeOut(k) * (LT(900, 600) + r() * LT(400, 250));
    const s = pop(clamp(k * 4)) * (0.8 + r() * 0.5) * (1 - easeIn(clamp((k - 0.8) / 0.2)));
    const lim = LT(640, 470), fade = clamp((y - lim) / 140); if (fade <= 0) return;   // never over the ¡PUBLICADO! title
    O.reaction(x, kd, sx + drift * k + Math.sin(k * 8 + i) * 18, y, s * (0.85 + 0.15 * fade), fade);
  });
}
function wipe(x, t, t0, t1) {
  if (t < t0 || t > t1) return;
  const k = (t - t0) / (t1 - t0);
  const cols = [BRAND.cian, BRAND.azul, BRAND.marino, BRAND.naranja, BRAND.ambar];
  x.save(); x.translate(DW / 2, DH / 2); x.rotate(-0.35); if (TV) x.scale(1.4, 1);
  cols.forEach((c, i) => {
    const d = i * 0.06; const kk = easeInOut(clamp((k - d) / (1 - 0.24)));
    const xx = lerp(-2400, 2400, kk);
    x.fillStyle = c; x.fillRect(xx - 1200 + (i - 2) * 90, -1600, 1700 - i * 120, 3200);
  });
  x.restore();
}

// ---------------------------------------------------------------- render
function render(t) {
  t = clamp(t, 0, DUR);
  const studioOn = t >= 31.0;
  street.visible = !studioOn; studio.visible = studioOn;
  scene.fog = studioOn ? null : FOG_STREET;
  // light framing
  if (studioOn) { lights.key.position.set(-3, 6, 5); lights.key.target.position.set(0, 0.6, 0); lights.rim.position.set(4, 4, -5); lights.hemi.intensity = 1.9; }
  else { lights.key.position.set(-7, 8, 2.5); lights.key.target.position.set(0, 0, 0); lights.rim.position.set(5, 4, -8); lights.hemi.intensity = 1.6; }
  const sc = lights.key.shadow.camera;
  if (studioOn) { sc.left = -2; sc.right = 2; sc.top = 3; sc.bottom = -1; } else { sc.left = -7; sc.right = 7; sc.top = 7; sc.bottom = -7; }
  sc.updateProjectionMatrix();

  const P = poseAt(t);
  rig.setPose(P);
  { const sy = P.sqY || 1, sx = 1 / Math.sqrt(sy); rig.root.scale.set(sx, sy, sx); }   // squash & stretch (jumps)
  drawScreen(screenAt(t));
  rig.lapTex.needsUpdate = false;

  const c = camAt(t);
  camera.position.fromArray(c.p); camera.up.fromArray(c.up).normalize(); camera.lookAt(new THREE.Vector3().fromArray(c.t));
  // handheld drift ±0.3° (multi-octave noise, deterministic)
  const HHA = 0.3 * Math.PI / 180;
  camera.rotateY(HHA * fbm(t, 91, 0.35)); camera.rotateX(HHA * 0.8 * fbm(t, 92, 0.3)); camera.rotateZ(HHA * 0.5 * fbm(t, 93, 0.25));
  camera.updateMatrixWorld(true);
  rig.root.updateMatrixWorld(true);
  updateHud(t);
  drawBG(t, studioOn);
  renderer.render(scene, camera);
  drawOverlay(t);
}

window.ready = init().then(() => { window.__gl = { renderer, scene, camera, rig }; render(0); return true; });
window.render = (t) => render(t);
window.DUR = DUR;
window.missingAssets = () => A.missing;
