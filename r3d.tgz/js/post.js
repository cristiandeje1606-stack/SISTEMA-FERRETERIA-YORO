// WP3 finishing layer (no WebGL cost): vignette between the 3D canvas and the 2D overlays, optional grade of the 3D layer only.
// The 3D canvas stays transparent, so the 2D background and the overlays keep their exact brand colours.
// URL flags: vig=<0..1> (default 0.25, 0 = off) · grade=0|1 (default 1: light warm/contrast grade on the 3D layer).
const Q = new URLSearchParams(location.search);
const VIG = Q.get('vig') === null ? 0.25 : +Q.get('vig');
const GRADE = Q.get('grade') !== '0' && Q.get('look') !== '0';
const gl = document.getElementById('gl'), fx = document.getElementById('fx'), stage = document.getElementById('stage');
if (GRADE && gl) gl.style.filter = 'contrast(1.06) saturate(1.12)';
if (VIG > 0 && stage && fx && Q.get('look') !== '0') {
  const v = document.createElement('div'); v.id = 'vig';
  v.style.cssText = `position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;` +
    `background:radial-gradient(ellipse 75% 70% at 50% 48%, rgba(6,18,31,0) 55%, rgba(6,18,31,${(VIG * 0.6).toFixed(3)}) 80%, rgba(6,18,31,${VIG.toFixed(3)}) 100%)`;
  stage.insertBefore(v, fx);
}
