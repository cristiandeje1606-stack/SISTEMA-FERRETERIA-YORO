// Procedural chibi street reporter (clay / animated-movie look)
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

function phys(color, o = {}) {
  return new THREE.MeshPhysicalMaterial({ color, roughness: 0.55, metalness: 0, clearcoat: 0.25, clearcoatRoughness: 0.5, sheen: 0.3, sheenRoughness: 0.6, sheenColor: new THREE.Color('#ffffff'), envMapIntensity: 0.7, ...o });
}
function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function mesh(geo, mat, cast = true) { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; return m; }
function capsule(r, len, mat, seg = 16) { return mesh(new THREE.CapsuleGeometry(r, len, 8, seg), mat); }

export const DEFAULT_POSE = {
  x: 0, y: 0, z: 0, rotY: 0, lean: 0, bob: 0,
  torsoX: 0, torsoY: 0, torsoZ: 0,
  headX: 0, headY: 0, headZ: 0,
  // right arm (character's right, screen-left when facing camera) holds the phone
  rFwd: 0.05, rOut: 0.18, rTwist: 0, rElbow: -0.15, rWristX: 0, rWristY: 0, rWristZ: 0,
  lFwd: 0.05, lOut: 0.18, lTwist: 0, lElbow: -0.15, lWristX: 0, lWristY: 0, lWristZ: 0,
  rLeg: 0, lLeg: 0, rKnee: 0, lKnee: 0, legSpread: 0.04,
  brow: 0, browTilt: 0, mouthOpen: 0, smile: 1, eyeX: 0, eyeY: 0, blink: 0, eyeScale: 1,
  thumb: 0, mic: 1, phone: 1, pRX: 0, pRY: 0, pRZ: 0, point: 0, laptop: 0, phoneScale: 1, aimW: 0, aimYaw: 0, aimPitch: 0, aimRoll: 0,
};

export function buildReporter() {
  const C = {
    skin: phys('#a8673e', { roughness: 0.48, sheen: 0.5, sheenColor: new THREE.Color('#ffb48a'), clearcoat: 0.12 }),
    skinDark: phys('#8a5230', { roughness: 0.5 }),
    hair: phys('#22170f', { roughness: 0.62, clearcoat: 0.15, clearcoatRoughness: 0.6, sheen: 0.5, sheenColor: new THREE.Color('#6a4a35') }),
    shirt: phys('#f3f6fb', { roughness: 0.7, sheen: 0.6 }),
    vest: phys('#0e2a48', { roughness: 0.6, sheen: 0.5, sheenColor: new THREE.Color('#4c8fe2') }),
    trim: phys('#08E1FF', { roughness: 0.35, emissive: '#0aa6c0', emissiveIntensity: 0.25 }),
    jeans: phys('#33435e', { roughness: 0.75, sheen: 0.4 }),
    shoe: phys('#ffffff', { roughness: 0.4, clearcoat: 0.5 }),
    sole: phys('#F6901C', { roughness: 0.5 }),
    eyeW: new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0.15, clearcoat: 1, clearcoatRoughness: 0.05 }),
    iris: new THREE.MeshPhysicalMaterial({ color: '#4a2a14', roughness: 0.2, clearcoat: 1 }),
    pupil: new THREE.MeshPhysicalMaterial({ color: '#0a0604', roughness: 0.15, clearcoat: 1 }),
    hl: new THREE.MeshBasicMaterial({ color: '#ffffff' }),
    mouth: phys('#4a1414', { roughness: 0.5 }),
    tongue: phys('#e0606a', { roughness: 0.5 }),
    teeth: phys('#ffffff', { roughness: 0.3 }),
    blush: new THREE.MeshPhysicalMaterial({ color: '#ff7a6a', roughness: 0.6, transparent: true, opacity: 0.32, depthWrite: false }),
    black: phys('#16181c', { roughness: 0.35, clearcoat: 0.6 }),
    metal: new THREE.MeshPhysicalMaterial({ color: '#5a6270', roughness: 0.35, metalness: 0.8, envMapIntensity: 1 }),
  };

  const root = new THREE.Group(); root.name = 'reporter';
  const hips = new THREE.Group(); hips.position.y = 0.43; root.add(hips);

  // ---------- legs
  const legs = {};
  for (const s of ['l', 'r']) {
    const sx = s === 'l' ? 1 : -1;
    const hip = new THREE.Group(); hip.position.set(sx * 0.095, 0.02, 0); hips.add(hip);
    const thigh = capsule(0.078, 0.14, C.jeans); thigh.position.y = -0.1; hip.add(thigh);
    const knee = new THREE.Group(); knee.position.y = -0.2; hip.add(knee);
    const shin = capsule(0.07, 0.12, C.jeans); shin.position.y = -0.08; knee.add(shin);
    const cuff = mesh(new THREE.TorusGeometry(0.068, 0.014, 8, 20), C.jeans); cuff.rotation.x = Math.PI / 2; cuff.position.y = -0.16; knee.add(cuff);
    const foot = new THREE.Group(); foot.position.y = -0.2; knee.add(foot);
    const shoe = mesh(new RoundedBoxGeometry(0.13, 0.085, 0.235, 4, 0.04), C.shoe); shoe.position.set(0, -0.018, 0.04); foot.add(shoe);
    const sole = mesh(new RoundedBoxGeometry(0.138, 0.03, 0.245, 3, 0.012), C.sole); sole.position.set(0, -0.055, 0.04); foot.add(sole);
    const lace = mesh(new THREE.BoxGeometry(0.06, 0.012, 0.07), C.trim, false); lace.position.set(0, 0.02, 0.07); lace.rotation.x = -0.35; foot.add(lace);
    legs[s] = { hip, knee, foot };
  }

  // ---------- torso
  const torso = new THREE.Group(); hips.add(torso);
  const pants = mesh(new THREE.CapsuleGeometry(0.178, 0.05, 8, 28), C.jeans); pants.scale.set(1, 0.9, 0.8); pants.position.y = 0.07; torso.add(pants);
  const body = mesh(new THREE.CapsuleGeometry(0.2, 0.17, 10, 28), C.vest); body.scale.set(1, 1, 0.8); body.position.y = 0.29; torso.add(body);
  // shirt collar + chest V
  const collar = mesh(new THREE.TorusGeometry(0.085, 0.03, 10, 24), C.shirt); collar.rotation.x = Math.PI / 2 - 0.25; collar.position.set(0, 0.555, 0.0); torso.add(collar);
  // vest trims (hem, neckline, zip)
  const hem = mesh(new THREE.TorusGeometry(0.2, 0.014, 8, 40), C.trim, false); hem.rotation.x = Math.PI / 2; hem.scale.set(1.02, 0.82, 1); hem.position.y = 0.13; torso.add(hem);
  const zip = mesh(new THREE.BoxGeometry(0.014, 0.3, 0.01), C.trim, false); zip.position.set(0, 0.3, 0.163); torso.add(zip);
  // PRENSA patches (wrap around vest)
  const prensaTex = (big) => canvasTex(512, big ? 160 : 128, (g, w, h) => {
    g.fillStyle = '#08E1FF'; const r = 22;
    g.beginPath(); g.roundRect(6, 6, w - 12, h - 12, r); g.fill();
    g.fillStyle = '#0B2238'; g.beginPath(); g.roundRect(14, 14, w - 28, h - 28, r - 6); g.fill();
    g.fillStyle = '#ffffff'; g.font = `${big ? 90 : 80}px UneDisplay, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('PRENSA', w / 2, h / 2 + 6);
  });
  const backPatch = new THREE.Mesh(new THREE.CylinderGeometry(0.206, 0.206, 0.11, 32, 1, true, Math.PI - 0.75, 1.5), new THREE.MeshPhysicalMaterial({ map: prensaTex(true), roughness: 0.5, transparent: true }));
  backPatch.scale.set(1, 1, 0.8); backPatch.position.y = 0.36; torso.add(backPatch);
  const chestPatch = new THREE.Mesh(new THREE.CylinderGeometry(0.205, 0.205, 0.045, 24, 1, true, 0.25, 0.62), new THREE.MeshPhysicalMaterial({ map: prensaTex(false), roughness: 0.5, transparent: true }));
  chestPatch.scale.set(1, 1, 0.8); chestPatch.position.y = 0.4; torso.add(chestPatch);
  // pocket on right chest
  const pocket = mesh(new RoundedBoxGeometry(0.075, 0.06, 0.02, 2, 0.008), C.vest); pocket.position.set(-0.085, 0.23, 0.155); pocket.rotation.y = -0.45; torso.add(pocket);
  const pocketT = mesh(new THREE.BoxGeometry(0.077, 0.008, 0.022), C.trim, false); pocketT.position.set(-0.085, 0.262, 0.156); pocketT.rotation.y = -0.45; torso.add(pocketT);

  // ---------- neck + head
  const neck = capsule(0.06, 0.04, C.skin); neck.position.y = 0.53; torso.add(neck);
  const headPivot = new THREE.Group(); headPivot.position.y = 0.56; torso.add(headPivot);
  const head = new THREE.Group(); head.position.y = 0.26; headPivot.add(head);
  const skull = mesh(new THREE.SphereGeometry(0.3, 48, 32), C.skin); skull.scale.set(1.0, 0.94, 0.92); head.add(skull);
  // jaw/cheek volume
  const chin = mesh(new THREE.SphereGeometry(0.25, 32, 20), C.skin); chin.scale.set(1.0, 0.8, 0.88); chin.position.set(0, -0.06, 0.035); head.add(chin);
  // ears
  for (const sx of [1, -1]) {
    const ear = mesh(new THREE.SphereGeometry(0.06, 16, 12), C.skin); ear.scale.set(0.55, 0.9, 0.6); ear.position.set(sx * 0.292, -0.02, -0.01); head.add(ear);
    const inner = mesh(new THREE.SphereGeometry(0.035, 12, 10), C.skinDark, false); inner.scale.set(0.4, 0.8, 0.5); inner.position.set(sx * 0.305, -0.02, 0.0); head.add(inner);
  }
  // hair: cap + quiff + sideburns
  const cap = mesh(new THREE.SphereGeometry(0.318, 40, 24, 0, Math.PI * 2, 0, Math.PI * 0.5), C.hair);
  cap.scale.set(1.03, 1.0, 0.98); cap.rotation.x = -0.32; cap.position.set(0, 0.03, -0.01); head.add(cap);
  const back = mesh(new THREE.SphereGeometry(0.3, 32, 20), C.hair); back.scale.set(1.02, 0.85, 0.86); back.position.set(0, 0.03, -0.07); head.add(back);
  // quiff: overlapping clay locks sweeping forward/up
  const locks = [[0.0, 0.265, 0.12, 0.13, 0.0, -0.35], [-0.12, 0.25, 0.1, 0.11, 0.25, -0.3], [0.12, 0.25, 0.1, 0.11, -0.25, -0.3], [-0.06, 0.28, 0.02, 0.12, 0.1, -0.2], [0.07, 0.28, 0.0, 0.12, -0.1, -0.2], [0.0, 0.215, 0.2, 0.09, 0, -0.7], [-0.2, 0.19, 0.12, 0.08, 0.6, -0.2], [0.2, 0.19, 0.12, 0.08, -0.6, -0.2]];
  for (const [x, y, z, r, rz, rx] of locks) { const t = mesh(new THREE.SphereGeometry(r, 20, 14), C.hair); t.scale.set(1.2, 0.6, 1.25); t.position.set(x, y, z); t.rotation.set(rx, 0, rz); head.add(t); }
  for (const sx of [1, -1]) { const sb = mesh(new THREE.SphereGeometry(0.045, 12, 10), C.hair); sb.scale.set(0.6, 1.4, 0.8); sb.position.set(sx * 0.27, 0.06, 0.06); head.add(sb); }

  // face features (face is +Z)
  const face = new THREE.Group(); head.add(face);
  const eyes = [];
  for (const sx of [1, -1]) {
    const eg = new THREE.Group(); eg.position.set(sx * 0.105, 0.0, 0.245); eg.rotation.y = sx * 0.33; face.add(eg);
    const white = mesh(new THREE.SphereGeometry(0.072, 28, 20), C.eyeW, false); white.scale.set(0.9, 1.08, 0.5); eg.add(white);
    const iris = new THREE.Group(); eg.add(iris);
    const ir = mesh(new THREE.SphereGeometry(0.048, 24, 16), C.iris, false); ir.scale.set(1, 1.08, 0.42); ir.position.z = 0.024; iris.add(ir);
    const pu = mesh(new THREE.SphereGeometry(0.028, 16, 12), C.pupil, false); pu.scale.set(1, 1.08, 0.4); pu.position.z = 0.036; iris.add(pu);
    const h1 = mesh(new THREE.SphereGeometry(0.014, 10, 8), C.hl, false); h1.position.set(0.018, 0.022, 0.044); iris.add(h1);
    const h2 = mesh(new THREE.SphereGeometry(0.007, 8, 6), C.hl, false); h2.position.set(-0.016, -0.018, 0.044); iris.add(h2);
    // upper lid line (lash)
    const lash = mesh(new THREE.TorusGeometry(0.066, 0.008, 6, 20, Math.PI * 0.9), C.hair, false); lash.position.set(0, 0.0, 0.018); lash.rotation.z = Math.PI * 0.05; lash.scale.set(0.95, 1.1, 1); eg.add(lash);
    const brow = mesh(new THREE.CapsuleGeometry(0.014, 0.065, 4, 8), C.hair, false); brow.rotation.z = Math.PI / 2; brow.position.set(0, 0.1, 0.03); eg.add(brow);
    const blush = new THREE.Mesh(new THREE.SphereGeometry(0.045, 16, 10), C.blush); blush.scale.set(1.2, 0.6, 0.3); blush.position.set(sx * 0.02, -0.095, 0.02); eg.add(blush);
    eyes.push({ g: eg, iris, brow, sx });
  }
  const nose = mesh(new THREE.SphereGeometry(0.036, 16, 12), C.skin); nose.scale.set(1.15, 0.85, 0.8); nose.position.set(0, -0.06, 0.29); face.add(nose);
  // mouth: smile arc + open mouth
  // face surface (analytic union of skull + chin ellipsoids) so the mouth sits ON the face
  const zAt = (x, y) => {
    const e1 = 1 - (x / 0.3) ** 2 - (y / 0.282) ** 2;
    const e2 = 1 - (x / 0.25) ** 2 - ((y + 0.06) / 0.2) ** 2;
    return Math.max(e1 > 0 ? 0.276 * Math.sqrt(e1) : 0, e2 > 0 ? 0.035 + 0.22 * Math.sqrt(e2) : 0);
  };
  const mouthG = new THREE.Group(); face.add(mouthG);
  const smilePts = [];
  for (let i = 0; i <= 16; i++) { const x = -0.058 + 0.116 * i / 16; const y = -0.14 - 0.03 * (1 - (x / 0.058) ** 2); smilePts.push(new THREE.Vector3(x, y, zAt(x, y) - 0.002)); }
  const smileM = new THREE.Group(); mouthG.add(smileM);
  smileM.add(mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(smilePts), 24, 0.0095, 8), C.mouth, false));
  for (const pt of [smilePts[0], smilePts[16]]) { const cap = mesh(new THREE.SphereGeometry(0.0095, 8, 6), C.mouth, false); cap.position.copy(pt); smileM.add(cap); }
  const open = new THREE.Group(); open.position.set(0, -0.158, zAt(0, -0.158) - 0.012); open.rotation.x = -0.4; mouthG.add(open);
  const cav = mesh(new THREE.SphereGeometry(0.06, 24, 16), C.mouth, false); cav.scale.set(1.1, 1, 0.3); open.add(cav);
  const tongue = mesh(new THREE.SphereGeometry(0.036, 16, 10), C.tongue, false); tongue.scale.set(1.25, 0.6, 0.3); tongue.position.set(0, -0.03, 0.006); open.add(tongue);
  const teeth = mesh(new THREE.SphereGeometry(0.05, 16, 8, 0, Math.PI * 2, 0, 0.5), C.teeth, false); teeth.scale.set(1.1, 0.5, 0.3); teeth.position.set(0, 0.035, 0.0); open.add(teeth);

  // ---------- arms
  const arms = {};
  for (const s of ['l', 'r']) {
    const sx = s === 'l' ? 1 : -1;
    const sh = new THREE.Group(); sh.position.set(sx * 0.215, 0.43, 0); sh.rotation.order = 'XZY'; torso.add(sh);
    const ball = mesh(new THREE.SphereGeometry(0.075, 20, 14), C.shirt); sh.add(ball);
    const sleeve = capsule(0.072, 0.06, C.shirt); sleeve.position.y = -0.06; sh.add(sleeve);
    const arm = capsule(0.058, 0.1, C.skin); arm.position.y = -0.13; sh.add(arm);
    const armhole = mesh(new THREE.TorusGeometry(0.078, 0.009, 8, 20), C.trim, false); armhole.rotation.y = Math.PI / 2; armhole.rotation.z = 0; armhole.position.set(-sx * 0.02, 0.0, 0); sh.add(armhole);
    const el = new THREE.Group(); el.position.y = -0.2; el.rotation.order = 'XYZ'; sh.add(el);
    const elb = mesh(new THREE.SphereGeometry(0.056, 16, 12), C.skin); el.add(elb);
    const fore = capsule(0.054, 0.1, C.skin); fore.position.y = -0.075; el.add(fore);
    const wrist = new THREE.Group(); wrist.position.y = -0.165; el.add(wrist);
    const palm = mesh(new THREE.SphereGeometry(0.062, 20, 14), C.skin); palm.scale.set(1.0, 1.15, 0.78); palm.position.y = -0.04; wrist.add(palm);
    const fingers = mesh(new THREE.CapsuleGeometry(0.03, 0.05, 6, 10), C.skin); fingers.rotation.z = Math.PI / 2; fingers.position.set(0, -0.085, 0.022); fingers.scale.set(1, 1.6, 0.9); wrist.add(fingers);
    const thumbG = new THREE.Group(); thumbG.position.set(sx * -0.045, -0.035, 0.03); wrist.add(thumbG);
    const thumb = capsule(0.022, 0.045, C.skin); thumb.position.y = -0.03; thumb.rotation.z = sx * 0.6; thumbG.add(thumb);
    arms[s] = { sh, el, wrist, thumbG, sx };
  }

  // ---------- microphone (left hand)
  const mic = new THREE.Group();
  const handle = mesh(new THREE.CylinderGeometry(0.022, 0.017, 0.2, 16), C.black); mic.add(handle);
  const grill = mesh(new THREE.SphereGeometry(0.048, 24, 16), C.metal); grill.position.y = 0.13; mic.add(grill);
  const ring = mesh(new THREE.CylinderGeometry(0.03, 0.024, 0.03, 16), C.metal); ring.position.y = 0.095; mic.add(ring);
  const flagTex = canvasTex(256, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#0e2a48'); gr.addColorStop(1, '#06121F');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = '#08E1FF'; g.fillRect(0, 0, w, 16); g.fillRect(0, h - 16, w, 16);
    g.textAlign = 'center'; g.textBaseline = 'middle';
    const fg = g.createLinearGradient(30, 0, 130, 0); fg.addColorStop(0, '#FDAE03'); fg.addColorStop(0.5, '#F6901C'); fg.addColorStop(1, '#EA4F3D');
    g.font = '86px UneLogo, sans-serif'; g.fillStyle = fg; g.fillText('PRO', w / 2, 100);
    g.fillStyle = '#ffffff'; g.font = '50px UneDisplay, sans-serif'; g.fillText('NEWS', w / 2, 178);
  });
  const flag = mesh(new RoundedBoxGeometry(0.085, 0.085, 0.085, 2, 0.008), new THREE.MeshPhysicalMaterial({ map: flagTex, roughness: 0.35, clearcoat: 0.6 }));
  flag.position.y = 0.04; mic.add(flag);
  mic.position.set(0.0, -0.075, 0.035); mic.rotation.set(0.25, 0, 0);
  arms.l.wrist.add(mic);

  // ---------- phone (right hand)
  const phone = new THREE.Group();
  const PW = 0.12, PH = 0.245;
  const pbody = mesh(new RoundedBoxGeometry(PW, PH, 0.016, 4, 0.012), new THREE.MeshPhysicalMaterial({ color: '#1a1f29', roughness: 0.25, metalness: 0.6, clearcoat: 1, envMapIntensity: 1 }));
  phone.add(pbody);
  const screenCanvas = document.createElement('canvas'); screenCanvas.width = 780; screenCanvas.height = 1688;
  const screenTex = new THREE.CanvasTexture(screenCanvas); screenTex.colorSpace = THREE.SRGBColorSpace; screenTex.anisotropy = 8;
  const screenMat = new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false });
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(PW * 0.92, PH * 0.94), screenMat); screen.position.z = 0.0085; phone.add(screen);
  const back2 = mesh(new RoundedBoxGeometry(0.035, 0.035, 0.006, 2, 0.006), C.black); back2.position.set(-0.03, 0.085, -0.009); phone.add(back2);
  // holder group lets the phone be placed in the palm
  const phoneHolder = new THREE.Group(); phoneHolder.add(phone);
  phoneHolder.position.set(0.0, -0.09, 0.045);
  arms.r.wrist.add(phoneHolder);

  // pointing index finger on the right hand
  const finger = capsule(0.019, 0.06, C.skin); finger.position.set(0, -0.115, 0.02); arms.r.wrist.add(finger);

  // ---------- laptop (held in front of the chest)
  const laptop = new THREE.Group();
  const lapMat = new THREE.MeshPhysicalMaterial({ color: '#c9d2de', roughness: 0.3, metalness: 0.75, clearcoat: 0.6, envMapIntensity: 1.1 });
  const LW = 0.46, LD = 0.3;
  const lbase = mesh(new RoundedBoxGeometry(LW, 0.022, LD, 3, 0.01), lapMat); laptop.add(lbase);
  const kb = mesh(new THREE.BoxGeometry(LW * 0.86, 0.004, LD * 0.5), C.black, false); kb.position.set(0, 0.012, -0.02); laptop.add(kb);
  const lidPivot = new THREE.Group(); lidPivot.position.set(0, 0.011, -LD / 2 + 0.005); laptop.add(lidPivot);
  const lid = mesh(new RoundedBoxGeometry(LW, 0.3, 0.014, 3, 0.007), lapMat); lid.position.set(0, 0.15, -0.007); lidPivot.add(lid);
  const bezel = mesh(new THREE.PlaneGeometry(LW * 0.97, 0.29), C.black, false); bezel.position.set(0, 0.15, 0.0005); lidPivot.add(bezel);
  const lapCanvas = document.createElement('canvas'); lapCanvas.width = 1280; lapCanvas.height = 800;
  const lapTex = new THREE.CanvasTexture(lapCanvas); lapTex.colorSpace = THREE.SRGBColorSpace; lapTex.anisotropy = 8;
  const lscreen = new THREE.Mesh(new THREE.PlaneGeometry(LW * 0.92, LW * 0.92 * 0.625), new THREE.MeshBasicMaterial({ map: lapTex, toneMapped: false }));
  lscreen.position.set(0, 0.152, 0.001); lidPivot.add(lscreen);
  lidPivot.rotation.x = -0.25;
  laptop.position.set(0, 0.27, 0.36); laptop.rotation.x = 0.0;
  torso.add(laptop); laptop.visible = false;

  const rig = { finger, laptop, lidPivot, lapCanvas, lapTex, root, hips, torso, headPivot, head, eyes, mouthG, smileM, open, legs, arms, mic, phone, phoneHolder, screen, screenCanvas, screenTex, C, body };
  rig.setPose = (p) => applyPose(rig, p);
  return rig;
}

export function applyPose(rig, P) {
  const p = { ...DEFAULT_POSE, ...P };
  rig.root.position.set(p.x, p.y, p.z);
  rig.root.rotation.y = p.rotY;
  rig.hips.position.y = 0.43 + p.bob;
  rig.torso.rotation.set(p.torsoX + p.lean, p.torsoY, p.torsoZ);
  rig.headPivot.rotation.set(p.headX, p.headY, p.headZ);
  // arms: fwd = flex (negative X rotation lifts arm forward), out = abduction
  for (const s of ['l', 'r']) {
    const a = rig.arms[s]; const sx = a.sx;
    a.sh.rotation.set(-p[s + 'Fwd'], sx * p[s + 'Twist'], sx * p[s + 'Out']);
    a.el.rotation.set(p[s + 'Elbow'], 0, 0);
    a.wrist.rotation.set(p[s + 'WristX'], sx * p[s + 'WristY'], sx * p[s + 'WristZ']);
  }
  rig.arms.r.thumbG.rotation.x = -p.thumb;
  for (const s of ['l', 'r']) {
    const L = rig.legs[s]; const sx = s === 'l' ? 1 : -1;
    L.hip.rotation.set(-p[s + 'Leg'], 0, sx * p.legSpread);
    L.knee.rotation.x = p[s + 'Knee'];
    L.foot.rotation.x = -p[s + 'Knee'] * 0.5 + p[s + 'Leg'] * 0.6;
    L.foot.rotation.z = -sx * p.legSpread;
  }
  // face
  const bl = Math.max(0, Math.min(1, p.blink));
  for (const e of rig.eyes) {
    e.g.scale.set(p.eyeScale, p.eyeScale * (1 - bl * 0.92), p.eyeScale);
    e.iris.position.set(p.eyeX * 0.02, p.eyeY * 0.02, 0);
    e.brow.position.y = 0.1 + p.brow * 0.03;
    e.brow.rotation.z = Math.PI / 2 + e.sx * p.browTilt * 0.3;
  }
  const o = Math.max(0, p.mouthOpen);
  rig.open.visible = o > 0.04;
  rig.smileM.visible = o < 0.35;
  rig.open.scale.set(0.75 + 0.3 * o, Math.max(0.05, o), 1);
  rig.mic.visible = p.mic > 0.5;
  rig.phoneHolder.visible = p.phone > 0.5;
  rig.phoneHolder.rotation.set(p.pRX, p.pRY, p.pRZ);
  rig.phoneHolder.scale.setScalar(p.phoneScale);
  if (p.aimW > 0) {
    // orient the phone in character space (screen normal = +Z rotated by yaw/pitch), independent of the arm
    rig.root.updateMatrixWorld(true);
    const parentQ = rig.phoneHolder.parent.getWorldQuaternion(new THREE.Quaternion());
    const rootQ = rig.root.getWorldQuaternion(new THREE.Quaternion());
    const want = rootQ.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(p.aimPitch, p.aimYaw, p.aimRoll, 'YXZ')));
    const local = parentQ.invert().multiply(want);
    rig.phoneHolder.quaternion.slerp(local, Math.min(1, p.aimW));
    // keep the hand BEHIND the phone: place phone center in front of the palm along the screen normal
    const wq = want.clone();
    const n = new THREE.Vector3(0, 0, 1).applyQuaternion(wq), up = new THREE.Vector3(0, 1, 0).applyQuaternion(wq);
    const palm = rig.arms.r.wrist.localToWorld(new THREE.Vector3(0, -0.06, 0.0));
    const target = palm.addScaledVector(n, 0.075 * p.aimW).addScaledVector(up, 0.06 * p.phoneScale * p.aimW);
    const base = rig.phoneHolder.parent.localToWorld(new THREE.Vector3(0.0, -0.09, 0.045));
    rig.phoneHolder.position.copy(rig.phoneHolder.parent.worldToLocal(base.lerp(target, Math.min(1, p.aimW))));
  } else rig.phoneHolder.position.set(0.0, -0.09, 0.045);
  rig.finger.visible = p.point > 0.5;
  rig.laptop.visible = p.laptop > 0.01;
  rig.laptop.scale.setScalar(Math.max(0.001, p.laptop));
}
