// Stylized street set: road receding along -Z, colonial-style buildings, lamps, fallen tree, cones and tape.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { rng } from './util.js';

const R = rng(20261027);

function canvasTex(w, h, draw, opts = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  if (opts.repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...opts.repeat); }
  return t;
}

function shade(hex, f) {
  const c = new THREE.Color(hex); c.multiplyScalar(f); return '#' + c.getHexString();
}

const SIGNS = ['PULPERÍA', 'FARMACIA', 'BARBERÍA', 'CAFÉ', 'FERRETERÍA', 'PANADERÍA', 'LIBRERÍA', 'TIENDA'];

function facadeTex(base, floors, cols, sign, seed) {
  const r = rng(seed);
  const W = 128 * cols, H = 150 * floors;
  return canvasTex(W, H, (g) => {
    g.fillStyle = base; g.fillRect(0, 0, W, H);
    // plaster noise
    for (let i = 0; i < 900; i++) {
      g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
      g.fillRect(r() * W, r() * H, 2 + r() * 6, 2 + r() * 6);
    }
    // bottom grime gradient
    const gr = g.createLinearGradient(0, H - 60, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.25)');
    g.fillStyle = gr; g.fillRect(0, H - 60, W, 60);
    // floor bands
    g.fillStyle = shade(base, 0.82);
    for (let f = 1; f < floors; f++) g.fillRect(0, H - f * 150 - 6, W, 10);
    g.fillRect(0, 0, W, 14);
    for (let f = 0; f < floors; f++) {
      for (let c = 0; c < cols; c++) {
        const x = c * 128 + 30, y = H - (f + 1) * 150 + 28;
        if (f === 0) {
          // ground floor: doors / shop
          if (sign && c === Math.floor(cols / 2)) {
            g.fillStyle = '#2a1d16'; g.fillRect(x - 6, y + 20, 80, 102);
            g.fillStyle = '#f4c46a'; g.fillRect(x, y + 26, 68, 96);
            g.fillStyle = 'rgba(80,40,10,0.35)'; g.fillRect(x + 32, y + 26, 4, 96);
          } else {
            g.fillStyle = '#5b3a24'; g.fillRect(x + 4, y + 22, 60, 100);
            g.fillStyle = '#714a2e'; g.fillRect(x + 10, y + 28, 22, 88); g.fillRect(x + 36, y + 28, 22, 88);
          }
          continue;
        }
        const lit = r() < 0.32;
        g.fillStyle = shade(base, 0.6); g.fillRect(x - 6, y - 6, 80, 104);
        if (lit) {
          const lg = g.createLinearGradient(0, y, 0, y + 92); lg.addColorStop(0, '#ffe7a8'); lg.addColorStop(1, '#f7b453');
          g.fillStyle = lg;
        } else {
          const lg = g.createLinearGradient(x, y, x + 68, y + 92); lg.addColorStop(0, '#9fc3e8'); lg.addColorStop(0.5, '#3d6491'); lg.addColorStop(1, '#22406a');
          g.fillStyle = lg;
        }
        g.fillRect(x, y, 68, 92);
        g.fillStyle = 'rgba(255,255,255,0.85)'; g.fillRect(x + 32, y, 4, 92); g.fillRect(x, y + 40, 68, 4);
        // sill
        g.fillStyle = shade(base, 1.15); g.fillRect(x - 10, y + 92, 88, 9);
        // balcony rail sometimes
        if (r() < 0.35) {
          g.fillStyle = '#1f2a33'; g.fillRect(x - 12, y + 62, 92, 4);
          for (let k = 0; k < 9; k++) g.fillRect(x - 10 + k * 11, y + 62, 3, 38);
        }
      }
    }
    if (sign) {
      const sy = H - 150 + 4;
      g.fillStyle = '#ffffff'; g.fillRect(14, sy, W - 28, 34);
      g.fillStyle = shade(base, 0.45); g.fillRect(18, sy + 4, W - 36, 26);
      g.fillStyle = '#ffffff'; g.font = 'bold 24px UneCond, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(sign, W / 2, sy + 18);
    }
  });
}

function stripesTex(text) {
  return canvasTex(1024, 96, (g, w, h) => {
    g.fillStyle = '#ffd400'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#111';
    for (let x = -64; x < w; x += 64) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 24, 0); g.lineTo(x + 24 + 30, h); g.lineTo(x + 30, h); g.fill(); }
    g.fillStyle = '#ffd400'; g.fillRect(150, 10, 724, h - 20);
    g.fillStyle = '#111'; g.font = '50px UneDisplay, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 6);
  });
}

export function glowTex(color = '255,214,140') {
  return canvasTex(128, 128, (g) => {
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, `rgba(${color},1)`); gr.addColorStop(0.25, `rgba(${color},0.45)`); gr.addColorStop(1, `rgba(${color},0)`);
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  });
}

export function buildStreet() {
  const root = new THREE.Group(); root.name = 'street';
  const std = (color, rough = 0.85, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: 0, envMapIntensity: 0.6, ...extra });

  // --- ground / road
  const asphaltTex = canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#323c4a'; g.fillRect(0, 0, w, h);
    const r = rng(7);
    for (let i = 0; i < 5000; i++) { const v = 40 + r() * 40; g.fillStyle = `rgba(${v},${v + 6},${v + 16},0.5)`; g.fillRect(r() * w, r() * h, 2, 2); }
  }, { repeat: [3, 18] });
  const road = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 90), std('#ffffff', 0.92, { map: asphaltTex }));
  road.rotation.x = -Math.PI / 2; road.position.set(0, 0, -30); road.receiveShadow = true; root.add(road);
  // lane dashes
  const dashMat = std('#f2c94c', 0.6);
  for (let z = 6; z > -70; z -= 2.2) {
    const d = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 1.1), dashMat);
    d.rotation.x = -Math.PI / 2; d.position.set(0, 0.005, z); d.receiveShadow = true; root.add(d);
  }
  // sidewalks + curbs
  const walkTex = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#b9b2a6'; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(70,60,50,0.35)'; g.lineWidth = 3;
    for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(0, i * 64); g.lineTo(w, i * 64); g.stroke(); g.beginPath(); g.moveTo(i * 64, 0); g.lineTo(i * 64, h); g.stroke(); }
    const r = rng(9); for (let i = 0; i < 1500; i++) { g.fillStyle = r() < .5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'; g.fillRect(r() * w, r() * h, 2, 2); }
  }, { repeat: [1, 40] });
  for (const s of [-1, 1]) {
    const walk = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.16, 90), std('#ffffff', 0.9, { map: walkTex }));
    walk.position.set(s * (2.3 + 0.95), 0.08, -30); walk.receiveShadow = true; walk.castShadow = true; root.add(walk);
    const curb = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 90), std('#d8d2c6', 0.8));
    curb.position.set(s * 2.33, 0.09, -30); curb.receiveShadow = true; root.add(curb);
  }

  // --- buildings
  const palette = ['#e9d6b0', '#c8694b', '#3f8f8c', '#dba545', '#d98c86', '#86acd6', '#efe6d2', '#9cc28f', '#b4583f', '#f0c987'];
  let signI = 0;
  for (const side of [-1, 1]) {
    let z = 7;
    let k = side < 0 ? 0 : 3;
    while (z > -60) {
      const depthZ = 3 + Math.floor(R() * 3) * 0.8;
      const floors = 2 + Math.floor(R() * 2.4);
      const cols = Math.max(2, Math.round(depthZ / 1.15));
      const h = floors * 1.35;
      const base = palette[(k++) % palette.length];
      const sign = R() < 0.55 ? SIGNS[(signI++) % SIGNS.length] : null;
      const fac = facadeTex(base, floors, cols, sign, 100 + k * 13 + (side > 0 ? 500 : 0));
      const plain = std(base, 0.9);
      const facMat = std('#ffffff', 0.88, { map: fac });
      const mats = side < 0 ? [facMat, plain, plain, plain, plain, plain] : [plain, facMat, plain, plain, plain, plain];
      const b = new THREE.Mesh(new THREE.BoxGeometry(2.4, h, depthZ - 0.05), mats);
      b.position.set(side * (4.15 + 1.2), h / 2, z - depthZ / 2);
      b.castShadow = true; b.receiveShadow = true; root.add(b);
      // cornice
      const cor = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.18, depthZ + 0.08), std(shade(base, 0.75), 0.85));
      cor.position.set(side * (4.15 + 1.2 - 0.1), h + 0.09, z - depthZ / 2); cor.castShadow = true; cor.receiveShadow = true; root.add(cor);
      // tile roof hint (terracotta strip) on some
      if (R() < 0.5) {
        const roof = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.12, depthZ + 0.1), std('#a8452c', 0.7));
        roof.position.set(side * (4.15 - 0.05), h - 0.25, z - depthZ / 2); roof.rotation.z = side * -0.5; roof.castShadow = true; root.add(roof);
      }
      // awning for shops
      if (sign) {
        const aw = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.05, Math.min(2.2, depthZ - 0.6)), std(['#e3173e', '#0b6fb8', '#2e9b5f', '#f6901c'][signI % 4], 0.6));
        aw.position.set(side * (4.15 - 0.35), 1.5, z - depthZ / 2); aw.rotation.z = side * 0.28; aw.castShadow = true; root.add(aw);
      }
      z -= depthZ;
    }
  }

  // --- distant hills (western Honduras)
  const hillMat = std('#2f5d7a', 1, { fog: true });
  for (let i = 0; i < 7; i++) {
    const hm = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hillMat);
    hm.scale.set(14 + R() * 10, 6 + R() * 6, 6);
    hm.position.set(-40 + i * 13 + R() * 4, -1, -85 - R() * 10); root.add(hm);
  }

  // --- street lamps
  const glow = glowTex();
  const poleMat = std('#1b2733', 0.5, { metalness: 0.4 });
  const bulbMat = new THREE.MeshStandardMaterial({ color: '#fff3d0', emissive: '#ffd890', emissiveIntensity: 2.2 });
  const lamps = [];
  for (const [x, z] of [[-3.75, 2.2], [3.75, -6.5], [-3.75, -14], [3.75, -22], [-3.75, -31], [3.75, -40]]) {
    const g = new THREE.Group(); g.position.set(x, 0.16, z);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.07, 3.3, 10), poleMat); pole.position.y = 1.65; pole.castShadow = true; g.add(pole);
    const baseM = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.25, 10), poleMat); baseM.position.y = 0.12; g.add(baseM);
    const arm = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.03, 6, 16, Math.PI / 2), poleMat);
    const dir = x < 0 ? 1 : -1;
    arm.position.set(dir * 0.35, 3.3, 0); arm.rotation.y = x < 0 ? 0 : Math.PI; g.add(arm);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.2, 0.16, 12), poleMat); head.position.set(dir * 0.7, 3.6, 0); head.castShadow = true; g.add(head);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 8), bulbMat); bulb.position.set(dir * 0.7, 3.5, 0); g.add(bulb);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.85 }));
    sp.scale.set(1.6, 1.6, 1); sp.position.copy(bulb.position); g.add(sp);
    root.add(g); lamps.push(g);
  }

  // --- the news event: fallen tree
  const tree = new THREE.Group(); tree.name = 'tree';
  const barkTex = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#6b4a32'; g.fillRect(0, 0, w, h);
    const r = rng(33);
    for (let i = 0; i < 70; i++) { g.strokeStyle = r() < .5 ? 'rgba(40,24,14,0.6)' : 'rgba(150,110,80,0.35)'; g.lineWidth = 2 + r() * 4; const x = r() * w; g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + r() * 20 - 10, h * .3, x + r() * 20 - 10, h * .7, x + r() * 10 - 5, h); g.stroke(); }
  }, { repeat: [3, 2] });
  const barkMat = std('#ffffff', 0.95, { map: barkTex });
  // trunk lying across road (along X), base on the left sidewalk, slightly raised
  const trunkLen = 6.2;
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.3, trunkLen, 16, 4), barkMat);
  trunk.rotation.z = Math.PI / 2 + 0.04; trunk.position.set(-0.35, 0.3, -1.6); trunk.rotation.y = 0.12;
  trunk.castShadow = true; trunk.receiveShadow = true; tree.add(trunk);
  // broken stump on the left sidewalk
  const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.38, 0.7, 14), barkMat);
  stump.position.set(-3.55, 0.5, -1.25); stump.castShadow = true; tree.add(stump);
  const splMat = std('#e8cfa0', 0.9);
  for (let i = 0; i < 6; i++) {
    const s = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.35 + R() * 0.2, 5), splMat);
    const a = i / 6 * Math.PI * 2; s.position.set(-3.55 + Math.cos(a) * 0.2, 0.95, -1.25 + Math.sin(a) * 0.2); s.rotation.set(R() * 0.5 - .25, 0, R() * 0.5 - .25); tree.add(s);
  }
  // branches
  const brMat = barkMat;
  const branches = [
    [1.2, 0.55, -1.75, 0.6, 0.0, 0.9, 1.3], [1.8, 0.5, -1.3, -0.5, 0.2, 1.1, 1.1], [2.3, 0.45, -1.95, 0.4, -0.3, 0.6, 0.9],
    [0.5, 0.5, -1.4, -0.9, 0.3, 0.8, 0.8], [2.6, 0.35, -1.5, 0.2, 0.6, 0.2, 0.9],
  ];
  for (const [x, y, z, rx, ry, rz, len] of branches) {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.1, len, 8), brMat);
    b.position.set(x, y + 0.2, z); b.rotation.set(rx, ry, rz); b.castShadow = true; tree.add(b);
  }
  // foliage clusters
  const leafCols = ['#3c8a3a', '#56a845', '#2a6e31', '#6dbb4e', '#2f7a3b'];
  const leafMats = leafCols.map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.75, envMapIntensity: 0.5 }));
  const leafGeo = new THREE.IcosahedronGeometry(1, 2);
  const lr = rng(77);
  for (let i = 0; i < 46; i++) {
    const m = new THREE.Mesh(leafGeo, leafMats[i % leafMats.length]);
    const u = lr();
    const s = 0.2 + lr() * 0.28 + u * 0.12;
    m.scale.set(s * 1.15, s * 0.8, s);
    m.position.set(0.6 + u * 2.9, 0.3 + lr() * (0.5 + u * 0.7), -1.7 + (lr() - 0.5) * (0.9 + u * 1.8));
    m.castShadow = true; m.receiveShadow = true; tree.add(m);
  }
  // scattered leaves on the asphalt
  const leafSmall = new THREE.CircleGeometry(0.06, 6);
  for (let i = 0; i < 60; i++) {
    const m = new THREE.Mesh(leafSmall, leafMats[i % 5]);
    m.rotation.x = -Math.PI / 2; m.rotation.z = lr() * 6;
    m.position.set(-2 + lr() * 5, 0.012, -0.6 + (lr() - 0.3) * 2.6); tree.add(m);
  }
  root.add(tree);

  // --- traffic cones + warning tape
  const coneMat = std('#ff6a13', 0.55, { envMapIntensity: 0.8 });
  const whiteMat = std('#f4f4f4', 0.4);
  const cones = [];
  const conePos = [[-1.85, 0.35], [-0.65, 0.55], [0.6, 0.5], [1.8, 0.3]];
  for (const [x, z] of conePos) {
    const c = new THREE.Group(); c.position.set(x, 0, z);
    const base = new THREE.Mesh(new RoundedBoxGeometry(0.42, 0.05, 0.42, 2, 0.02), coneMat); base.position.y = 0.025; base.castShadow = true; c.add(base);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.16, 0.6, 18), coneMat); body.position.y = 0.35; body.castShadow = true; c.add(body);
    for (const [y, r0, r1] of [[0.28, 0.122, 0.135], [0.46, 0.075, 0.088]]) {
      const band = new THREE.Mesh(new THREE.CylinderGeometry(r0 + 0.004, r1 + 0.004, 0.08, 18, 1, true), whiteMat); band.position.y = y; c.add(band);
    }
    root.add(c); cones.push(c);
  }
  const tapeTex = stripesTex('PRECAUCIÓN');
  tapeTex.wrapS = THREE.RepeatWrapping;
  const tapeMat = new THREE.MeshStandardMaterial({ map: tapeTex, side: THREE.DoubleSide, roughness: 0.5, envMapIntensity: 0.6 });
  function ribbon(pts, width, uvLen) {
    const curve = new THREE.CatmullRomCurve3(pts);
    const N = 40; const pos = [], uv = [], idx = [];
    const total = curve.getLength();
    for (let i = 0; i <= N; i++) {
      const p = curve.getPoint(i / N);
      const tw = Math.sin(i / N * Math.PI * 2) * 0.25;
      const up = new THREE.Vector3(0, Math.cos(tw), Math.sin(tw)).multiplyScalar(width / 2);
      pos.push(p.x + up.x, p.y + up.y, p.z + up.z, p.x - up.x, p.y - up.y, p.z - up.z);
      const u = (i / N) * total / uvLen; uv.push(u, 1, u, 0);
      if (i < N) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx); geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, tapeMat); m.castShadow = true; return m;
  }
  const tops = conePos.map(([x, z]) => new THREE.Vector3(x, 0.6, z));
  // tape from the lamp pole on the left, across cones, to a building pipe on the right
  const tapePts = [new THREE.Vector3(-3.7, 0.95, 0.9), tops[0]];
  for (let i = 0; i < tops.length - 1; i++) {
    const a = tops[i], b = tops[i + 1];
    tapePts.push(new THREE.Vector3((a.x + b.x) / 2, 0.47, (a.z + b.z) / 2 + 0.02), b);
  }
  tapePts.push(new THREE.Vector3(2.9, 0.62, 0.55), new THREE.Vector3(3.9, 0.95, 0.8));
  root.add(ribbon(tapePts, 0.085, 1.4));
  // little post on the right sidewalk to hold the tape
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.0, 8), poleMat); post.position.set(3.9, 0.6, 0.8); post.castShadow = true; root.add(post);
  const post2 = post.clone(); post2.position.set(-3.7, 0.6, 0.9); root.add(post2);

  // sidewalk props: trash can and planters
  const canMat = std('#1f6f5a', 0.5);
  const tc = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.18, 0.55, 14), canMat); tc.position.set(3.65, 0.44, 3.5); tc.castShadow = true; root.add(tc);
  for (const [x, z] of [[-3.7, 4.6], [3.7, -3.6], [-3.7, -8.5]]) {
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.2, 0.35, 14), std('#b4583f', 0.8)); pot.position.set(x, 0.33, z); pot.castShadow = true; root.add(pot);
    const bush = new THREE.Mesh(leafGeo, leafMats[1]); bush.scale.set(0.38, 0.34, 0.38); bush.position.set(x, 0.72, z); bush.castShadow = true; root.add(bush);
  }
  return { root, tree, cones, lamps };
}

export function buildLights(scene) {
  const hemi = new THREE.HemisphereLight('#b9d8ff', '#5a4a3e', 1.0); scene.add(hemi);
  const key = new THREE.DirectionalLight('#ffe2b8', 3.8);
  key.position.set(-7, 8, 2.5); key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  const sc = key.shadow.camera; sc.left = -7; sc.right = 7; sc.top = 7; sc.bottom = -7; sc.near = 1; sc.far = 30;
  key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02; key.shadow.radius = 4;
  scene.add(key); scene.add(key.target);
  const rim = new THREE.DirectionalLight('#7fe9ff', 2.2); rim.position.set(5, 4, -8); scene.add(rim);
  const fill = new THREE.DirectionalLight('#ffe9dc', 1.3); fill.position.set(4, 3, 9); scene.add(fill);
  return { hemi, key, rim, fill };
}
