// Procedural street reporter v2 — sculpted head, lidded eyes, lips, clumped hair, tailored clothes,
// articulated hands (4 fingers x 3 segments + opposable thumb) and analytic 2-bone arm IK for real grips.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { rng } from './util.js';

// ------------------------------------------------------------------ helpers
function canvasTex(w, h, draw, repeat) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
}
function dataTex(w, h, draw, repeat) { const t = canvasTex(w, h, draw, repeat); t.colorSpace = THREE.NoColorSpace; return t; }
function mesh(geo, mat, cast = true) { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; return m; }
function capsule(r, len, mat, seg = 16) { return mesh(new THREE.CapsuleGeometry(r, len, 8, seg), mat); }
const G = (v, c, s) => Math.exp(-((v.x - c[0]) ** 2 + (v.y - c[1]) ** 2 + (v.z - c[2]) ** 2) / (2 * s * s));

// tapered tube along points; cross-section ellipse oriented by `upFn` (returns a reference normal)
function taperTube(pts, r0, r1, { seg = 20, rad = 8, flat = 1, upFn = null, colorFn = null, power = 1.2 } = {}) {
  const curve = new THREE.CatmullRomCurve3(pts);
  const pos = [], nor = [], col = [], idx = [];
  const T = new THREE.Vector3(), N = new THREE.Vector3(), B = new THREE.Vector3(), P = new THREE.Vector3();
  for (let i = 0; i <= seg; i++) {
    const u = i / seg;
    curve.getPointAt(u, P); curve.getTangentAt(u, T);
    const ref = upFn ? upFn(P) : new THREE.Vector3(0, 1, 0);
    B.crossVectors(T, ref).normalize(); if (B.lengthSq() < 1e-6) B.set(1, 0, 0);
    N.crossVectors(B, T).normalize();
    const r = r0 + (r1 - r0) * Math.pow(u, power);
    const c = colorFn ? colorFn(u) : null;
    for (let j = 0; j <= rad; j++) {
      const a = j / rad * Math.PI * 2;
      const cx = Math.cos(a), cy = Math.sin(a);
      const nx = B.x * cx + N.x * cy * flat, ny = B.y * cx + N.y * cy * flat, nz = B.z * cx + N.z * cy * flat;
      pos.push(P.x + (B.x * cx * r) + N.x * cy * r * flat, P.y + (B.y * cx * r) + N.y * cy * r * flat, P.z + (B.z * cx * r) + N.z * cy * r * flat);
      const l = Math.hypot(nx, ny, nz) || 1; nor.push(nx / l, ny / l, nz / l);
      if (c) col.push(c.r, c.g, c.b);
    }
  }
  for (let i = 0; i < seg; i++) for (let j = 0; j < rad; j++) {
    const a = i * (rad + 1) + j, b = a + rad + 1;
    idx.push(a, b, a + 1, b, b + 1, a + 1);
  }
  // end caps (simple fans)
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  if (col.length) g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  return g;
}

// ------------------------------------------------------------------ materials
function makeMaterials() {
  const skinParams = { roughness: 0.58, metalness: 0, sheen: 0.7, sheenRoughness: 0.45, sheenColor: new THREE.Color('#ff9c7a'), clearcoat: 0.0, emissive: new THREE.Color('#5a2410'), emissiveIntensity: 0.16, envMapIntensity: 0.4 };
  const fabricNoise = dataTex(256, 256, (g, w, h) => {
    g.fillStyle = '#808080'; g.fillRect(0, 0, w, h);
    const r = rng(3);
    for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) { const v = 110 + ((x + y) % 4 === 0 ? 40 : 0) + r() * 40; g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(x, y, 2, 2); }
  }, [6, 6]);
  // vest: navy canvas with seams and stitches (UV of a capsule: u around, v along height)
  const vestMap = canvasTex(1024, 512, (g, w, h) => {
    g.fillStyle = '#0f2b4a'; g.fillRect(0, 0, w, h);
    const r = rng(5); for (let i = 0; i < 9000; i++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)'; g.fillRect(r() * w, r() * h, 2, 2); }
    // side panels slightly darker
    g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(w * 0.18, 0, w * 0.14, h); g.fillRect(w * 0.68, 0, w * 0.14, h);
    // seams (dashed stitch lines)
    g.strokeStyle = 'rgba(160,200,235,0.55)'; g.lineWidth = 2; g.setLineDash([7, 6]);
    for (const x of [0.18, 0.32, 0.68, 0.82]) { g.beginPath(); g.moveTo(w * x, h * 0.12); g.lineTo(w * x, h * 0.9); g.stroke(); }
    for (const y of [0.3, 0.72]) { g.beginPath(); g.moveTo(0, h * y); g.lineTo(w, h * y); g.stroke(); }
    g.setLineDash([]);
  });
  const jeansMap = canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#34507a'; g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 3) { g.fillStyle = y % 6 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.08)'; g.fillRect(0, y, w, 1); }
    const r = rng(8); for (let i = 0; i < 6000; i++) { g.fillStyle = r() < .5 ? 'rgba(200,220,255,0.06)' : 'rgba(0,0,20,0.08)'; g.fillRect(r() * w, r() * h, 3, 1); }
    // side seams with orange stitching
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(w * 0.245, 0, 6, h); g.fillRect(w * 0.745, 0, 6, h);
    g.strokeStyle = '#d98a3a'; g.lineWidth = 2; g.setLineDash([6, 5]);
    for (const x of [0.235, 0.265, 0.735, 0.765]) { g.beginPath(); g.moveTo(w * x, 0); g.lineTo(w * x, h); g.stroke(); }
  });
  const C = {
    skin: new THREE.MeshPhysicalMaterial({ color: '#a8673e', ...skinParams }),
    head: new THREE.MeshPhysicalMaterial({ color: '#ffffff', vertexColors: true, ...skinParams }),
    skinDark: new THREE.MeshPhysicalMaterial({ color: '#7c4426', ...skinParams }),
    mouthLine: new THREE.MeshPhysicalMaterial({ color: '#4a1a12', roughness: 0.6 }),
    lips: new THREE.MeshPhysicalMaterial({ color: '#9a5340', roughness: 0.45, sheen: 0.6, sheenColor: new THREE.Color('#ff9a8a'), emissive: new THREE.Color('#3a1008'), emissiveIntensity: 0.12 }),
    nail: new THREE.MeshPhysicalMaterial({ color: '#c99a80', roughness: 0.3, clearcoat: 0.6, clearcoatRoughness: 0.3 }),
    hair: new THREE.MeshPhysicalMaterial({ color: '#ffffff', vertexColors: true, roughness: 0.62, sheen: 0.6, sheenRoughness: 0.5, sheenColor: new THREE.Color('#7a5236'), clearcoat: 0.0 }),
    hairBase: new THREE.MeshPhysicalMaterial({ color: '#2e1d12', roughness: 0.7, sheen: 0.4, sheenColor: new THREE.Color('#5a3d29') }),
    shirt: new THREE.MeshPhysicalMaterial({ color: '#f2f5fa', roughness: 0.8, sheen: 0.8, sheenRoughness: 0.6, sheenColor: new THREE.Color('#ffffff'), bumpMap: fabricNoise, bumpScale: 0.6 }),
    vest: new THREE.MeshPhysicalMaterial({ color: '#ffffff', map: vestMap, roughness: 0.78, sheen: 0.6, sheenRoughness: 0.5, sheenColor: new THREE.Color('#4c8fe2'), bumpMap: fabricNoise, bumpScale: 0.8 }),
    vestPlain: new THREE.MeshPhysicalMaterial({ color: '#0f2b4a', roughness: 0.78, sheen: 0.6, sheenColor: new THREE.Color('#4c8fe2'), bumpMap: fabricNoise, bumpScale: 0.8 }),
    trim: new THREE.MeshPhysicalMaterial({ color: '#08E1FF', roughness: 0.35, emissive: '#0aa6c0', emissiveIntensity: 0.3 }),
    jeans: new THREE.MeshPhysicalMaterial({ color: '#ffffff', map: jeansMap, roughness: 0.85, sheen: 0.5, sheenColor: new THREE.Color('#9db8e8'), bumpMap: fabricNoise, bumpScale: 1.0 }),
    belt: new THREE.MeshPhysicalMaterial({ color: '#3a2416', roughness: 0.45, clearcoat: 0.3 }),
    shoe: new THREE.MeshPhysicalMaterial({ color: '#f7f8fb', roughness: 0.5, sheen: 0.4, bumpMap: fabricNoise, bumpScale: 0.4 }),
    sole: new THREE.MeshPhysicalMaterial({ color: '#F6901C', roughness: 0.6 }),
    midsole: new THREE.MeshPhysicalMaterial({ color: '#ffffff', roughness: 0.4 }),
    lace: new THREE.MeshPhysicalMaterial({ color: '#0B2238', roughness: 0.6 }),
    eyeW: new THREE.MeshPhysicalMaterial({ color: '#fbf8f4', roughness: 0.2, clearcoat: 1, clearcoatRoughness: 0.05 }),
    hl: new THREE.MeshBasicMaterial({ color: '#ffffff' }),
    mouth: new THREE.MeshBasicMaterial({ color: '#2a0a0a' }),
    tongue: new THREE.MeshPhysicalMaterial({ color: '#d4626a', roughness: 0.5 }),
    teeth: new THREE.MeshPhysicalMaterial({ color: '#fbfbf6', roughness: 0.3 }),
    lash: new THREE.MeshPhysicalMaterial({ color: '#140c08', roughness: 0.6 }),
    black: new THREE.MeshPhysicalMaterial({ color: '#16181c', roughness: 0.35, clearcoat: 0.6 }),
    metal: new THREE.MeshPhysicalMaterial({ color: '#5a6270', roughness: 0.35, metalness: 0.8 }),
    chrome: new THREE.MeshPhysicalMaterial({ color: '#d8dde5', roughness: 0.2, metalness: 0.9 }),
  };
  return C;
}

// iris texture in polar layout (u = angle, v = radius from pupil centre)
function irisTex() {
  return canvasTex(256, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#050302'); gr.addColorStop(0.36, '#050302'); gr.addColorStop(0.4, '#6b3a17');
    gr.addColorStop(0.7, '#9a5a24'); gr.addColorStop(0.86, '#4a2810'); gr.addColorStop(0.93, '#1a0d05'); gr.addColorStop(1, '#f5f1ea');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const r = rng(12);
    for (let i = 0; i < 140; i++) { const x = r() * w; g.strokeStyle = r() < 0.5 ? 'rgba(255,200,120,0.28)' : 'rgba(30,12,4,0.35)'; g.lineWidth = 1 + r() * 2; g.beginPath(); g.moveTo(x, h * 0.4); g.lineTo(x + (r() - 0.5) * 6, h * (0.75 + r() * 0.12)); g.stroke(); }
  });
}

// ------------------------------------------------------------------ hand
// Hand frame: wrist at origin, fingers along -Y, palm normal +Z, thumb on the lateral side (x = sx * ...)
const FINGER = { i: [0.031, 0.023, 0.019], m: [0.034, 0.025, 0.02], r: [0.031, 0.023, 0.019], k: [0.025, 0.019, 0.016] };
const FX = { i: 0.031, m: 0.0105, r: -0.0105, k: -0.03 };
function buildHand(sx, C) {
  const hand = new THREE.Group();
  // palm: rounded, slightly cupped
  const palmGeo = new RoundedBoxGeometry(0.084, 0.07, 0.036, 4, 0.016);
  const palm = mesh(palmGeo, C.skin); palm.position.set(0, -0.05, 0.004); hand.add(palm);
  const heel = mesh(new THREE.SphereGeometry(0.03, 16, 12), C.skin); heel.scale.set(1.3, 0.9, 0.55); heel.position.set(sx * 0.016, -0.03, 0.006); hand.add(heel);
  const fingers = {};
  for (const k of ['i', 'm', 'r', 'k']) {
    const L = FINGER[k]; const R0 = k === 'k' ? 0.0115 : 0.0132;
    const base = new THREE.Group(); base.position.set(sx * FX[k], -0.083, 0.004); hand.add(base);
    const knuckle = mesh(new THREE.SphereGeometry(R0 * 1.05, 12, 10), C.skin); base.add(knuckle);
    const segs = []; let parent = base;
    for (let s = 0; s < 3; s++) {
      const j = new THREE.Group(); if (s > 0) j.position.y = -L[s - 1]; parent.add(j);
      const r = R0 * (1 - s * 0.09);
      const cap = mesh(new THREE.CapsuleGeometry(r, Math.max(0.001, L[s] - r * 0.6), 6, 10), C.skin, s < 2);
      cap.position.y = -L[s] / 2; j.add(cap);
      if (s === 2) { const nail = mesh(new THREE.SphereGeometry(r * 0.75, 10, 8), C.nail, false); nail.scale.set(1, 1.2, 0.35); nail.position.set(0, -L[s] * 0.62, -r * 0.72); j.add(nail); }
      segs.push(j); parent = j;
    }
    const tip = new THREE.Object3D(); tip.position.y = -L[2] - R0 * 0.5; segs[2].add(tip);
    fingers[k] = { base, segs, tip };
  }
  // thumb: CMC base on the lateral heel, two segments + tip
  const tBase = new THREE.Group(); tBase.position.set(sx * 0.04, -0.028, 0.012); hand.add(tBase);
  const tMeta = mesh(new THREE.CapsuleGeometry(0.017, 0.022, 6, 10), C.skin); tMeta.position.y = -0.018; tBase.add(tMeta);
  const t1 = new THREE.Group(); t1.position.y = -0.036; tBase.add(t1);
  const t1m = mesh(new THREE.CapsuleGeometry(0.0145, 0.014, 6, 10), C.skin); t1m.position.y = -0.013; t1.add(t1m);
  const t2 = new THREE.Group(); t2.position.y = -0.026; t1.add(t2);
  const t2m = mesh(new THREE.CapsuleGeometry(0.0135, 0.01, 6, 10), C.skin); t2m.position.y = -0.011; t2.add(t2m);
  const tn = mesh(new THREE.SphereGeometry(0.01, 10, 8), C.nail, false); tn.scale.set(1, 1.2, 0.35); tn.position.set(0, -0.014, -0.0095); t2.add(tn);
  const tTip = new THREE.Object3D(); tTip.position.y = -0.026; t2.add(tTip);
  return { hand, fingers, thumb: { base: tBase, t1, t2, tip: tTip }, sx };
}
// hand pose: {i,m,r,k:[c1,c2,c3] curls (rad, + = toward palm), sp: spread, t:[yaw, pitch, b1, b2]}
export const HANDS = {
  relax: { i: [0.35, 0.4, 0.3], m: [0.42, 0.45, 0.3], r: [0.5, 0.5, 0.35], k: [0.6, 0.55, 0.4], sp: 0.06, t: [0.2, 0.35, 0.25, 0.2] },
  open: { i: [0.05, 0.06, 0.04], m: [0.04, 0.05, 0.04], r: [0.06, 0.06, 0.05], k: [0.1, 0.08, 0.05], sp: 0.2, t: [0.4, 0.25, 0.15, 0.1] },
  fist: { i: [1.45, 1.6, 1.1], m: [1.5, 1.6, 1.1], r: [1.55, 1.6, 1.1], k: [1.6, 1.6, 1.1], sp: 0.0, t: [-0.15, 0.95, 0.6, 0.5] },
  point: { i: [0.0, 0.02, 0.02], m: [1.5, 1.6, 1.1], r: [1.55, 1.6, 1.1], k: [1.6, 1.6, 1.1], sp: 0.0, t: [-0.35, 1.1, 0.6, 0.5] },
  thumbsUp: { i: [1.5, 1.6, 1.1], m: [1.55, 1.6, 1.1], r: [1.6, 1.6, 1.1], k: [1.6, 1.6, 1.1], sp: 0.0, t: [-0.8, -0.4, -0.05, -0.05] },
  mic: { i: [1.25, 1.35, 0.95], m: [1.3, 1.35, 0.95], r: [1.35, 1.35, 0.95], k: [1.4, 1.35, 0.95], sp: 0.0, t: [0.05, 0.9, 0.35, 0.3] },
  grip: { i: [0.05, 0.3, 1.45], m: [0.05, 0.3, 1.45], r: [0.08, 0.35, 1.45], k: [0.12, 0.45, 1.4], sp: 0.02, t: [0.35, 0.95, 0.1, 0.15] },
  tap: { i: [0.05, 0.12, 0.1], m: [1.2, 1.4, 1.0], r: [1.35, 1.45, 1.0], k: [1.45, 1.45, 1.0], sp: 0.0, t: [-0.05, 0.85, 0.5, 0.35] },
  support: { i: [0.25, 1.2, 1.0], m: [0.3, 1.25, 1.0], r: [0.35, 1.3, 1.0], k: [0.4, 1.3, 1.0], sp: 0.05, t: [0.45, 0.85, 0.15, 0.1] },
  side: { i: [0.4, 1.0, 0.4], m: [0.4, 1.05, 0.4], r: [0.45, 1.05, 0.4], k: [0.5, 1.05, 0.4], sp: 0.04, t: [0.2, 0.2, 0.0, 0.0] },
  tray: { i: [0.15, 0.25, 0.15], m: [0.15, 0.25, 0.15], r: [0.18, 0.28, 0.15], k: [0.22, 0.3, 0.15], sp: 0.08, t: [0.55, -0.35, 0.1, 0.1] },
};
function applyHand(H, hp) {
  const sx = H.sx;
  for (const k of ['i', 'm', 'r', 'k']) {
    const f = H.fingers[k]; const c = hp[k];
    const spr = { i: 1, m: 0.3, r: -0.4, k: -1 }[k] * (hp.sp || 0);
    f.base.rotation.set(-c[0], 0, sx * spr);
    f.segs[1].rotation.x = -c[1]; f.segs[2].rotation.x = -c[2];
  }
  const [yaw, pitch, b1, b2] = hp.t;
  // thumb: default points down & lateral; yaw swings it out (abduction), pitch brings it across the palm (opposition)
  H.thumb.base.rotation.set(-pitch * 0.9, sx * pitch * 0.4, sx * (0.55 + yaw), 'XYZ');
  H.thumb.t1.rotation.x = -b1; H.thumb.t2.rotation.x = -b2;
}

// ------------------------------------------------------------------ pose defaults
export const DEFAULT_POSE = {
  x: 0, y: 0, z: 0, rotY: 0, lean: 0, bob: 0, sway: 0,
  torsoX: 0, torsoY: 0, torsoZ: 0,
  headX: 0, headY: 0, headZ: 0,
  rFwd: 0.05, rOut: 0.18, rTwist: 0, rElbow: -0.15, rWristX: 0, rWristY: 0, rWristZ: 0,
  lFwd: 0.05, lOut: 0.18, lTwist: 0, lElbow: -0.15, lWristX: 0, lWristY: 0, lWristZ: 0,
  rLeg: 0, lLeg: 0, rKnee: 0, lKnee: 0, legSpread: 0.04,
  brow: 0, browTilt: 0, mouthOpen: 0, smile: 1, round: 0, eyeX: 0, eyeY: 0, blink: 0, eyeScale: 1, lidUp: 0, squint: 0,
  mic: 1, phone: 1, point: 0, laptop: 0,
  // phone placement (root space) used when aimW>0
  aimW: 0, aimYaw: 0, aimPitch: 0, aimRoll: 0, phX: -0.1, phY: 0.95, phZ: 0.25,
  // left hand IK helpers
  lTapW: 0, lTapX: 0.5, lTapY: 0.5, lLift: 0.03, lGripW: 0, rTapLift: 0,
  rGripDY: 0, rThumbW: 0, rThumbX: 0.8, rThumbY: 0.55, rThumbLift: 0, lThumbW: 0, lThumbX: 0.5, lThumbY: 0.9, lThumbLift: 0,
  handR: HANDS.relax, handL: HANDS.relax,
  hairLagX: 0, hairLagZ: 0, vestLag: 0,
};

const PW = 0.078, PH = 0.1605, PT = 0.011;
export const PHONE = { W: PW, H: PH, T: PT, SW: PW * 0.92, SH: PH * 0.94 };

// ------------------------------------------------------------------ build
export function buildReporter() {
  const C = makeMaterials();
  const root = new THREE.Group(); root.name = 'reporter';
  const hips = new THREE.Group(); hips.position.y = 0.43; root.add(hips);

  // ---------- legs + sneakers
  const legs = {};
  for (const s of ['l', 'r']) {
    const sx = s === 'l' ? 1 : -1;
    const hip = new THREE.Group(); hip.position.set(sx * 0.095, 0.02, 0); hips.add(hip);
    const thigh = mesh(new THREE.CapsuleGeometry(0.08, 0.14, 8, 18), C.jeans); thigh.position.y = -0.1; hip.add(thigh);
    const knee = new THREE.Group(); knee.position.y = -0.2; hip.add(knee);
    const shin = mesh(new THREE.CylinderGeometry(0.074, 0.08, 0.17, 18, 1), C.jeans); shin.position.y = -0.09; knee.add(shin);
    const kneeB = mesh(new THREE.SphereGeometry(0.076, 16, 12), C.jeans); knee.add(kneeB);
    const cuff = mesh(new THREE.TorusGeometry(0.078, 0.016, 8, 24), C.jeans); cuff.rotation.x = Math.PI / 2; cuff.position.y = -0.165; knee.add(cuff);
    const foot = new THREE.Group(); foot.position.y = -0.2; knee.add(foot);
    // sneaker
    const upper = mesh(new RoundedBoxGeometry(0.12, 0.075, 0.17, 4, 0.035), C.shoe); upper.position.set(0, -0.012, 0.02); foot.add(upper);
    const toe = mesh(new THREE.SphereGeometry(0.062, 20, 14), C.shoe); toe.scale.set(0.98, 0.62, 1.0); toe.position.set(0, -0.026, 0.1); foot.add(toe);
    const mid = mesh(new RoundedBoxGeometry(0.135, 0.028, 0.255, 3, 0.012), C.midsole); mid.position.set(0, -0.052, 0.045); foot.add(mid);
    const out = mesh(new RoundedBoxGeometry(0.138, 0.014, 0.258, 3, 0.006), C.sole); out.position.set(0, -0.068, 0.045); foot.add(out);
    const tongue = mesh(new RoundedBoxGeometry(0.06, 0.05, 0.06, 2, 0.015), C.shoe); tongue.position.set(0, 0.02, 0.02); tongue.rotation.x = -0.4; foot.add(tongue);
    for (let i = 0; i < 4; i++) { const l = mesh(new THREE.CapsuleGeometry(0.0055, 0.05, 4, 6), C.lace, false); l.rotation.z = Math.PI / 2; l.position.set(0, 0.018 - i * 0.009, 0.045 + i * 0.017); l.rotation.y = (i % 2 ? 0.25 : -0.25); foot.add(l); }
    const stripe = mesh(new THREE.BoxGeometry(0.004, 0.022, 0.1), C.trim, false); stripe.position.set(sx * 0.061, -0.015, 0.03); stripe.rotation.x = -0.45; foot.add(stripe);
    const heelTab = mesh(new RoundedBoxGeometry(0.05, 0.04, 0.02, 2, 0.008), C.sole); heelTab.position.set(0, 0.0, -0.066); foot.add(heelTab);
    legs[s] = { hip, knee, foot };
  }

  // ---------- torso: jeans + belt + shirt + vest
  const torso = new THREE.Group(); hips.add(torso);
  const pants = mesh(new THREE.CapsuleGeometry(0.158, 0.05, 8, 28), C.jeans); pants.scale.set(1, 0.85, 0.85); pants.position.y = 0.085; torso.add(pants);
  const belt = mesh(new THREE.TorusGeometry(0.163, 0.016, 8, 40), C.belt); belt.rotation.x = Math.PI / 2; belt.scale.set(1, 0.83, 1.25); belt.position.y = 0.12; torso.add(belt);
  const buckle = mesh(new RoundedBoxGeometry(0.05, 0.034, 0.012, 2, 0.004), C.chrome); buckle.position.set(0, 0.12, 0.142); torso.add(buckle);
  const loopM = new THREE.BoxGeometry(0.01, 0.04, 0.008);
  for (const a of [-0.9, 0.9, -2.0, 2.0]) { const lp = mesh(loopM, C.jeans, false); lp.position.set(Math.sin(a) * 0.175, 0.12, Math.cos(a) * 0.145); lp.rotation.y = a; torso.add(lp); }
  // shirt core (visible at neck/arms)
  const shirtCore = mesh(new THREE.CapsuleGeometry(0.19, 0.16, 8, 24), C.shirt); shirtCore.scale.set(1, 1, 0.78); shirtCore.position.y = 0.33; torso.add(shirtCore);
  // vest
  const body = mesh(new THREE.CapsuleGeometry(0.2, 0.13, 12, 32), C.vest); body.scale.set(1, 1, 0.8); body.position.y = 0.34; torso.add(body);
  const vestLag = new THREE.Group(); vestLag.position.y = 0.17; torso.add(vestLag);
  const hem = mesh(new THREE.TorusGeometry(0.168, 0.013, 8, 40), C.trim, false); hem.rotation.x = Math.PI / 2; hem.scale.set(1.03, 0.82, 1); vestLag.add(hem);
  // neckline trim + shirt collar
  const neckTrim = mesh(new THREE.TorusGeometry(0.11, 0.013, 8, 32), C.trim, false); neckTrim.rotation.x = Math.PI / 2 - 0.2; neckTrim.scale.set(1, 0.85, 1); neckTrim.position.set(0, 0.535, 0.01); torso.add(neckTrim);
  const collarBand = mesh(new THREE.TorusGeometry(0.075, 0.022, 10, 28), C.shirt); collarBand.rotation.x = Math.PI / 2 - 0.25; collarBand.position.set(0, 0.565, 0.0); torso.add(collarBand);
  const flapShape = new THREE.Shape(); flapShape.moveTo(0, 0); flapShape.lineTo(0.055, -0.01); flapShape.lineTo(0.012, -0.062); flapShape.lineTo(0, -0.03); flapShape.closePath();
  for (const sx of [1, -1]) {
    const fg = new THREE.ExtrudeGeometry(flapShape, { depth: 0.006, bevelEnabled: true, bevelSize: 0.003, bevelThickness: 0.003, bevelSegments: 2 });
    const flap = mesh(fg, C.shirt); flap.scale.set(sx, 1, 1); flap.position.set(sx * 0.008, 0.585, 0.075); flap.rotation.set(-0.55, sx * -0.35, 0); torso.add(flap);
  }
  // zipper: tape + teeth + pull
  const zipTex = canvasTex(32, 512, (g, w, h) => { g.fillStyle = '#0a1e33'; g.fillRect(0, 0, w, h); g.fillStyle = '#c9d4e2'; for (let y = 0; y < h; y += 8) { g.fillRect(y % 16 ? 8 : 14, y, 10, 5); } });
  const zip = mesh(new THREE.BoxGeometry(0.016, 0.36, 0.006), new THREE.MeshPhysicalMaterial({ map: zipTex, roughness: 0.4, metalness: 0.4 }), false); zip.position.set(0, 0.33, 0.161); zip.rotation.x = -0.02; torso.add(zip);
  const pull = mesh(new RoundedBoxGeometry(0.014, 0.03, 0.006, 2, 0.003), C.chrome, false); pull.position.set(0.004, 0.49, 0.17); pull.rotation.z = 0.15; torso.add(pull);
  // trims down the front opening
  for (const sx of [1, -1]) { const tr = mesh(new THREE.BoxGeometry(0.008, 0.36, 0.006), C.trim, false); tr.position.set(sx * 0.016, 0.33, 0.16); torso.add(tr); }
  // PRENSA patches
  const prensaTex = (big) => canvasTex(512, big ? 160 : 128, (g, w, h) => {
    g.fillStyle = '#08E1FF'; g.beginPath(); g.roundRect(6, 6, w - 12, h - 12, 22); g.fill();
    g.fillStyle = '#0B2238'; g.beginPath(); g.roundRect(14, 14, w - 28, h - 28, 16); g.fill();
    g.strokeStyle = 'rgba(8,225,255,0.6)'; g.setLineDash([8, 6]); g.lineWidth = 3; g.beginPath(); g.roundRect(22, 22, w - 44, h - 44, 12); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#ffffff'; g.font = `${big ? 90 : 76}px UneDisplay, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('PRENSA', w / 2, h / 2 + 6);
  });
  const backPatch = new THREE.Mesh(new THREE.CylinderGeometry(0.206, 0.206, 0.11, 32, 1, true, Math.PI - 0.72, 1.44), new THREE.MeshPhysicalMaterial({ map: prensaTex(true), roughness: 0.5, transparent: true }));
  backPatch.scale.set(1, 1, 0.8); backPatch.position.y = 0.38; torso.add(backPatch);
  const chestPatch = new THREE.Mesh(new THREE.CylinderGeometry(0.205, 0.205, 0.045, 24, 1, true, 0.28, 0.6), new THREE.MeshPhysicalMaterial({ map: prensaTex(false), roughness: 0.5, transparent: true }));
  chestPatch.scale.set(1, 1, 0.8); chestPatch.position.y = 0.43; torso.add(chestPatch);
  // pockets (chest right + two lower) with flaps and snaps
  const pocketAt = (x, y, w, h, ry) => {
    const g = new THREE.Group(); g.position.set(x, y, Math.sqrt(Math.max(0, 0.2 * 0.2 - x * x)) * 0.8 + 0.002); g.rotation.y = ry; torso.add(g);
    const zz = 0.0;
    const p = mesh(new RoundedBoxGeometry(w, h, 0.016, 2, 0.006), C.vestPlain); p.position.z = zz; g.add(p);
    const f = mesh(new RoundedBoxGeometry(w * 1.06, h * 0.32, 0.02, 2, 0.007), C.vestPlain); f.position.set(0, h * 0.42, zz + 0.006); g.add(f);
    const ft = mesh(new THREE.BoxGeometry(w * 1.06, 0.006, 0.022), C.trim, false); ft.position.set(0, h * 0.27, zz + 0.006); g.add(ft);
    const sn = mesh(new THREE.CylinderGeometry(0.0055, 0.0055, 0.004, 12), C.chrome, false); sn.rotation.x = Math.PI / 2; sn.position.set(0, h * 0.38, zz + 0.018); g.add(sn);
  };
  // place pockets on the vest surface: compute z from the capsule (r 0.2, z-scale 0.8)
  pocketAt(-0.085, 0.43, 0.068, 0.062, -0.45);
  pocketAt(-0.1, 0.27, 0.08, 0.07, -0.52);
  pocketAt(0.1, 0.27, 0.08, 0.07, 0.52);
  // reflective band around the waist area of the vest
  const band = mesh(new THREE.TorusGeometry(0.186, 0.008, 6, 48), C.trim, false); band.rotation.x = Math.PI / 2; band.scale.set(1.03, 0.82, 1); band.position.y = 0.3; torso.add(band);

  // ---------- neck + head
  const neck = mesh(new THREE.CylinderGeometry(0.058, 0.066, 0.08, 18), C.skin); neck.position.y = 0.55; torso.add(neck);
  const headPivot = new THREE.Group(); headPivot.position.y = 0.57; torso.add(headPivot);
  const head = new THREE.Group(); head.position.y = 0.26; headPivot.add(head);
  const HR = new THREE.Vector3(0.3, 0.284, 0.278);
  const hg = new THREE.SphereGeometry(1, 112, 84);
  {
    const p = hg.attributes.position; const v = new THREE.Vector3(); const cols = [];
    const base = new THREE.Color('#ad6a3c'), blush = new THREE.Color('#c25a44'), dark = new THREE.Color('#8e5230');
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i);
      let d = 0;
      d += 0.06 * G(v, [0, -0.55, 0.75], 0.45);
      for (const s of [1, -1]) {
        d += 0.075 * G(v, [s * 0.55, -0.28, 0.72], 0.26);   // cheeks
        d += 0.035 * G(v, [s * 0.34, 0.3, 0.87], 0.17);     // brow ridge
        d -= 0.055 * G(v, [s * 0.36, 0.04, 0.92], 0.16);    // eye sockets
        d -= 0.03 * G(v, [s * 0.88, 0.2, 0.35], 0.28);      // temples
        d += 0.025 * G(v, [s * 0.6, -0.62, 0.45], 0.25);    // jaw line
      }
      d += 0.05 * G(v, [0, -0.88, 0.45], 0.2);              // chin
      d += 0.02 * G(v, [0, -0.42, 0.95], 0.14);             // philtrum/muzzle
      d += 0.05 * G(v, [0, 0.25, -0.9], 0.5);               // back of skull
      d -= 0.02 * G(v, [0, -0.7, 0.85], 0.12);              // under lower lip
      const k = 1 + d;
      p.setXYZ(i, v.x * k * HR.x, v.y * k * HR.y, v.z * k * HR.z);
      const c = base.clone();
      let bl = 0; for (const s of [1, -1]) bl += G(v, [s * 0.55, -0.25, 0.75], 0.2);
      c.lerp(blush, Math.min(0.55, bl * 0.55));
      c.lerp(dark, 0.35 * G(v, [0, -0.25, -0.2], 0.9) * (v.z < 0 ? 1 : 0.2)); // slight darker back/neck
      cols.push(c.r, c.g, c.b);
    }
    hg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
    hg.computeVertexNormals();
  }
  const skull = mesh(hg, C.head); head.add(skull);
  // surface query (head-local)
  const probe = new THREE.Mesh(hg, new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }));
  const ray = new THREE.Raycaster();
  const surf = (x, y) => { ray.set(new THREE.Vector3(x, y, 1), new THREE.Vector3(0, 0, -1)); const h = ray.intersectObject(probe)[0]; return h ? h.point.z : 0.2; };

  // ears
  for (const sx of [1, -1]) {
    const eg = new THREE.Group(); eg.position.set(sx * 0.288, -0.025, -0.02); eg.rotation.y = sx * 0.35; head.add(eg);
    const outer = mesh(new THREE.SphereGeometry(0.06, 20, 16), C.skin); outer.scale.set(0.42, 0.95, 0.68); eg.add(outer);
    const rim = mesh(new THREE.TorusGeometry(0.044, 0.011, 8, 24, Math.PI * 1.5), C.skin); rim.rotation.set(0, sx * Math.PI / 2, Math.PI * 0.25); rim.scale.set(1, 1.3, 1); rim.position.x = sx * 0.012; eg.add(rim);
    const concha = mesh(new THREE.SphereGeometry(0.03, 14, 10), C.skinDark, false); concha.scale.set(0.35, 0.9, 0.7); concha.position.set(sx * 0.016, -0.005, 0.004); eg.add(concha);
  }

  // eyes with lids
  const iTex = irisTex();
  const eyes = [];
  for (const sx of [1, -1]) {
    const ex = sx * 0.106, ey = 0.008;
    const sz = surf(ex, ey);
    const eg = new THREE.Group(); eg.position.set(ex, ey, sz - 0.02); eg.rotation.y = sx * 0.3; face(eg);
    const scaleG = new THREE.Group(); scaleG.scale.set(0.066, 0.076, 0.04); eg.add(scaleG);
    const ball = mesh(new THREE.SphereGeometry(1, 32, 24), C.eyeW, false); scaleG.add(ball);
    const irisG = new THREE.Group(); scaleG.add(irisG);
    const cap = mesh(new THREE.SphereGeometry(0.62, 32, 12, 0, Math.PI * 2, 0, 0.66), new THREE.MeshPhysicalMaterial({ map: iTex, roughness: 0.15, clearcoat: 1, clearcoatRoughness: 0.03 }), false);
    cap.rotation.x = Math.PI / 2; cap.position.z = 0.43; irisG.add(cap);
    // catchlights (fixed to the eye, not to the iris)
    const h1 = mesh(new THREE.SphereGeometry(0.15, 12, 8), C.hl, false); h1.position.set(0.28, 0.3, 0.9); scaleG.add(h1);
    const h2 = mesh(new THREE.SphereGeometry(0.065, 8, 6), C.hl, false); h2.position.set(-0.22, -0.24, 0.93); scaleG.add(h2);
    // lids
    const upper = new THREE.Group(); scaleG.add(upper);
    const ul = mesh(new THREE.SphereGeometry(1.12, 32, 12, Math.PI / 2 - 1.4, 2.8, 0, Math.PI / 2), C.skin, false); upper.add(ul);
    const lash = mesh(new THREE.TorusGeometry(1.12, 0.085, 8, 40, 2.8), C.lash, false); lash.rotation.x = Math.PI / 2; lash.rotation.z = -Math.PI / 2 - 1.4 + Math.PI; upper.add(lash);
    const lower = new THREE.Group(); scaleG.add(lower);
    const ll = mesh(new THREE.SphereGeometry(1.1, 32, 12, Math.PI / 2 - 1.4, 2.8, Math.PI / 2, Math.PI / 2), C.skin, false); lower.add(ll);
    eyes.push({ g: eg, scaleG, irisG, upper, lower, sx, hls: [h1, h2] });
  }
  function face(o) { head.add(o); }
  // eyebrows: thick tapered strokes following the brow ridge
  const brows = [];
  for (const sx of [1, -1]) {
    const bg = new THREE.Group(); head.add(bg);
    const pts = [];
    for (let i = 0; i <= 6; i++) { const u = i / 6; const x = sx * (0.04 + u * 0.13); const y = 0.112 + Math.sin(u * Math.PI) * 0.02 - u * 0.012; pts.push(new THREE.Vector3(x, y, surf(x, y) + 0.004)); }
    const center = pts[3].clone(); pts.forEach(p => p.sub(center)); bg.position.copy(center);
    const geo = taperTube(pts, 0.0155, 0.0065, { seg: 18, rad: 8, flat: 0.55, upFn: () => new THREE.Vector3(0, 0, 1), power: 1.4 });
    const b = mesh(geo, C.hairBase, false); bg.add(b);
    brows.push({ g: bg, base: center.clone(), sx });
  }
  // nose: bridge + tip + alae + nostrils
  const tipY = -0.058; const tipZ = surf(0, tipY);
  const bridge = mesh(new THREE.SphereGeometry(0.02, 14, 10), C.skin); bridge.scale.set(0.75, 1.8, 0.5); bridge.position.set(0, -0.022, surf(0, -0.022) - 0.006); bridge.rotation.x = 0.3; /* bridge removed: read as a floating lump in 3/4 view */
  const ntip = mesh(new THREE.SphereGeometry(0.026, 20, 14), C.skin); ntip.scale.set(1.12, 0.92, 0.85); ntip.position.set(0, tipY, tipZ + 0.012); head.add(ntip);
  for (const sx of [1, -1]) {
    const ala = mesh(new THREE.SphereGeometry(0.0145, 14, 10), C.skin); ala.position.set(sx * 0.024, tipY - 0.008, tipZ - 0.003); head.add(ala);
    const nos = mesh(new THREE.SphereGeometry(0.0085, 10, 8), C.mouth, false); nos.scale.set(1.3, 0.7, 1); nos.position.set(sx * 0.0135, tipY - 0.022, tipZ + 0.011); head.add(nos);
  }
  // mouth (rebuilt when the shape changes)
  const mouthG = new THREE.Group(); head.add(mouthG);
  const mouth = { key: '', meshes: [] };

  function buildMouth(open, smile, round) {
    const key = [open, smile, round].map(v => Math.round(v * 40)).join(',');
    if (key === mouth.key) return; mouth.key = key;
    for (const m of mouth.meshes) { mouthG.remove(m); if (m.geometry) m.geometry.dispose(); }
    mouth.meshes = [];
    const yc = -0.148;
    const w = 0.058 * (1 - 0.42 * round) * (1 + 0.1 * Math.max(0, smile));
    const cy = yc + 0.016 * smile * (1 - round);
    const upMid = yc - 0.004 * smile + 0.012 * open * (0.4 + round * 0.6);
    const loMid = yc - 0.004 * smile - 0.052 * open * (0.85 + 0.25 * round) - 0.003;
    const N = 20;
    const curve = (mid, bulge) => { const a = []; for (let i = 0; i <= N; i++) { const u = i / N, x = -w + 2 * w * u; const k = 1 - (2 * u - 1) ** 2; const kk = round > 0 ? Math.pow(k, 1 - 0.5 * round) : k; a.push([x, cy + (mid - cy) * kk + bulge * kk]); } return a; };
    const up = curve(upMid, 0), lo = curve(loMid, 0);
    const Z = (x, y, off) => surf(x, y) + off;
    // cavity
    if (open > 0.03) {
      const shp = new THREE.Shape(); up.forEach(([x, y], i) => i ? shp.lineTo(x, y) : shp.moveTo(x, y)); for (let i = lo.length - 1; i >= 0; i--) shp.lineTo(lo[i][0], lo[i][1]);
      const sg = new THREE.ShapeGeometry(shp, 4); const pp = sg.attributes.position; for (let i = 0; i < pp.count; i++) pp.setZ(i, Z(pp.getX(i), pp.getY(i), 0.0015));
      const cav = new THREE.Mesh(sg, C.mouth); mouthG.add(cav); mouth.meshes.push(cav);
      // teeth (upper) and tongue (lower)
      const gap = upMid - loMid;
      const tsh = new THREE.Shape(); const tdrop = Math.min(0.012, gap * 0.32);
      up.forEach(([x, y], i) => i ? tsh.lineTo(x * 0.9, y - 0.001) : tsh.moveTo(x * 0.9, y - 0.001)); for (let i = up.length - 1; i >= 0; i--) tsh.lineTo(up[i][0] * 0.82, up[i][1] - tdrop * (1 - Math.abs(2 * i / N - 1) ** 2 * 0.6));
      const tg = new THREE.ShapeGeometry(tsh, 4); const tp = tg.attributes.position; for (let i = 0; i < tp.count; i++) tp.setZ(i, Z(tp.getX(i), tp.getY(i), 0.0024));
      const teeth = new THREE.Mesh(tg, C.teeth); mouthG.add(teeth); mouth.meshes.push(teeth);
      const tongue = new THREE.Mesh(new THREE.CircleGeometry(1, 24), C.tongue);
      const tw = w * 0.62, th = Math.max(0.004, gap * 0.28);
      const tgp = tongue.geometry.attributes.position;
      for (let i = 0; i < tgp.count; i++) { const x = tgp.getX(i) * tw, y = loMid + th * 0.9 + tgp.getY(i) * th; tgp.setXYZ(i, x, y, Z(x, y, 0.0021)); }
      mouthG.add(tongue); mouth.meshes.push(tongue);
    }
    // lips
    const lipPts = (arr, dy, off) => arr.map(([x, y]) => new THREE.Vector3(x, y + dy, Z(x, y + dy, off)));
    const line = new THREE.Mesh(taperTube(lipPts(up, 0.0, 0.0015), 0.0042, 0.0042, { seg: 24, rad: 8, flat: 0.6, upFn: () => new THREE.Vector3(0, 0, 1), power: 1 }), C.mouthLine);
    const ul = new THREE.Object3D();
    const ll = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 10), C.lips);
    { const lx = 0, ly = loMid - 0.009; ll.scale.set(w * 0.5, 0.0065, 0.0045); ll.position.set(lx, ly, Z(lx, ly, -0.0015)); ll.visible = open < 0.12; }
    mouthG.add(line); mouth.meshes.push(line);
    // taper lip ends by scaling toward the corners: add small corner dimples
    mouthG.add(ul, ll); mouth.meshes.push(ul, ll);
    for (const s of [0, N]) { const [x, y] = up[s]; const d = new THREE.Mesh(new THREE.SphereGeometry(0.0045, 10, 8), C.mouthLine); d.position.set(x, y, Z(x, y, 0.0012)); mouthG.add(d); mouth.meshes.push(d); }
  }
  buildMouth(0, 1, 0);

  // ---------- hair: base cap + clumped locks
  const hairG = new THREE.Group(); hairG.position.set(0, 0.12, -0.02); head.add(hairG);
  const hairOff = new THREE.Vector3(0, -0.12, 0.02); // undo pivot offset for geometry built in head space
  const capG = new THREE.SphereGeometry(1, 64, 32, 0, Math.PI * 2, 0, Math.PI * 0.5);
  { const p = capG.attributes.position; for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i); p.setXYZ(i, v.x * HR.x * 1.045, v.y * HR.y * 1.06, v.z * HR.z * 1.05); } capG.computeVertexNormals(); }
  const cap = mesh(capG, C.hairBase); cap.rotation.x = -0.6; cap.position.set(0, 0.0, -0.004).add(hairOff); hairG.add(cap);
  const backCap = mesh(new THREE.SphereGeometry(1, 48, 24), C.hairBase); backCap.scale.set(HR.x * 1.02, HR.y * 0.86, HR.z * 0.86); backCap.position.set(0, 0.01, -0.075).add(hairOff); /* back covered by the tilted cap */
  const napeG = new THREE.SphereGeometry(1, 48, 16, Math.PI * 1.5 - 1.15, 2.3, Math.PI * 0.45, Math.PI * 0.3);
  { const pp = napeG.attributes.position; for (let i = 0; i < pp.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(pp, i); pp.setXYZ(i, v.x * HR.x * 1.04, v.y * HR.y * 1.04, v.z * HR.z * 1.04); } napeG.computeVertexNormals(); }
  const nape = mesh(napeG, C.hairBase); nape.position.copy(hairOff); hairG.add(nape);
  const HRR = HR.clone().multiplyScalar(1.03);
  const sph = (az, el, lift) => new THREE.Vector3((HRR.x + lift) * Math.cos(el) * Math.sin(az), (HRR.y + lift) * Math.sin(el), (HRR.z + lift) * Math.cos(el) * Math.cos(az));
  const hr = rng(77);
  const root_ = new THREE.Color('#160d08'), midC = new THREE.Color('#33211a'), hiC = new THREE.Color('#8c6242');
  const lockColor = (j, hp) => (u) => { const c = root_.clone().lerp(midC, Math.min(1, u * 2.5)); const hl = Math.exp(-((u - hp) ** 2) / 0.01); c.lerp(hiC, hl * (0.5 + j * 0.35)); return c; };
  const addLock = (a0, e0, a1, e1, liftPeak, w, { n = 8, peakU = 0.35, tip = 0.4, hp = 0.45, flat = 0.42 } = {}) => {
    const pts = [];
    for (let i = 0; i <= n; i++) { const u = i / n; const az = a0 + (a1 - a0) * u; const el = e0 + (e1 - e0) * u; const lift = 0.006 + liftPeak * Math.exp(-((u - peakU) ** 2) / 0.06) * (u < peakU ? Math.min(1, u / peakU * 1.6) : 1); pts.push(sph(az, el, lift).add(hairOff)); }
    const geo = taperTube(pts, w, w * tip, { seg: 20, rad: 8, flat, upFn: (P) => P.clone().sub(hairOff).normalize(), colorFn: lockColor(hr(), hp), power: 1.8 });
    hairG.add(mesh(geo, C.hair));
  };
  // short side-swept cut: part on the character's left, textured top, tapered short sides and back
  const PART = 0.42;
  for (let i = 0; i < 9; i++) {
    const k = i / 8; const e0 = 0.74 + k * 0.6;
    addLock(PART + (hr() - 0.5) * 0.05, e0, -0.7 - k * 0.5, 0.78 + k * 0.38, 0.03 - k * 0.012, 0.064 - k * 0.01, { n: 10, peakU: 0.4, tip: 0.35, hp: 0.4, flat: 0.34 });
  }
  for (let i = 0; i < 5; i++) { const a = PART - 0.12 - i * 0.2; addLock(a, 0.84, a - 0.32, 0.66 + (hr() - 0.5) * 0.03, 0.035, 0.046, { n: 8, peakU: 0.5, tip: 0.3, hp: 0.45, flat: 0.36 }); }
  for (let i = 0; i < 4; i++) { const k = i / 3; addLock(PART + 0.04, 0.8 + k * 0.45, 1.05 + k * 0.35, 0.5 + k * 0.08, 0.012, 0.05, { n: 8, peakU: 0.35, tip: 0.45, hp: 0.45, flat: 0.34 }); }
  for (let i = 0; i < 4; i++) { const e = 0.62 - i * 0.07; addLock(-0.85 - i * 0.05, e, -1.8 - hr() * 0.15, e - 0.06, 0.008, 0.044, { n: 8, peakU: 0.4, tip: 0.5, hp: 0.5, flat: 0.34 }); }
  for (let i = 0; i < 12; i++) { const a = 0.9 + i * (4.5 / 11); const back = Math.cos(a) < 0 ? -Math.cos(a) : 0; addLock(PART * 0.5, 1.42, a, 0.42 - back * 0.55 - hr() * 0.06, 0.012, 0.058, { n: 9, peakU: 0.3, tip: 0.5, hp: 0.42, flat: 0.32 }); }
  // sideburns
  for (const s of [1, -1]) { const sb = mesh(new THREE.SphereGeometry(0.04, 12, 10), C.hairBase); sb.scale.set(0.45, 1.3, 0.8); sb.position.set(s * 0.274, 0.05, 0.06).add(hairOff); hairG.add(sb); }

  // ---------- arms + hands
  const arms = {};
  for (const s of ['l', 'r']) {
    const sx = s === 'l' ? 1 : -1;
    const sh = new THREE.Group(); sh.position.set(sx * 0.215, 0.45, 0); sh.rotation.order = 'XZY'; torso.add(sh);
    const ball = mesh(new THREE.SphereGeometry(0.075, 20, 14), C.shirt); sh.add(ball);
    const sleeve = mesh(new THREE.CylinderGeometry(0.075, 0.07, 0.11, 20), C.shirt); sleeve.position.y = -0.055; sh.add(sleeve);
    const sleeveHem = mesh(new THREE.TorusGeometry(0.069, 0.01, 8, 24), C.shirt); sleeveHem.rotation.x = Math.PI / 2; sleeveHem.position.y = -0.108; sh.add(sleeveHem);
    const arm = mesh(new THREE.CapsuleGeometry(0.055, 0.1, 8, 16), C.skin); arm.position.y = -0.135; sh.add(arm);
    const armhole = mesh(new THREE.TorusGeometry(0.079, 0.009, 8, 20), C.trim, false); armhole.rotation.y = Math.PI / 2; armhole.position.set(-sx * 0.02, 0.0, 0); sh.add(armhole);
    const el = new THREE.Group(); el.position.y = -0.205; el.rotation.order = 'XYZ'; sh.add(el);
    const elb = mesh(new THREE.SphereGeometry(0.052, 16, 12), C.skin); el.add(elb);
    const fore = mesh(new THREE.CylinderGeometry(0.052, 0.04, 0.165, 16), C.skin); fore.position.y = -0.088; el.add(fore);
    const wristBall = mesh(new THREE.SphereGeometry(0.041, 14, 10), C.skin); wristBall.position.y = -0.17; el.add(wristBall);
    const wrist = new THREE.Group(); wrist.position.y = -0.18; el.add(wrist);
    const H = buildHand(sx, C); wrist.add(H.hand);
    arms[s] = { sh, el, wrist, H, sx, L1: 0.205, L2: 0.18 };
  }

  // ---------- microphone (left hand, inside the fist)
  const mic = new THREE.Group();
  const handle = mesh(new THREE.CylinderGeometry(0.019, 0.016, 0.2, 16), C.black); mic.add(handle);
  const grill = mesh(new THREE.SphereGeometry(0.046, 24, 16), C.metal); grill.position.y = 0.135; mic.add(grill);
  const ring = mesh(new THREE.CylinderGeometry(0.03, 0.022, 0.03, 16), C.metal); ring.position.y = 0.098; mic.add(ring);
  const flagCanvas = document.createElement('canvas'); flagCanvas.width = flagCanvas.height = 256;
  const flagTex = new THREE.CanvasTexture(flagCanvas); flagTex.colorSpace = THREE.SRGBColorSpace;
  const flag = mesh(new RoundedBoxGeometry(0.085, 0.085, 0.085, 2, 0.008), new THREE.MeshPhysicalMaterial({ map: flagTex, roughness: 0.35, clearcoat: 0.6 }));
  flag.position.y = 0.045; mic.add(flag);
  // mic sits across the fist: handle axis along the hand's lateral axis, head on the thumb side
  const micHolder = new THREE.Group(); micHolder.add(mic);
  micHolder.position.set(0.0, -0.075, 0.03);
  micHolder.rotation.set(0, 0, -arms.l.sx * Math.PI / 2 * 0.0);
  arms.l.wrist.add(micHolder);

  // ---------- phone (placed in root space; the right hand grips it with IK)
  const phone = new THREE.Group();
  const pbody = mesh(new RoundedBoxGeometry(PW, PH, PT, 4, 0.014), new THREE.MeshPhysicalMaterial({ color: '#1a1f29', roughness: 0.25, metalness: 0.6, clearcoat: 1 }));
  phone.add(pbody);
  const screenCanvas = document.createElement('canvas'); screenCanvas.width = 780; screenCanvas.height = 1688;
  const screenTex = new THREE.CanvasTexture(screenCanvas); screenTex.colorSpace = THREE.SRGBColorSpace; screenTex.anisotropy = 8;
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(PHONE.SW, PHONE.SH), new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false })); screen.position.z = PT / 2 + 0.0006; phone.add(screen);
  const camBump = mesh(new RoundedBoxGeometry(0.026, 0.026, 0.004, 2, 0.006), C.black); camBump.position.set(-PW / 2 + 0.019, PH / 2 - 0.019, -PT / 2 - 0.0015); phone.add(camBump);
  const phoneHolder = new THREE.Group(); phoneHolder.add(phone); root.add(phoneHolder);

  // ---------- laptop (held in front of the chest)
  const laptop = new THREE.Group();
  const lapMat = new THREE.MeshPhysicalMaterial({ color: '#c9d2de', roughness: 0.3, metalness: 0.75, clearcoat: 0.6 });
  const LW = 0.46, LD = 0.3;
  const lbase = mesh(new RoundedBoxGeometry(LW, 0.022, LD, 3, 0.01), lapMat); laptop.add(lbase);
  const kb = mesh(new THREE.BoxGeometry(LW * 0.86, 0.004, LD * 0.5), C.black, false); kb.position.set(0, 0.012, -0.02); laptop.add(kb);
  const lidPivot = new THREE.Group(); lidPivot.position.set(0, 0.011, -LD / 2 + 0.005); laptop.add(lidPivot);
  const lid = mesh(new RoundedBoxGeometry(LW, 0.3, 0.014, 3, 0.007), lapMat); lid.position.set(0, 0.15, -0.007); lidPivot.add(lid);
  const bezel = mesh(new THREE.PlaneGeometry(LW * 0.97, 0.29), C.black, false); bezel.position.set(0, 0.15, 0.0005); lidPivot.add(bezel);
  const lapCanvas = document.createElement('canvas'); lapCanvas.width = 1280; lapCanvas.height = 800;
  const lapTex = new THREE.CanvasTexture(lapCanvas); lapTex.colorSpace = THREE.SRGBColorSpace; lapTex.anisotropy = 8;
  const lscreen = new THREE.Mesh(new THREE.PlaneGeometry(LW * 0.92, LW * 0.92 * 0.625), new THREE.MeshBasicMaterial({ map: lapTex, toneMapped: false }));
  lscreen.position.set(0, 0.152, 0.001); lidPivot.add(lscreen);
  lidPivot.rotation.x = -0.12;
  laptop.position.set(0, 0.27, 0.37);
  torso.add(laptop); laptop.visible = false;

  // contact shadow under the feet (soft blob)
  const blobC = document.createElement('canvas'); blobC.width = blobC.height = 128; { const x = blobC.getContext('2d'); const gr = x.createRadialGradient(64, 64, 4, 64, 64, 64); gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(0.5, 'rgba(0,0,0,0.25)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(0, 0, 128, 128); }
  const blob = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 0.55), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(blobC), transparent: true, depthWrite: false }));
  blob.rotation.x = -Math.PI / 2; blob.renderOrder = 1;

  rigGripInfo = solveGrip(arms.r.H);
  const rig = { gripInfo: rigGripInfo, laptop, lidPivot, lapCanvas, lapTex, root, hips, torso, headPivot, head, eyes, brows, legs, arms, mic, micHolder, flagCanvas, flagTex, phone, phoneHolder, screen, screenCanvas, screenTex, C, body, hairG, vestLag, blob, buildMouth };
  rig.setPose = (p) => applyPose(rig, p);
  return rig;
}

// ------------------------------------------------------------------ IK
const _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _m = new THREE.Matrix4();
function basisQuat(X, Y, Z) { _m.makeBasis(X, Y, Z); return new THREE.Quaternion().setFromRotationMatrix(_m); }
// hand world orientation from finger direction F (hand -Y) and palm normal P (hand +Z)
export function handQuat(F, P) {
  const Y = F.clone().negate().normalize();
  const Z = P.clone().addScaledVector(Y, -P.dot(Y)).normalize();
  const X = new THREE.Vector3().crossVectors(Y, Z);
  return basisQuat(X, Y, Z);
}
// solve shoulder/elbow/wrist so the wrist reaches T (world) with hand orientation HQ (world). weight w blends from FK.
function solveArm(rig, side, T, HQ, w) {
  if (w <= 0) return;
  const A = rig.arms[side]; const sx = A.sx;
  rig.torso.updateMatrixWorld(true);
  const S = new THREE.Vector3(); A.sh.getWorldPosition(S);
  const torsoQ = rig.torso.getWorldQuaternion(new THREE.Quaternion());
  const d = T.clone().sub(S); let D = d.length();
  rig.debug = rig.debug || {}; rig.debug[side] = { reach: D, max: A.L1 + A.L2, S: S.toArray().map(v => +v.toFixed(3)), T: T.toArray().map(v => +v.toFixed(3)) };
  const L1 = A.L1, L2 = A.L2; D = Math.min(Math.max(D, Math.abs(L1 - L2) + 1e-3), L1 + L2 - 1e-4);
  const dh = d.normalize();
  const pole = new THREE.Vector3(sx * 0.55, -1, -0.45).applyQuaternion(torsoQ).normalize();
  const perp = pole.clone().addScaledVector(dh, -pole.dot(dh)).normalize();
  const cosA = (L1 * L1 + D * D - L2 * L2) / (2 * L1 * D); const a = Math.acos(Math.min(1, Math.max(-1, cosA)));
  const u = dh.clone().multiplyScalar(Math.cos(a)).addScaledVector(perp, Math.sin(a)).normalize();
  const E = S.clone().addScaledVector(u, L1);
  const Tc = S.clone().addScaledVector(dh, D);
  const f = Tc.clone().sub(E).normalize();
  const Y = u.clone().negate();
  let Z = f.clone().addScaledVector(u, -f.dot(u)); if (Z.lengthSq() < 1e-8) Z = perp.clone().negate(); Z.normalize();
  const X = new THREE.Vector3().crossVectors(Y, Z);
  const qSh = basisQuat(X, Y, Z);
  const bend = Math.acos(Math.min(1, Math.max(-1, u.dot(f))));
  const qShLocal = torsoQ.clone().invert().multiply(qSh);
  const qEl = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -bend);
  const elW = qSh.clone().multiply(qEl);
  const qWr = elW.clone().invert().multiply(HQ);
  A.sh.quaternion.slerp(qShLocal, w); A.el.quaternion.slerp(qEl, w); A.wrist.quaternion.slerp(qWr, w);
}

let rigGripInfo = null;
export const SIDE = { gap: 0.03, y: 0.006, z: -0.06 };
// right-hand grip in phone space: palm centre position and directions
const GRIP_R = { pos: new THREE.Vector3(0.03, -0.065, -0.031), F: new THREE.Vector3(-1, 0.1, 0.0), P: new THREE.Vector3(0.0, 0.0, 1) };
const PALM_OFF = new THREE.Vector3(0, -0.05, 0); // palm centre in hand space
function gripMatrix(gr, sx) {
  const q = handQuat(gr.F.clone().normalize(), gr.P.clone().normalize());
  const wristPos = gr.pos.clone().sub(PALM_OFF.clone().applyQuaternion(q));
  return new THREE.Matrix4().compose(wristPos, q, new THREE.Vector3(1, 1, 1));
}
let GRIP_R_M = gripMatrix(GRIP_R, -1);
export function setGripR(g) { if (g.pos) GRIP_R.pos.fromArray(g.pos); if (g.F) GRIP_R.F.fromArray(g.F); if (g.P) GRIP_R.P.fromArray(g.P); GRIP_R_M = gripMatrix(GRIP_R, -1); }
let GRIP_L_PHOTO = gripMatrix({ pos: new THREE.Vector3(-0.03, -PH / 2 - 0.022, -0.006), F: new THREE.Vector3(1, 0, -0.35), P: new THREE.Vector3(0, 1, 0) }, 1);
export function setGripL(g) { GRIP_L_PHOTO = gripMatrix({ pos: new THREE.Vector3(...g.pos), F: new THREE.Vector3(...g.F), P: new THREE.Vector3(...g.P) }, 1); }

// ------------------------------------------------------------------ phone collision helpers (phone-local space)
export let TAPZ = 0.0046;
export function phoneSDF(p) {
  const R = PT / 2; const qx = Math.abs(p.x) - (PW / 2 - R), qy = Math.abs(p.y) - (PH / 2 - R), qz = Math.abs(p.z) - (PT / 2 - R);
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qy, qz), 0) - R;
}
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3();
function chainPen(pts, rads, margin = 0.0009) {
  let pen = 0;
  for (let i = 0; i < pts.length - 1; i++) for (let k = 0; k <= 5; k++) {
    const u = k / 5; _c.copy(pts[i]).lerp(pts[i + 1], u); const r = rads[i] + (rads[i + 1] - rads[i]) * u;
    pen += Math.max(0, r + margin - phoneSDF(_c));
  }
  return pen * 1000;
}
function chainPts(objs, inv) { return objs.map(o => o.getWorldPosition(new THREE.Vector3()).applyMatrix4(inv)); }
function fingerPen(H, k, inv) { const f = H.fingers[k]; const R0 = k === 'k' ? 0.0115 : 0.0132; return chainPen(chainPts([f.base, f.segs[1], f.segs[2], f.tip], inv), [R0 * 1.05, R0 * 0.91, R0 * 0.82, R0 * 0.7]); }
function thumbPen(H, inv) { return chainPen(chainPts([H.thumb.base, H.thumb.t1, H.thumb.t2, H.thumb.tip], inv), [0.017, 0.0145, 0.0135, 0.01]); }
function palmPen(H, inv) {
  // palm block sampled as a grid of spheres
  let pen = 0; const P = new THREE.Vector3();
  for (const x of [-0.034, -0.012, 0.012, 0.034]) for (const y of [-0.022, -0.05, -0.078]) { P.set(x, y, 0.004).applyMatrix4(H.hand.matrixWorld).applyMatrix4(inv); pen += Math.max(0, 0.0185 + 0.0008 - phoneSDF(P)); }
  return pen * 1000;
}
// solve the right-hand grip once: finger curls that wrap the left side without entering the phone, thumb resting on the right bezel
export function solveGrip(H) {
  const dummy = new THREE.Object3D(); const parent = H.hand.parent; dummy.add(H.hand);
  dummy.matrixAutoUpdate = false; dummy.matrix.copy(GRIP_R_M); dummy.matrixWorld.copy(GRIP_R_M);
  const I = new THREE.Matrix4();
  const hp = HANDS.grip;
  applyHand(H, hp); H.hand.updateMatrixWorld(true);
  const res = { palmPen: palmPen(H, I) };
  for (const k of ['i', 'm', 'r', 'k']) {
    const f = H.fingers[k];
    const yb = f.base.getWorldPosition(new THREE.Vector3()).y;
    const T = new THREE.Vector3(-PW / 2 - 0.002, yb - 0.004, 0.003);
    const cost = (c) => { hp[k] = c; applyHand(H, hp); H.hand.updateMatrixWorld(true); return 10 * fingerPen(H, k, I) + 1000 * f.tip.getWorldPosition(_a).distanceTo(T); };
    let v = hp[k].slice(), best = cost(v);
    for (let st = 0.4; st > 0.005; st *= 0.6) for (let j = 0; j < 3; j++) for (const sg of [1, -1]) { const c = v.slice(); c[j] = Math.min(1.75, Math.max(-0.15, c[j] + sg * st)); const d = cost(c); if (d < best) { best = d; v = c; } }
    hp[k] = v; res[k] = { pen: fingerPen(H, k, I), d: f.tip.getWorldPosition(_a).distanceTo(T) };
  }
  applyHand(H, hp); H.hand.updateMatrixWorld(true);
  // thumb rest on the right bezel, in front of the glass
  const tb = H.thumb.base.getWorldPosition(new THREE.Vector3());
  THUMB_REST.set(PW / 2 - 0.006, Math.min(PH / 2 - 0.02, tb.y + 0.012), PT / 2 + 0.012);
  const tr = thumbReach({ arms: { r: { H, wrist: H.hand } } }, 'r', THUMB_REST, 1, hp.t, I, true);
  const tv = H.thumb.lastV; hp.t = [tv[0], tv[1], tv[2], tv[2] * 0.85];
  res.thumbCost = tr; res.thumbPen = thumbPen(H, I);
  parent.add(H.hand); H.hand.position.set(0, 0, 0); H.hand.quaternion.identity();
  return res;
}
export const THUMB_REST = new THREE.Vector3();
export function thumbRestNorm() { return { x: 0.5 + THUMB_REST.x / PHONE.SW, y: 0.5 - THUMB_REST.y / PHONE.SH, lift: THUMB_REST.z - PT / 2 - 0.009 }; }

// thumb reach: coordinate descent on (yaw, pitch, bend) so the thumb tip touches a world point
function thumbReach(rig, side, target, w, base, phoneInv = null, multi = false) {
  const H = rig.arms[side].H; const sx = H.sx;
  const tip = new THREE.Vector3();
  const setT = (v) => { H.thumb.base.rotation.set(-v[1] * 0.9, sx * v[1] * 0.4, sx * (0.55 + v[0]), 'XYZ'); H.thumb.t1.rotation.x = -v[2]; H.thumb.t2.rotation.x = -v[2] * 0.85; H.thumb.base.updateMatrixWorld(true); return H.thumb.tip.getWorldPosition(tip).distanceTo(target) + (phoneInv ? 0.01 * thumbPen(H, phoneInv) : 0); };
  rig.arms[side].wrist.updateMatrixWorld(true);
  let v = [base[0], base[1], base[2]]; let best = setT(v);
  if (multi) for (const a of [-1, -0.3, 0.4, 1.1]) for (const b of [-1, -0.2, 0.6, 1.4]) for (const c of [0, 0.7]) { const d = setT([a, b, c]); if (d < best) { best = d; v = [a, b, c]; } }
  const lo = [-1.3, -1.3, -0.4], hi = [1.7, 2.1, 1.4];
  for (let st = 0.4; st > 0.01; st *= 0.55) for (let k = 0; k < 3; k++) for (const sgn of [1, -1]) {
    const c = v.slice(); c[k] = Math.min(hi[k], Math.max(lo[k], c[k] + sgn * st)); const d = setT(c); if (d < best) { best = d; v = c; } }
  const f = [base[0] + (v[0] - base[0]) * w, base[1] + (v[1] - base[1]) * w, base[2] + (v[2] - base[2]) * w];
  setT(f); H.thumb.lastV = v;
  return best;
}
export function phonePoint(nx, ny, lift) { return new THREE.Vector3((nx - 0.5) * PHONE.SW, (0.5 - ny) * PHONE.SH, PT / 2 + lift); }

// ------------------------------------------------------------------ apply pose
export function applyPose(rig, P) {
  const p = { ...DEFAULT_POSE, ...P };
  rig.root.position.set(p.x, p.y, p.z);
  rig.root.rotation.y = p.rotY;
  rig.hips.position.set(p.sway, 0.43 + p.bob, 0);
  rig.hips.rotation.z = -p.sway * 0.6;
  rig.torso.rotation.set(p.torsoX + p.lean, p.torsoY, p.torsoZ + p.sway * 1.2);
  rig.headPivot.rotation.set(p.headX, p.headY, p.headZ - p.sway * 0.8);
  // FK arms
  for (const s of ['l', 'r']) {
    const a = rig.arms[s]; const sx = a.sx;
    a.sh.rotation.set(-p[s + 'Fwd'], sx * p[s + 'Twist'], sx * p[s + 'Out']);
    a.el.rotation.set(p[s + 'Elbow'], 0, 0);
    a.wrist.rotation.set(p[s + 'WristX'], sx * p[s + 'WristY'], sx * p[s + 'WristZ']);
  }
  applyHand(rig.arms.r.H, p.handR); applyHand(rig.arms.l.H, p.handL);
  for (const s of ['l', 'r']) {
    const L = rig.legs[s]; const sx = s === 'l' ? 1 : -1;
    L.hip.rotation.set(-p[s + 'Leg'], 0, sx * p.legSpread + p.sway * 0.6);
    L.knee.rotation.x = p[s + 'Knee'];
    L.foot.rotation.x = -p[s + 'Knee'] * 0.5 + p[s + 'Leg'] * 0.6;
    L.foot.rotation.z = -sx * p.legSpread - p.sway * 0.6;
  }
  // face
  const bl = Math.max(0, Math.min(1, p.blink));
  for (const e of rig.eyes) {
    e.g.scale.setScalar(p.eyeScale);
    e.irisG.rotation.set(-p.eyeY * 0.32, p.eyeX * 0.42, 0);
    const openUp = -0.6 - p.lidUp * 0.3 + p.squint * 0.22;
    e.upper.rotation.x = openUp + (0.66 - openUp) * bl;
    for (const h of e.hls) { const k = Math.max(0, 1 - bl * 1.6); h.scale.setScalar(Math.max(0.001, k)); h.visible = k > 0.05 && p.squint <= 0.4; }
    e.lower.rotation.x = 0.7 - p.squint * 0.3 - 0.12 * Math.max(0, p.smile) * Math.min(1, p.mouthOpen * 2);
  }
  for (const b of rig.brows) {
    b.g.position.set(b.base.x, b.base.y + p.brow * 0.022, b.base.z + p.brow * 0.002);
    b.g.rotation.z = b.sx * p.browTilt * 0.28;
  }
  rig.buildMouth(Math.max(0, p.mouthOpen), p.smile, p.round);
  // hair + vest secondary motion
  rig.hairG.rotation.set(p.hairLagX, 0, p.hairLagZ);
  rig.vestLag.rotation.set(p.vestLag * 0.5, 0, 0);
  rig.mic.visible = p.mic > 0.5;
  // mic in the fist: across the palm, head up (thumb side)
  rig.micHolder.position.set(0.0, -0.068, 0.035);
  rig.micHolder.rotation.set(0.0, 0, -rig.arms.l.sx * Math.PI / 2);
  rig.laptop.visible = p.laptop > 0.01;
  rig.laptop.scale.setScalar(Math.max(0.001, p.laptop));

  // ---------- phone placement + grips (IK)
  rig.phoneHolder.visible = p.phone > 0.5;
  rig.root.updateMatrixWorld(true);
  const rootM = rig.root.matrixWorld;
  if (p.phone > 0.5) {
    // A: phone follows the FK right hand
    const wristW = rig.arms.r.wrist.matrixWorld.clone();
    const phoneA = wristW.multiply(GRIP_R_M.clone().invert()).multiply(new THREE.Matrix4().makeTranslation(0, -p.rGripDY, 0));
    // B: phone placed in root space
    const qB = new THREE.Quaternion().setFromEuler(new THREE.Euler(p.aimPitch, p.aimYaw, p.aimRoll, 'YXZ'));
    const phoneB = rootM.clone().multiply(new THREE.Matrix4().compose(new THREE.Vector3(p.phX, p.phY, p.phZ), qB, new THREE.Vector3(1, 1, 1)));
    const pa = new THREE.Vector3(), qa = new THREE.Quaternion(), sa = new THREE.Vector3(); phoneA.decompose(pa, qa, sa);
    const pb = new THREE.Vector3(), qb = new THREE.Quaternion(), sb = new THREE.Vector3(); phoneB.decompose(pb, qb, sb);
    const w = Math.min(1, Math.max(0, p.aimW));
    const pw = pa.lerp(pb, w), qw = qa.slerp(qb, w);
    const phoneW = new THREE.Matrix4().compose(pw, qw, new THREE.Vector3(1, 1, 1));
    // to holder local (holder is child of root)
    const local = rootM.clone().invert().multiply(phoneW);
    local.decompose(rig.phoneHolder.position, rig.phoneHolder.quaternion, rig.phoneHolder.scale);
    rig.phoneHolder.updateMatrixWorld(true);
    // right hand grips the phone
    const handW = phoneW.clone().multiply(new THREE.Matrix4().makeTranslation(0, p.rGripDY, 0)).multiply(GRIP_R_M);
    const hp = new THREE.Vector3(), hq = new THREE.Quaternion(), hs = new THREE.Vector3(); handW.decompose(hp, hq, hs);
    if (p.rTapLift) hp.addScaledVector(new THREE.Vector3(0, 0, 1).applyQuaternion(qw), p.rTapLift);
    solveArm(rig, 'r', hp, hq, 1);
    // right thumb touches / hovers over a screen point (typing)
    if (p.rThumbW > 0) {
      const tgt = phonePoint(p.rThumbX, p.rThumbY, 0.009 + p.rThumbLift).applyMatrix4(phoneW);
      rig.debug = rig.debug || {}; rig.debug.thumbErr = thumbReach(rig, 'r', tgt, p.rThumbW, p.handR.t, phoneW.clone().invert(), true);
    }
    // left hand: photo support grip
    if (p.lGripW > 0) {
      const lw = phoneW.clone().multiply(GRIP_L_PHOTO); const lp = new THREE.Vector3(), lq = new THREE.Quaternion(); lw.decompose(lp, lq, new THREE.Vector3());
      solveArm(rig, 'l', lp, lq, p.lGripW);
      if (p.lThumbW > 0) { const tgt = phonePoint(p.lThumbX, p.lThumbY, 0.009 + p.lThumbLift).applyMatrix4(phoneW); rig.debug = rig.debug || {}; rig.debug.lthumbErr = thumbReach(rig, 'l', tgt, p.lThumbW, p.handL.t, phoneW.clone().invert()); }
    }
    // left index taps a point on the screen
    if (p.lTapW > 0) {
      const H = rig.arms.l.H; rig.arms.l.wrist.updateMatrixWorld(true);
      // fingertip offset in wrist space (from current hand pose)
      const tipW = H.fingers.i.tip.getWorldPosition(new THREE.Vector3());
      const tipLocal = rig.arms.l.wrist.worldToLocal(tipW.clone());
      const sxp = (p.lTapX - 0.5) * PHONE.SW, syp = (0.5 - p.lTapY) * PHONE.SH;
      const tgt = new THREE.Vector3(sxp, syp, PT / 2 + TAPZ + p.lLift).applyMatrix4(phoneW);
      const ax = new THREE.Vector3(1, 0, 0).applyQuaternion(qw), ay = new THREE.Vector3(0, 1, 0).applyQuaternion(qw), az = new THREE.Vector3(0, 0, 1).applyQuaternion(qw);
      const Sl = rig.arms.l.sh.getWorldPosition(new THREE.Vector3());
      const toT = tgt.clone().sub(Sl).normalize();
      const F = toT.multiplyScalar(0.8).addScaledVector(az, -0.56).addScaledVector(ax, 0.12).normalize();
      const Pn = az.clone().negate().addScaledVector(ay, -0.3).normalize();
      const q = handQuat(F, Pn);
      const wristT = tgt.clone().sub(tipLocal.applyQuaternion(q));
      solveArm(rig, 'l', wristT, q, p.lTapW);
    }
  }
  // laptop: side grip — palm on the outside of each side edge, fingers curled under the base, thumb on top of the deck
  if (p.laptop > 0.3) {
    rig.laptop.updateMatrixWorld(true);
    const lm = rig.laptop.matrixWorld; const lq = rig.laptop.getWorldQuaternion(new THREE.Quaternion());
    for (const s of ['l', 'r']) {
      const sx = rig.arms[s].sx;
      const ax = new THREE.Vector3(1, 0, 0).applyQuaternion(lq), ay = new THREE.Vector3(0, 1, 0).applyQuaternion(lq), az = new THREE.Vector3(0, 0, 1).applyQuaternion(lq);
      const F = ay.clone().multiplyScalar(-0.55).addScaledVector(az, 0.35).addScaledVector(ax, -sx * 0.25).normalize();
      const q = handQuat(F, ax.clone().multiplyScalar(-sx));
      const palm = new THREE.Vector3(sx * (0.23 + SIDE.gap), SIDE.y, SIDE.z).applyMatrix4(lm);
      const wristT = palm.sub(PALM_OFF.clone().applyQuaternion(q));
      solveArm(rig, s, wristT, q, Math.min(1, (p.laptop - 0.3) / 0.5));
    }
  }
  // contact shadow
  rig.blob.position.set(p.x, 0.012, p.z); rig.blob.rotation.z = -p.rotY;
  const hgt = Math.max(0, p.y);
  rig.blob.scale.setScalar(1 + hgt * 1.5); rig.blob.material.opacity = 1 - Math.min(0.7, hgt * 3);
}
