// tap times of the typing SFX (music.py typing(), rng 42)
export const TYPING_TAPS = [12.5, 12.626, 12.706, 12.842, 12.978, 13.12, 13.202, 13.301, 13.39, 13.485, 13.609, 13.732, 13.814, 13.945, 14.017, 14.406, 14.521, 14.904, 14.987, 15.087, 15.167, 15.314, 15.392, 15.508, 15.613, 16.016, 16.094, 16.192, 16.325, 16.441];
// The sentence typed on the phone (same text as the input box of app_3).
export const TYPED_TEXT = 'Esta mañana cayó un árbol en la calle principal del barrio El Centro, frente a la farmacia.';
// TAP_CHARS[i] = how many characters of TYPED_TEXT are visible right after tap i (monotone, last = full length).
// Each tap reveals a chunk of ~3 characters; the key lit/pressed on tap i is the LAST character of its chunk.
export const TAP_CHARS = TYPING_TAPS.map((_, i) => Math.round((i + 1) * TYPED_TEXT.length / TYPING_TAPS.length));
// visible characters at time t (0 before the first tap)
export function typedCount(t) { let n = 0; for (let i = 0; i < TYPING_TAPS.length; i++) if (t >= TYPING_TAPS[i]) n = TAP_CHARS[i]; return n; }
export function typedTextAt(t) { return TYPED_TEXT.slice(0, typedCount(t)); }
// character pressed on tap i
export const tapChar = (i) => TYPED_TEXT[TAP_CHARS[i] - 1];
// keyboard key for a character: {row, col} on S.KB rows (QWERTYUIOP / ASDFGHJKLÑ / ZXCVBNM), accents fold to the base
// letter; space → {row: 3, col: -1} (space bar); punctuation (, .) → null (no key lit)
const ROWS = ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'];
export function keyOfChar(ch) {
  if (ch === ' ') return { row: 3, col: -1, space: true };
  const c = ch.toUpperCase().replace('Á', 'A').replace('É', 'E').replace('Í', 'I').replace('Ó', 'O').replace('Ú', 'U');
  for (let r = 0; r < 3; r++) { const k = ROWS[r].indexOf(c); if (k >= 0) return { row: r, col: k }; }
  return null;
}
