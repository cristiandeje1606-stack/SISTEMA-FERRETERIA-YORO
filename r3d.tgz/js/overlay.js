// 2D overlay graphics: extruded 3D text, stickers, banners, lists, notes, cursor, reactions
import { clamp, pop, easeIn, easeOut, prog, BRAND } from './util.js';

export const FONTS = {
  display: 'UneDisplay', cond: 'UneCond', text: 'UneText', logo: 'UneLogo',
};

export function font(g, fam, size, italic = false) {
  g.font = `${italic ? 'italic ' : ''}${size}px ${fam}`;
}

// entrance/exit transform: returns {s, a, r} for an element living [t0, t1]
export function life(t, t0, t1, { inDur = 0.55, outDur = 0.28, spin = 0.12 } = {}) {
  if (t < t0 || t > t1) return null;
  const pi = prog(t, t0, t0 + inDur);
  let s = pop(pi);
  let r = (1 - easeOut(pi)) * -spin;
  let a = clamp(pi * 4);
  if (t1 - t < outDur) { const po = 1 - (t1 - t) / outDur; s *= 1 - easeIn(po) * 0.9; a *= 1 - easeIn(po); r += easeIn(po) * spin * 0.6; }
  return { s: Math.max(0, s), a: clamp(a), r };
}

function grad(g, x0, y0, x1, y1, stops) {
  const gr = g.createLinearGradient(x0, y0, x1, y1);
  stops.forEach((c, i) => gr.addColorStop(i / (stops.length - 1), c));
  return gr;
}

// Extruded text block. lines: array of strings or arrays of [text, colorStops] segments
export function text3D(g, lines, o) {
  const {
    x, y, size = 80, fam = FONTS.display, italic = false, align = 'center',
    face = ['#ffffff', '#e8f6ff'], side = '#06121F', depth = 12, outline = 0, outlineColor = '#06121F',
    lineH = 1.02, maxW = 940, shadow = true, highlight = true, tracking = 0,
  } = o;
  g.save();
  let fs = size;
  font(g, fam, fs, italic);
  // fit width
  const wOf = (ln) => (Array.isArray(ln) ? ln.reduce((w, sg) => w + g.measureText(sg[0]).width, 0) : g.measureText(ln).width) + tracking * fs * (lineText(ln).length);
  let maxLine = Math.max(...lines.map(wOf));
  if (maxLine > maxW) { fs = fs * maxW / maxLine; font(g, fam, fs, italic); maxLine = Math.max(...lines.map(wOf)); }
  const lh = fs * lineH;
  const totalH = lh * lines.length;
  g.textBaseline = 'middle';
  g.lineJoin = 'round';
  const dep = depth * fs / 80;
  const lineY = (i) => y - totalH / 2 + lh * (i + 0.5);
  const startX = (w) => align === 'center' ? x - w / 2 : align === 'left' ? x : x - w;
  const drawLine = (ln, i, mode) => {
    const segs = Array.isArray(ln) ? ln : [[ln, null]];
    const w = wOf(ln);
    let cx = startX(w);
    const cy = lineY(i);
    for (const [txt, stops] of segs) {
      const tw = g.measureText(txt).width + tracking * fs * txt.length;
      g.textAlign = 'left';
      mode(txt, cx, cy, tw, stops);
      cx += tw;
    }
  };
  const fill = (txt, cx, cy) => {
    if (!tracking) { g.fillText(txt, cx, cy); return; }
    let xx = cx; for (const ch of txt) { g.fillText(ch, xx, cy); xx += g.measureText(ch).width + tracking * fs; }
  };
  const stroke = (txt, cx, cy) => {
    if (!tracking) { g.strokeText(txt, cx, cy); return; }
    let xx = cx; for (const ch of txt) { g.strokeText(ch, xx, cy); xx += g.measureText(ch).width + tracking * fs; }
  };
  // soft drop shadow
  if (shadow) {
    g.save(); g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = fs * 0.35; g.shadowOffsetY = fs * 0.18; g.fillStyle = side;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => fill(txt, cx + dep * 0.5, cy + dep)));
    g.restore();
  }
  // extrusion layers
  g.fillStyle = side;
  if (outline) { g.strokeStyle = side; g.lineWidth = outline * 2; }
  const steps = Math.max(2, Math.round(dep / 1.5));
  for (let k = steps; k >= 1; k--) {
    const ox = dep * 0.45 * k / steps, oy = dep * k / steps;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => { if (outline) stroke(txt, cx + ox, cy + oy); fill(txt, cx + ox, cy + oy); }));
  }
  // outline
  if (outline) {
    g.strokeStyle = outlineColor; g.lineWidth = outline * 2;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => stroke(txt, cx, cy)));
  }
  // face
  lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy, tw, stops) => {
    const st = stops || face;
    g.fillStyle = grad(g, 0, cy - fs * 0.45, 0, cy + fs * 0.45, st);
    fill(txt, cx, cy);
  }));
  // top bevel highlight
  if (highlight) {
    g.save();
    g.globalCompositeOperation = 'source-atop';
    g.restore();
    g.save(); g.globalAlpha = 0.55; g.fillStyle = 'rgba(255,255,255,0.9)';
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => {
      g.save(); g.beginPath(); g.rect(cx - 5, cy - fs * 0.62, 4000, fs * 0.16); g.clip(); fill(txt, cx, cy - fs * 0.02); g.restore();
    }));
    g.restore();
  }
  g.restore();
  return { w: maxLine, h: totalH, fs };
}
function lineText(ln) { return Array.isArray(ln) ? ln.map(s => s[0]).join('') : ln; }

export function measure(g, txt, fam, size, italic) { g.save(); font(g, fam, size, italic); const w = g.measureText(txt).width; g.restore(); return w; }

export function rrect(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }

// 3D slab (sticker / pill) centered at 0,0 in current transform
export function slab(g, w, h, r, { face = [BRAND.ambar, BRAND.naranja], side = '#8a3a10', depth = 16, rim = 'rgba(255,255,255,0.9)', rimW = 0, gloss = true, shadow = true } = {}) {
  if (shadow) {
    g.save(); g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = 40; g.shadowOffsetY = 22; g.fillStyle = side;
    rrect(g, -w / 2 + depth * 0.4, -h / 2 + depth, w, h, r); g.fill(); g.restore();
  }
  g.fillStyle = side;
  const steps = Math.max(3, Math.round(depth / 2));
  for (let k = steps; k >= 1; k--) { rrect(g, -w / 2 + depth * 0.4 * k / steps, -h / 2 + depth * k / steps, w, h, r); g.fill(); }
  g.fillStyle = grad(g, 0, -h / 2, 0, h / 2, face);
  rrect(g, -w / 2, -h / 2, w, h, r); g.fill();
  if (rimW) { g.strokeStyle = rim; g.lineWidth = rimW; rrect(g, -w / 2 + rimW / 2, -h / 2 + rimW / 2, w - rimW, h - rimW, r - rimW / 2); g.stroke(); }
  if (gloss) {
    g.save(); rrect(g, -w / 2, -h / 2, w, h, r); g.clip();
    g.fillStyle = grad(g, 0, -h / 2, 0, -h / 2 + h * 0.5, ['rgba(255,255,255,0.45)', 'rgba(255,255,255,0.0)']);
    rrect(g, -w / 2 + 8, -h / 2 + 6, w - 16, h * 0.42, r * 0.8); g.fill();
    g.restore();
  }
}

// a sticker: slab + 3D text, with bounce transform
export function sticker(g, t, o) {
  const L = life(t, o.t0, o.t1, o.life || {});
  if (!L) return;
  g.save();
  g.translate(o.x, o.y);
  g.rotate((o.rot || 0) * Math.PI / 180 + L.r);
  g.scale(L.s, L.s);
  g.globalAlpha = L.a;
  // idle float
  const fl = Math.sin((t - o.t0) * 2.2) * 4;
  g.translate(0, fl);
  // measure text to size slab
  const size = o.size || 74;
  g.save(); font(g, o.fam || FONTS.display, size, o.italic);
  const tw = Math.max(...o.lines.map(l => g.measureText(Array.isArray(l) ? l.map(s => s[0]).join('') : l).width));
  g.restore();
  const maxTW = (o.maxW || 900) - (o.padX || 56) * 2;
  const k = Math.min(1, maxTW / tw);
  const fs = size * k;
  const w = o.w || Math.min(o.maxW || 900, tw * k + (o.padX || 56) * 2);
  const h = o.h || fs * (o.lineH || 1.05) * o.lines.length + (o.padY || 34) * 2;
  if (!o.noSlab) slab(g, w, h, o.radius ?? Math.min(h / 2, 40), { face: o.face || [BRAND.ambar, BRAND.naranja], side: o.side || '#7a2e0c', depth: o.depth ?? 18, rimW: o.rimW ?? 6, rim: o.rim || 'rgba(255,255,255,0.95)' });
  text3D(g, o.lines, { x: o.tx || 0, y: (o.ty || 0) + fs * 0.04, size: fs, fam: o.fam || FONTS.display, italic: o.italic, face: o.textFace || ['#ffffff', '#fff1d6'], side: o.textSide || '#06121F', depth: o.textDepth ?? 9, lineH: o.lineH || 1.05, maxW: 4000, outline: o.outline ?? 0, highlight: false, shadow: false });
  g.restore();
}

// step banner: number badge + pill with text
export function banner(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.6, spin: 0.08 });
  if (!L) return;
  const { x = 540, y = 380 } = o;
  g.save(); g.translate(x, y); g.rotate((o.rot ?? -2.5) * Math.PI / 180 + L.r); g.scale(L.s, L.s); g.globalAlpha = L.a;
  const size = o.size || 60;
  g.save(); font(g, FONTS.display, size);
  const tw = Math.max(...o.lines.map(l => g.measureText(l).width)); g.restore();
  const badge = o.num ? 118 : 0;
  const maxW = 960;
  const k = Math.min(1, (maxW - badge - 80) / tw);
  const fs = size * k;
  const w = Math.min(maxW, tw * k + 80 + badge);
  const h = fs * 1.08 * o.lines.length + 52;
  const shift = badge / 2;
  g.save(); g.translate(shift * 0.4, 0);
  slab(g, w - badge * 0.4, h, 34, { face: o.face || ['#ffffff', '#dfefff'], side: o.side || '#0B2238', depth: 18, rimW: 0 });
  g.restore();
  text3D(g, o.lines, { x: shift * 0.6 + 4, y: 2, size: fs, face: o.textFace || [BRAND.marino, '#123a63'], side: o.textSide || 'rgba(8,225,255,0.85)', depth: 5, maxW: 4000, shadow: false, highlight: false });
  if (o.num) {
    // number badge (circle coin-like) popping slightly later
    const bp = pop(prog(t, o.t0 + 0.12, o.t0 + 0.7));
    g.save(); g.translate(-w / 2 + 40, 0); g.scale(bp, bp); g.rotate(0.08);
    const R = 74;
    g.save(); g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 30; g.shadowOffsetY = 16;
    g.fillStyle = '#7a2e0c'; for (let k2 = 8; k2 >= 1; k2--) { g.beginPath(); g.arc(k2 * 0.8, k2 * 1.8, R, 0, 7); g.fill(); }
    g.restore();
    g.fillStyle = grad(g, 0, -R, 0, R, [BRAND.ambar, BRAND.naranja, BRAND.brasa]); g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill();
    g.strokeStyle = '#ffffff'; g.lineWidth = 7; g.beginPath(); g.arc(0, 0, R - 6, 0, 7); g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.ellipse(0, -R * 0.45, R * 0.65, R * 0.3, 0, 0, 7); g.fill();
    text3D(g, [String(o.num)], { x: 0, y: 4, size: 92, face: ['#ffffff', '#fff3d6'], side: '#7a2e0c', depth: 8, shadow: false, highlight: false });
    g.restore();
  }
  g.restore();
}

// list: condensed bold italic white with dark outline, line by line
export function list(g, t, o) {
  const { x, y, lines, t0, t1, step = 0.45, size = 72, align = 'left', lineH = 1.12, maxW = 900 } = o;
  if (t < t0 || t > t1) return;
  lines.forEach((ln, i) => {
    const ti = t0 + i * step;
    const L = life(t, ti, t1 - (lines.length - 1 - i) * 0.05, { inDur: 0.45, spin: 0 });
    if (!L) return;
    const pi = easeOut(prog(t, ti, ti + 0.35));
    g.save();
    g.globalAlpha = L.a;
    const yy = y + i * size * lineH;
    g.translate(x + (1 - pi) * -90, yy);
    g.scale(L.s, L.s);
    g.transform(1, 0, -0.0, 1, 0, 0);
    text3D(g, [ln], { x: 0, y: 0, size, fam: FONTS.cond, italic: true, align, face: ['#ffffff', '#e6f4ff'], side: '#06121F', depth: 7, outline: size * 0.075, outlineColor: '#06121F', maxW, shadow: true, highlight: false });
    g.restore();
  });
}

// small yellow note
export function note(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.5, spin: 0.1 });
  if (!L) return;
  g.save(); g.translate(o.x, o.y); g.rotate((o.rot ?? -3) * Math.PI / 180 + L.r); g.scale(L.s, L.s); g.globalAlpha = L.a;
  const size = o.size || 44;
  const fam = o.fam || FONTS.cond;
  g.save(); font(g, fam, size, true); const tw = Math.max(...o.lines.map(l => g.measureText(l).width)); g.restore();
  const k = Math.min(1, ((o.maxW || 900) - 60) / tw);
  const fs = size * k;
  const w = tw * k + 60, h = fs * 1.15 * o.lines.length + 30;
  slab(g, w, h, 18, { face: ['#ffe066', BRAND.ambar], side: '#9a5a00', depth: 9, rimW: 0 });
  text3D(g, o.lines, { x: 0, y: 2, size: fs, fam, italic: true, face: [BRAND.noche, '#16304d'], side: 'rgba(255,255,255,0.5)', depth: 2, maxW: 4000, shadow: false, highlight: false, lineH: 1.15 });
  g.restore();
}

// white glove hand cursor (tip at 0,0)
export function cursor(g, x, y, s = 1, press = 0, alpha = 1) {
  g.save(); g.translate(x, y); g.scale(s * (1 - press * 0.12), s * (1 - press * 0.12)); g.rotate(-0.35); g.globalAlpha = alpha;
  const path = new Path2D('M0,0 C-8,0 -14,6 -14,14 L-14,80 C-24,70 -40,66 -48,76 C-54,84 -50,94 -44,100 L-6,150 C4,164 18,172 38,172 L74,172 C100,172 116,152 116,128 L116,82 C116,72 108,64 98,64 C92,64 86,67 84,72 C82,62 74,56 66,56 C58,56 52,60 50,66 C48,56 40,50 32,50 C24,50 18,54 14,58 L14,14 C14,6 8,0 0,0 Z');
  g.save(); g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 24; g.shadowOffsetY = 12; g.fillStyle = '#c9d6e6'; g.translate(5, 8); g.fill(path); g.restore();
  g.fillStyle = grad(g, -40, 0, 110, 170, ['#ffffff', '#e9f1fb', '#cfdcec']); g.fill(path);
  g.strokeStyle = '#06121F'; g.lineWidth = 7; g.lineJoin = 'round'; g.stroke(path);
  g.strokeStyle = 'rgba(6,18,31,0.5)'; g.lineWidth = 4;
  for (const xx of [50, 84]) { g.beginPath(); g.moveTo(xx, 74); g.lineTo(xx, 100); g.stroke(); }
  g.beginPath(); g.moveTo(14, 66); g.lineTo(14, 100); g.stroke();
  g.restore();
}

export function ripple(g, x, y, t, color = BRAND.cian) {
  if (t < 0 || t > 0.6) return;
  const k = t / 0.6;
  g.save();
  for (let i = 0; i < 2; i++) {
    const kk = clamp(k - i * 0.18);
    if (kk <= 0) continue;
    g.globalAlpha = (1 - kk) * 0.9; g.strokeStyle = i ? '#ffffff' : color; g.lineWidth = 10 * (1 - kk) + 2;
    g.beginPath(); g.arc(x, y, 20 + kk * 120, 0, 7); g.stroke();
  }
  // spark lines
  g.globalAlpha = 1 - k; g.strokeStyle = BRAND.ambar; g.lineWidth = 8; g.lineCap = 'round';
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2; const r0 = 40 + k * 70, r1 = r0 + 30 * (1 - k);
    g.beginPath(); g.moveTo(x + Math.cos(a) * r0, y + Math.sin(a) * r0); g.lineTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1); g.stroke();
  }
  g.restore();
}

// reactions (generic icons, no brand logos)
export function reaction(g, kind, x, y, s, a) {
  g.save(); g.translate(x, y); g.scale(s, s); g.globalAlpha = a;
  const R = 54;
  const cols = { heart: [BRAND.brasa, '#c42a3a'], like: [BRAND.azul, '#2c63b0'], comment: [BRAND.cian, '#0798b3'], star: [BRAND.ambar, '#c77a00'] }[kind];
  g.save(); g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = 20; g.shadowOffsetY = 10;
  g.fillStyle = cols[1]; g.beginPath(); g.arc(3, 7, R, 0, 7); g.fill(); g.restore();
  g.fillStyle = grad(g, 0, -R, 0, R, [cols[0], cols[1]]); g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill();
  g.strokeStyle = '#ffffff'; g.lineWidth = 5; g.beginPath(); g.arc(0, 0, R - 3, 0, 7); g.stroke();
  g.fillStyle = '#ffffff';
  if (kind === 'heart') {
    g.beginPath(); g.moveTo(0, 26); g.bezierCurveTo(-44, -2, -30, -38, 0, -18); g.bezierCurveTo(30, -38, 44, -2, 0, 26); g.fill();
  } else if (kind === 'like') {
    g.beginPath(); g.roundRect(-30, -6, 14, 36, 4); g.fill();
    g.beginPath(); g.moveTo(-12, -6); g.lineTo(-2, -30); g.quadraticCurveTo(6, -40, 10, -28); g.lineTo(6, -10); g.lineTo(26, -10); g.quadraticCurveTo(36, -8, 32, 4); g.lineTo(26, 26); g.quadraticCurveTo(22, 32, 14, 32); g.lineTo(-12, 32); g.closePath(); g.fill();
  } else if (kind === 'comment') {
    g.beginPath(); g.roundRect(-30, -24, 60, 42, 14); g.fill();
    g.beginPath(); g.moveTo(-14, 14); g.lineTo(-20, 32); g.lineTo(2, 16); g.fill();
    g.fillStyle = cols[1]; for (const xx of [-14, 0, 14]) { g.beginPath(); g.arc(xx, -3, 5, 0, 7); g.fill(); }
  } else {
    g.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 14 : 32; const an = -Math.PI / 2 + i * Math.PI / 5; g.lineTo(Math.cos(an) * r, Math.sin(an) * r); } g.closePath(); g.fill();
  }
  g.restore();
}

// fixed brand mark (top center): the client's real PROAUDIH logo (never redrawn or recoloured)
export function topMark(g, logo, alpha = 1) {
  if (alpha <= 0.001) return;
  g.save(); g.globalAlpha = alpha;
  const cx = 540;
  const hg = g.createRadialGradient(cx, 120, 10, cx, 120, 300);
  hg.addColorStop(0, 'rgba(6,18,31,0.5)'); hg.addColorStop(1, 'rgba(6,18,31,0)');
  g.fillStyle = hg; g.fillRect(cx - 340, 0, 680, 260);
  const H = 150, W = H * 929 / 959, y0 = 20;
  if (logo) {
    g.save(); g.shadowColor = 'rgba(0,0,0,0.55)'; g.shadowBlur = 16; g.shadowOffsetY = 5;
    g.imageSmoothingQuality = 'high'; g.drawImage(logo, cx - W / 2, y0, W, H); g.restore();
  }
  // small product line under the logo
  font(g, FONTS.cond, 30);
  g.textBaseline = 'middle'; g.textAlign = 'left';
  const label = 'ESTUDIO DE NOTICIAS';
  const tr = 6; let w = 0; for (const ch of label) w += g.measureText(ch).width + tr; w -= tr;
  let xx = cx - w / 2; const ly = y0 + H + 22;
  g.fillStyle = '#3DE0FF';
  g.save(); g.shadowColor = 'rgba(0,0,0,0.7)'; g.shadowBlur = 8;
  for (const ch of label) { g.fillText(ch, xx, ly); xx += g.measureText(ch).width + tr; }
  g.restore();
  g.fillStyle = 'rgba(59,113,251,0.9)'; g.fillRect(cx - w / 2 - 62, ly - 1, 46, 3); g.fillRect(cx + w / 2 + 16, ly - 1, 46, 3);
  g.restore();
}
