// 2D overlay graphics (WP4): sticker titles, step banners, bullet lists, notes, tap cursor,
// transitions (navy wipe + amber edge), proof dim, close cards, top brand mark, and the full
// 2D scene timeline `timeline(g, t, env)` that main.js calls once per frame.
import { clamp, pop, easeIn, easeOut, easeInOut, easeOutBack, easeOutExpo, prog, lerp, env as envW, BRAND } from './util.js';

export const FONTS = {
  display: 'UneDisplay', cond: 'UneCond', text: 'UneText', bold: 'UneTextB', logo: 'UneLogo',
};
const WEIGHT = { UneDisplay: 800, UneCond: 800, UneText: 600, UneTextB: 700, UneLogo: 900 };
const NAVY = '#0B2238', INK = '#06121F', AMBER = '#FDAE03', ORANGE = '#F6901C';

// music grid (music.py): first hit 0.6 s, 25 bars to 56.0 s → beat 0.554 s (108.3 BPM)
export const BEAT = (56.0 - 0.6) / 100;
export const onBeat = (t) => 0.6 + Math.ceil((t - 0.6) / BEAT - 1e-6) * BEAT;

export function font(g, fam, size, italic = false) {
  g.font = `${italic ? 'italic ' : ''}${WEIGHT[fam] || 400} ${size}px ${fam}`;
}

// hex colour shade: k>0 mixes toward white, k<0 toward black (non-hex strings pass through)
export function shade(c, k) {
  if (typeof c !== 'string' || c[0] !== '#' || c.length !== 7) return c;
  const n = parseInt(c.slice(1), 16); let r = (n >> 16) & 255, gg = (n >> 8) & 255, b = n & 255;
  const f = (v) => Math.round(k >= 0 ? v + (255 - v) * k : v * (1 + k));
  r = f(r); gg = f(gg); b = f(b);
  return '#' + ((1 << 24) | (r << 16) | (gg << 8) | b).toString(16).slice(1);
}

// entrance/exit transform: returns {s, a, r} for an element living [t0, t1]
export function life(t, t0, t1, { inDur = 0.45, outDur = 0.22, spin = 0.12 } = {}) {
  if (t < t0 || t > t1) return null;
  const pi = prog(t, t0, t0 + inDur);
  // anticipation dip then easeOutBack(1.4) overshoot, settled by a damped spring
  let s = pi < 1 ? easeOutBack(pi, 1.4) : 1;
  s += Math.exp(-(t - t0 - inDur) * 9) * Math.sin(Math.max(0, t - t0 - inDur) * 18) * 0.03 * (pi >= 1 ? 1 : 0);
  let r = (1 - easeOut(pi)) * -spin;
  let a = clamp(pi * 4);
  if (t1 - t < outDur) { const po = 1 - (t1 - t) / outDur; s *= 1 - easeIn(po) * 0.9; a *= 1 - easeIn(po); r += easeIn(po) * spin * 0.6; }
  return { s: Math.max(0, s), a: clamp(a), r };
}

function grad(g, x0, y0, x1, y1, stops) {
  const gr = g.createLinearGradient(x0, y0, x1, y1);
  stops.forEach((c, i) => gr.addColorStop(i / Math.max(1, stops.length - 1), c));
  return gr;
}
// two-tone bevel face: +12 % light on top
const bevelStops = (st) => [shade(st[0], 0.12), ...st];

// Extruded text block. lines: array of strings or arrays of [text, colorStops] segments
export function text3D(g, lines, o) {
  const {
    x, y, size = 80, fam = FONTS.display, italic = false, align = 'center',
    face = ['#ffffff', '#e8f6ff'], side = INK, depth = 12, outline = 0, outlineColor = INK,
    lineH = 1.02, maxW = 940, shadow = true, highlight = true, tracking = 0,
  } = o;
  g.save();
  let fs = size;
  font(g, fam, fs, italic);
  const wOf = (ln) => (Array.isArray(ln) ? ln.reduce((w, sg) => w + g.measureText(sg[0]).width, 0) : g.measureText(ln).width) + tracking * fs * (lineText(ln).length);
  let maxLine = Math.max(...lines.map(wOf));
  if (maxLine > maxW) { fs = fs * maxW / maxLine; font(g, fam, fs, italic); maxLine = Math.max(...lines.map(wOf)); }
  const lh = fs * lineH;
  const totalH = lh * lines.length;
  g.textBaseline = 'middle';
  g.lineJoin = 'round';
  const dep = depth * fs / 80;
  const lineY = (i) => y - totalH / 2 + lh * (i + 0.5);
  const startX = (w) => align === 'center' ? x - w / 2 : align === 'left' ? x : x - w;
  const drawLine = (ln, i, mode) => {
    const segs = Array.isArray(ln) ? ln : [[ln, null]];
    let cx = startX(wOf(ln));
    const cy = lineY(i);
    for (const [txt, stops] of segs) {
      const tw = g.measureText(txt).width + tracking * fs * txt.length;
      g.textAlign = 'left';
      mode(txt, cx, cy, tw, stops);
      cx += tw;
    }
  };
  const fill = (txt, cx, cy) => {
    if (!tracking) { g.fillText(txt, cx, cy); return; }
    let xx = cx; for (const ch of txt) { g.fillText(ch, xx, cy); xx += g.measureText(ch).width + tracking * fs; }
  };
  const stroke = (txt, cx, cy) => {
    if (!tracking) { g.strokeText(txt, cx, cy); return; }
    let xx = cx; for (const ch of txt) { g.strokeText(ch, xx, cy); xx += g.measureText(ch).width + tracking * fs; }
  };
  if (shadow) {
    g.save(); g.shadowColor = 'rgba(6,18,31,0.55)'; g.shadowBlur = 24; g.shadowOffsetY = 10; g.fillStyle = side;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => fill(txt, cx + dep * 0.3, cy + dep + 4)));
    g.restore();
  }
  g.fillStyle = side;
  if (outline) { g.strokeStyle = side; g.lineWidth = outline * 2; }
  const steps = Math.max(2, Math.round(dep / 1.5));
  for (let k = steps; k >= 1; k--) {
    const ox = dep * 0.3 * k / steps, oy = dep * k / steps;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => { if (outline) stroke(txt, cx + ox, cy + oy); fill(txt, cx + ox, cy + oy); }));
  }
  if (outline) {
    g.strokeStyle = outlineColor; g.lineWidth = outline * 2;
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => stroke(txt, cx, cy)));
  }
  lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy, tw, stops) => {
    const st = bevelStops(stops || face);
    g.fillStyle = grad(g, 0, cy - fs * 0.42, 0, cy + fs * 0.42, st);
    fill(txt, cx, cy);
  }));
  if (highlight) {
    g.save(); g.globalAlpha = 0.45; g.fillStyle = 'rgba(255,255,255,0.9)';
    lines.forEach((ln, i) => drawLine(ln, i, (txt, cx, cy) => {
      g.save(); g.beginPath(); g.rect(cx - 5, cy - fs * 0.62, 4000, fs * 0.16); g.clip(); fill(txt, cx, cy - fs * 0.02); g.restore();
    }));
    g.restore();
  }
  g.restore();
  return { w: maxLine, h: totalH, fs };
}
function lineText(ln) { return Array.isArray(ln) ? ln.map(s => s[0]).join('') : ln; }

export function measure(g, txt, fam, size, italic) { g.save(); font(g, fam, size, italic); const w = g.measureText(txt).width; g.restore(); return w; }

export function rrect(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, Math.max(0, Math.min(r, h / 2, w / 2))); }

// 3D slab (sticker / pill) centered at 0,0: soft shadow 24 px + hard shadow 8 px #06121F,
// extrusion, 6 px bevel ring (light top / dark bottom) and a two-tone face (+12 % light on top)
export function slab(g, w, h, r, { face = [BRAND.ambar, BRAND.naranja], side = '#8a3a10', depth = 12, rim = 'rgba(255,255,255,0.95)', rimW = 0, gloss = true, shadow = true, bevel = 6 } = {}) {
  const x0 = -w / 2, y0 = -h / 2;
  if (shadow) {
    g.save(); g.shadowColor = 'rgba(6,18,31,0.6)'; g.shadowBlur = 24; g.shadowOffsetY = 12; g.fillStyle = INK;
    rrect(g, x0, y0 + depth + 8, w, h, r); g.fill(); g.restore();
    g.fillStyle = INK; rrect(g, x0 + depth * 0.3, y0 + depth + 8, w, h, r); g.fill();
  }
  g.fillStyle = side;
  const steps = Math.max(3, Math.round(depth / 2));
  for (let k = steps; k >= 1; k--) { rrect(g, x0 + depth * 0.3 * k / steps, y0 + depth * k / steps, w, h, r); g.fill(); }
  const last = face[face.length - 1];
  g.fillStyle = grad(g, 0, y0, 0, y0 + h, [shade(face[0], 0.45), shade(last, -0.28)]);
  rrect(g, x0, y0, w, h, r); g.fill();
  g.fillStyle = grad(g, 0, y0 + bevel, 0, y0 + h - bevel, bevelStops(face));
  rrect(g, x0 + bevel, y0 + bevel, w - bevel * 2, h - bevel * 2, r - bevel); g.fill();
  if (rimW) { g.strokeStyle = rim; g.lineWidth = rimW; rrect(g, x0 + rimW / 2, y0 + rimW / 2, w - rimW, h - rimW, r - rimW / 2); g.stroke(); }
  if (gloss) {
    g.save(); rrect(g, x0 + bevel, y0 + bevel, w - bevel * 2, h - bevel * 2, r - bevel); g.clip();
    g.fillStyle = grad(g, 0, y0, 0, y0 + h * 0.5, ['rgba(255,255,255,0.32)', 'rgba(255,255,255,0.0)']);
    rrect(g, x0 + 10, y0 + 8, w - 20, h * 0.42, r * 0.8); g.fill();
    g.restore();
  }
}

// a sticker: slab + 3D text, with bounce transform
export function sticker(g, t, o) {
  const L = life(t, o.t0, o.t1, o.life || {});
  if (!L) return;
  g.save();
  g.translate(o.x, o.y);
  g.rotate((o.rot || 0) * Math.PI / 180 + L.r);
  g.scale(L.s, L.s);
  g.globalAlpha = L.a;
  const fl = o.still ? 0 : Math.sin((t - o.t0) * 2.2) * 3;
  g.translate(0, fl);
  const size = o.size || 74;
  const fam = o.fam || FONTS.display;
  g.save(); font(g, fam, size, o.italic);
  const tw = Math.max(...o.lines.map(l => g.measureText(Array.isArray(l) ? l.map(s => s[0]).join('') : l).width));
  g.restore();
  const padX = o.padX ?? 40, padY = o.padY ?? 30;
  const maxTW = (o.maxW || 900) - padX * 2;
  const k = Math.min(1, maxTW / tw);
  const fs = size * k;
  const w = o.w || Math.min(o.maxW || 900, tw * k + padX * 2);
  const h = o.h || fs * (o.lineH || 1.05) * o.lines.length + padY * 2;
  if (!o.noSlab) slab(g, w, h, o.radius ?? Math.min(h / 2, 36), { face: o.face || [BRAND.ambar, BRAND.naranja], side: o.side || '#7a2e0c', depth: o.depth ?? 12, rimW: o.rimW ?? 0, rim: o.rim || 'rgba(255,255,255,0.95)' });
  text3D(g, o.lines, { x: o.tx || 0, y: (o.ty || 0) + fs * 0.04, size: fs, fam, italic: o.italic, face: o.textFace || ['#ffffff', '#eaf4ff'], side: o.textSide || INK, depth: o.textDepth ?? 8, lineH: o.lineH || 1.05, maxW: 4000, outline: o.outline ?? 0, highlight: false, shadow: false });
  g.restore();
  return { w, h, fs };
}

// step banner: cyan number badge + white pill with navy text
export function banner(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.5, spin: 0.08 });
  if (!L) return;
  const { x = 540, y = 380 } = o;
  g.save(); g.translate(x, y); g.rotate((o.rot ?? -2.5) * Math.PI / 180 + L.r); g.scale(L.s, L.s); g.globalAlpha = L.a;
  const size = Math.max(64, o.size || 64);
  g.save(); font(g, FONTS.display, size);
  const tw = Math.max(...o.lines.map(l => g.measureText(l).width)); g.restore();
  const badge = o.num ? 118 : 0;
  const maxW = o.maxW || 960;
  const k = Math.min(1, (maxW - badge - 72) / tw);
  const fs = size * k;
  const w = Math.min(maxW, tw * k + 72 + badge);
  const h = fs * 1.06 * o.lines.length + 48;
  const shift = badge / 2;
  g.save(); g.translate(shift * 0.4, 0);
  slab(g, w - badge * 0.4, h, 32, { face: o.face || ['#ffffff', '#dfefff'], side: o.side || '#7f98b5', depth: 12 });
  g.restore();
  text3D(g, o.lines, { x: shift * 0.6 + 4, y: 2, size: fs, face: o.textFace || [NAVY, '#123a63'], side: o.textSide || 'rgba(8,225,255,0.85)', depth: 5, maxW: 4000, shadow: false, highlight: false, lineH: 1.06 });
  if (o.num) {
    const bp = pop(prog(t, o.t0 + 0.1, o.t0 + 0.65));
    g.save(); g.translate(-w / 2 + 40, 0); g.scale(bp, bp); g.rotate(0.08);
    const R = 72;
    g.save(); g.shadowColor = 'rgba(6,18,31,0.6)'; g.shadowBlur = 24; g.shadowOffsetY = 12;
    g.fillStyle = INK; g.beginPath(); g.arc(3, 20, R, 0, 7); g.fill(); g.restore();
    g.fillStyle = '#05506a'; for (let k2 = 6; k2 >= 1; k2--) { g.beginPath(); g.arc(k2 * 0.5, k2 * 2, R, 0, 7); g.fill(); }
    g.fillStyle = grad(g, 0, -R, 0, R, ['#c4f8ff', '#3DE0FF', BRAND.cian, '#0789a8']); g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill();
    g.fillStyle = grad(g, 0, -R, 0, R, [shade(BRAND.cian, 0.3), '#0aa9c9']); g.beginPath(); g.arc(0, 0, R - 6, 0, 7); g.fill();
    g.strokeStyle = '#ffffff'; g.lineWidth = 6; g.beginPath(); g.arc(0, 0, R - 3, 0, 7); g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.3)'; g.beginPath(); g.ellipse(0, -R * 0.45, R * 0.6, R * 0.28, 0, 0, 7); g.fill();
    text3D(g, [String(o.num)], { x: 0, y: 4, size: 88, face: ['#ffffff', '#e8fbff'], side: NAVY, depth: 8, shadow: false, highlight: false });
    g.restore();
  }
  g.restore();
}

// Bullet list: Figtree 700 (UneTextB) 40 px white, shadow 0 4 12 rgba(6,18,31,.6), line-height 1.25.
// Items enter one by one on the music beat (every `beats` beats, default 2); at most 2 lines on
// screen: when a 3rd item enters, the oldest slides up and out.
export function list(g, t, o) {
  const { x, y, t0, t1, align = 'left', maxW = 900, beats = 2, plate = true } = o;
  const size = o.fontSize || 40;
  if (t < t0 || t > t1) return;
  const lines = o.lines.map(s => s.replace(/^[–-]\s*/, ''));
  const e0 = onBeat(t0), step = BEAT * beats;
  const E = lines.map((_, i) => e0 + i * step);
  let shift = 0; for (let j = 2; j < E.length; j++) shift += easeInOut(prog(t, E[j], E[j] + 0.3));
  const lh = size * 1.25, ind = size * 0.75;
  lines.forEach((ln, i) => {
    if (t < E[i]) return;
    const slot = i - shift;
    if (slot <= -0.98) return;
    const pi = prog(t, E[i], E[i] + 0.35);
    let a = clamp((t - E[i]) / 0.15) * clamp(1 + slot) * (1 - prog(t, t1 - 0.22, t1));
    if (a <= 0) return;
    g.save();
    g.globalAlpha = a;
    font(g, FONTS.bold, size);
    let tw = g.measureText(ln).width; let fs = size;
    if (tw > maxW - ind) { fs = size * Math.max(0.85, (maxW - ind) / tw); font(g, FONTS.bold, fs); tw = g.measureText(ln).width; }
    const W = ind + tw;
    const x0 = (align === 'left' ? x : align === 'right' ? x - W : x - W / 2) + (1 - easeOutBack(pi, 1.4)) * (align === 'right' ? 60 : -60);
    const yy = y + slot * lh * 1.12;
    if (plate) {
      g.save(); g.globalAlpha = a * 0.55; g.fillStyle = INK; rrect(g, x0 - 18, yy - lh * 0.5, W + 40, lh, lh * 0.5); g.fill(); g.restore();
    }
    // bullet: cyan diamond chip
    g.save(); g.translate(x0 + size * 0.22, yy); g.rotate(Math.PI / 4); g.fillStyle = BRAND.cian;
    const bs = size * 0.26 * (0.6 + 0.4 * easeOutBack(pi, 2)); g.fillRect(-bs / 2, -bs / 2, bs, bs); g.restore();
    g.shadowColor = 'rgba(6,18,31,0.6)'; g.shadowBlur = 12; g.shadowOffsetY = 4;
    g.fillStyle = '#ffffff'; g.textBaseline = 'middle'; g.textAlign = 'left';
    g.fillText(ln, x0 + ind, yy + 1);
    g.restore();
  });
}

// small yellow note
export function note(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.45, spin: 0.1 });
  if (!L) return;
  g.save(); g.translate(o.x, o.y); g.rotate((o.rot ?? -3) * Math.PI / 180 + L.r); g.scale(L.s, L.s); g.globalAlpha = L.a;
  const size = o.size || 44;
  const fam = o.fam || FONTS.bold;
  g.save(); font(g, fam, size); const tw = Math.max(...o.lines.map(l => g.measureText(l).width)); g.restore();
  const k = Math.min(1, ((o.maxW || 900) - 64) / tw);
  const fs = size * k;
  const w = tw * k + 64, h = fs * 1.2 * o.lines.length + 34;
  slab(g, w, h, 18, { face: ['#ffe680', '#FFC93A'], side: '#9a5a00', depth: 8 });
  text3D(g, o.lines, { x: 0, y: 2, size: fs, fam, face: [NAVY, '#16304d'], side: 'rgba(255,255,255,0.5)', depth: 0, maxW: 4000, shadow: false, highlight: false, lineH: 1.2 });
  g.restore();
}

// hand cursor (tip at 0,0). gold=true → the golden hand of the coin (default white glove)
const HAND = typeof Path2D !== 'undefined' ? new Path2D('M0,0 C-8,0 -14,6 -14,14 L-14,80 C-24,70 -40,66 -48,76 C-54,84 -50,94 -44,100 L-6,150 C4,164 18,172 38,172 L74,172 C100,172 116,152 116,128 L116,82 C116,72 108,64 98,64 C92,64 86,67 84,72 C82,62 74,56 66,56 C58,56 52,60 50,66 C48,56 40,50 32,50 C24,50 18,54 14,58 L14,14 C14,6 8,0 0,0 Z') : null;
export function cursor(g, x, y, s = 1, press = 0, alpha = 1, gold = false) {
  if (alpha <= 0.001) return;
  g.save(); g.translate(x, y); g.scale(s * (1 - press * 0.12), s * (1 - press * 0.12)); g.rotate(-0.35); g.globalAlpha = alpha;
  g.save(); g.shadowColor = 'rgba(6,18,31,0.55)'; g.shadowBlur = 24; g.shadowOffsetY = 12; g.fillStyle = gold ? '#a35f00' : '#c9d6e6'; g.translate(5, 8); g.fill(HAND); g.restore();
  g.fillStyle = gold ? grad(g, -40, 0, 110, 170, ['#fff6c4', '#ffc93a', '#f0a400', '#d88a00']) : grad(g, -40, 0, 110, 170, ['#ffffff', '#e9f1fb', '#cfdcec']);
  g.fill(HAND);
  if (gold) { // metallic sheen
    g.save(); g.clip(HAND); g.globalAlpha = alpha * 0.55; g.fillStyle = grad(g, -20, 20, 60, 120, ['rgba(255,255,255,0)', 'rgba(255,255,255,0.9)', 'rgba(255,255,255,0)']);
    g.fillRect(-60, -10, 200, 200); g.restore();
  }
  g.strokeStyle = gold ? '#7a4300' : INK; g.lineWidth = 7; g.lineJoin = 'round'; g.stroke(HAND);
  g.strokeStyle = gold ? 'rgba(122,67,0,0.6)' : 'rgba(6,18,31,0.5)'; g.lineWidth = 4;
  for (const xx of [50, 84]) { g.beginPath(); g.moveTo(xx, 74); g.lineTo(xx, 100); g.stroke(); }
  g.beginPath(); g.moveTo(14, 66); g.lineTo(14, 100); g.stroke();
  g.restore();
}

// TAP feedback (for WP2): golden hand-cursor with the fingertip at (x, y) + expanding cyan ring.
// p = 0..1 progress (≈0.45 s): 0–0.27 approach with anticipation, 0.27 contact (squash), ring to 1.
export function drawTap(g, x, y, p, opt = {}) {
  if (!(p >= 0 && p <= 1)) return;
  const { scale = 1, color = BRAND.cian, cursor: showCursor = true, alpha = 1 } = opt;
  const PC = 0.27;
  g.save();
  if (p >= PC) {
    const k = (p - PC) / (1 - PC);
    for (let i = 0; i < 2; i++) {
      const kk = clamp((k - i * 0.16) / (1 - i * 0.16)); if (kk <= 0) continue;
      g.globalAlpha = alpha * (1 - kk) * 0.95; g.strokeStyle = i ? '#ffffff' : color; g.lineWidth = (9 * (1 - kk) + 2) * scale;
      g.beginPath(); g.arc(x, y, (12 + easeOut(kk) * 74) * scale, 0, 7); g.stroke();
    }
    g.globalAlpha = alpha * (1 - k); g.fillStyle = 'rgba(255,255,255,0.85)';
    g.beginPath(); g.arc(x, y, 18 * scale * (1 - k * 0.6), 0, 7); g.fill();
    g.strokeStyle = color; g.lineCap = 'round'; g.lineWidth = 5 * scale;
    for (let i = 0; i < 6; i++) {
      const an = i / 6 * Math.PI * 2 + 0.3, r0 = (30 + k * 60) * scale, r1 = r0 + 20 * scale * (1 - k);
      g.beginPath(); g.moveTo(x + Math.cos(an) * r0, y + Math.sin(an) * r0); g.lineTo(x + Math.cos(an) * r1, y + Math.sin(an) * r1); g.stroke();
    }
  }
  g.restore();
  if (showCursor) {
    const ap = p < PC ? p / PC : 1;
    const d = 1 - easeOut(ap) + (p < PC ? Math.sin(ap * Math.PI) * 0.12 : 0);   // anticipation overshoot back
    const press = p >= PC ? Math.sin(clamp((p - PC) / 0.25) * Math.PI) : 0;
    const a = alpha * clamp(p / 0.1) * (1 - prog(p, 0.78, 1));
    cursor(g, x + d * 46 * scale, y + d * 64 * scale, 0.6 * scale, press, a, true);
  }
}
export function tapAt(g, t, tTap, x, y, opt) { drawTap(g, x, y, (t - tTap + 0.12) / 0.45, opt); }

export function ripple(g, x, y, t, color = BRAND.cian) {
  if (t < 0 || t > 0.6) return;
  const k = t / 0.6;
  g.save();
  for (let i = 0; i < 2; i++) {
    const kk = clamp(k - i * 0.18);
    if (kk <= 0) continue;
    g.globalAlpha = (1 - kk) * 0.9; g.strokeStyle = i ? '#ffffff' : color; g.lineWidth = 10 * (1 - kk) + 2;
    g.beginPath(); g.arc(x, y, 20 + kk * 120, 0, 7); g.stroke();
  }
  g.globalAlpha = 1 - k; g.strokeStyle = BRAND.ambar; g.lineWidth = 8; g.lineCap = 'round';
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2; const r0 = 40 + k * 70, r1 = r0 + 30 * (1 - k);
    g.beginPath(); g.moveTo(x + Math.cos(a) * r0, y + Math.sin(a) * r0); g.lineTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1); g.stroke();
  }
  g.restore();
}

// reactions (generic icons, no brand logos)
export function reaction(g, kind, x, y, s, a) {
  g.save(); g.translate(x, y); g.scale(s, s); g.globalAlpha = a;
  const R = 54;
  const cols = { heart: [BRAND.brasa, '#c42a3a'], like: [BRAND.azul, '#2c63b0'], comment: [BRAND.cian, '#0798b3'], star: [BRAND.ambar, '#c77a00'] }[kind];
  g.save(); g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = 20; g.shadowOffsetY = 10;
  g.fillStyle = cols[1]; g.beginPath(); g.arc(3, 7, R, 0, 7); g.fill(); g.restore();
  g.fillStyle = grad(g, 0, -R, 0, R, [cols[0], cols[1]]); g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill();
  g.strokeStyle = '#ffffff'; g.lineWidth = 5; g.beginPath(); g.arc(0, 0, R - 3, 0, 7); g.stroke();
  g.fillStyle = '#ffffff';
  if (kind === 'heart') {
    g.beginPath(); g.moveTo(0, 26); g.bezierCurveTo(-44, -2, -30, -38, 0, -18); g.bezierCurveTo(30, -38, 44, -2, 0, 26); g.fill();
  } else if (kind === 'like') {
    g.beginPath(); g.roundRect(-30, -6, 14, 36, 4); g.fill();
    g.beginPath(); g.moveTo(-12, -6); g.lineTo(-2, -30); g.quadraticCurveTo(6, -40, 10, -28); g.lineTo(6, -10); g.lineTo(26, -10); g.quadraticCurveTo(36, -8, 32, 4); g.lineTo(26, 26); g.quadraticCurveTo(22, 32, 14, 32); g.lineTo(-12, 32); g.closePath(); g.fill();
  } else if (kind === 'comment') {
    g.beginPath(); g.roundRect(-30, -24, 60, 42, 14); g.fill();
    g.beginPath(); g.moveTo(-14, 14); g.lineTo(-20, 32); g.lineTo(2, 16); g.fill();
    g.fillStyle = cols[1]; for (const xx of [-14, 0, 14]) { g.beginPath(); g.arc(xx, -3, 5, 0, 7); g.fill(); }
  } else {
    g.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 14 : 32; const an = -Math.PI / 2 + i * Math.PI / 5; g.lineTo(Math.cos(an) * r, Math.sin(an) * r); } g.closePath(); g.fill();
  }
  g.restore();
}

// Top brand mark: the client's real PROAUDIH logo (never redrawn or recoloured) + product line.
// opt = {cx, y0, h} (TV). The block is clamped so it always sits fully inside the safe area
// (TV x 96–1824, y ≥ 54; vertical x 60–1020, y ≥ 48).
export function markLayout(TV) {
  return TV ? { cx: 1586, y0: 58, h: 108, fs: 24, tr: 5 } : { cx: 540, y0: 52, h: 140, fs: 28, tr: 6 };
}
export function topMark(g, logo, alpha = 1, opt = null) {
  if (alpha <= 0.001) return;
  const TV = !!opt;
  const L = { ...markLayout(TV), ...(opt || {}) };
  const H = L.h, W = H * 929 / 959;
  g.save(); g.globalAlpha = alpha;
  font(g, FONTS.cond, L.fs ?? (TV ? 24 : 28));
  const label = 'ESTUDIO DE NOTICIAS', tr = L.tr ?? 5;
  let lw = 0; for (const ch of label) lw += g.measureText(ch).width + tr; lw -= tr;
  const ext = Math.max(W / 2, lw / 2 + 58);
  const [xmin, xmax, ymin] = TV ? [96, 1824, 54] : [60, 1020, 48];
  const cx = clamp(L.cx, xmin + ext, xmax - ext);
  const y0 = Math.max(ymin, L.y0);
  const ly = y0 + H + (TV ? 16 : 20);
  const hy = y0 + H * 0.6;
  const hg = g.createRadialGradient(cx, hy, 10, cx, hy, 280);
  hg.addColorStop(0, 'rgba(6,18,31,0.5)'); hg.addColorStop(1, 'rgba(6,18,31,0)');
  g.fillStyle = hg; g.fillRect(cx - 320, 0, 640, ly + 120);
  if (logo) {
    g.save(); g.shadowColor = 'rgba(0,0,0,0.55)'; g.shadowBlur = 16; g.shadowOffsetY = 5;
    g.imageSmoothingQuality = 'high'; g.drawImage(logo, cx - W / 2, y0, W, H); g.restore();
  }
  g.textBaseline = 'middle'; g.textAlign = 'left';
  let xx = cx - lw / 2;
  g.fillStyle = '#3DE0FF';
  g.save(); g.shadowColor = 'rgba(0,0,0,0.7)'; g.shadowBlur = 8;
  for (const ch of label) { g.fillText(ch, xx, ly); xx += g.measureText(ch).width + tr; }
  g.restore();
  g.fillStyle = 'rgba(59,113,251,0.9)'; g.fillRect(cx - lw / 2 - 56, ly - 1, 42, 3); g.fillRect(cx + lw / 2 + 14, ly - 1, 42, 3);
  g.restore();
  return { cx, y0, bottom: ly + 14, left: cx - ext, right: cx + ext };
}

// ---------------------------------------------------------------- transitions / dim
// Navy #0B2238 wipe with an amber #FDAE03 light edge, centred on the cut time tc. The panel
// sweeps in (covers the screen for ~1 frame at tc) and opens over the next scene.
export function transitionWipe(g, t, tc, env, dur = 0.6) {
  const k = (t - (tc - dur / 2)) / dur;
  if (k <= 0 || k >= 1) return;
  const DW = env.DW, DH = env.DH, sk = DH * 0.28, pad = 160;
  let L, R, edge;
  if (k < 0.5) { const e = easeIn(k / 0.5); L = -sk - pad; R = lerp(-pad, DW + sk + pad, e); edge = R; }
  else { const e = easeOutExpo((k - 0.5) / 0.5); L = lerp(-pad, DW + sk + pad, e); R = DW + sk + pad * 2; edge = L; }
  const quad = (a, b) => { g.beginPath(); g.moveTo(a, 0); g.lineTo(b, 0); g.lineTo(b - sk, DH); g.lineTo(a - sk, DH); g.closePath(); };
  g.save();
  // trailing light-navy streak for motion
  g.globalAlpha = 0.5; g.fillStyle = '#163a5c';
  if (k < 0.5) quad(R - 40, R + 90); else quad(L - 120, L + 10);
  g.globalAlpha = 1;
  g.fillStyle = grad(g, 0, 0, DW, DH, ['#0e2a45', NAVY, '#081a2c']); quad(L, R); g.fill();
  // subtle diagonal pinstripes inside the panel
  g.save(); quad(L, R); g.clip(); g.strokeStyle = 'rgba(61,224,255,0.06)'; g.lineWidth = 2;
  for (let xx = -sk; xx < DW + sk; xx += 46) { g.beginPath(); g.moveTo(xx, 0); g.lineTo(xx - sk, DH); g.stroke(); }
  g.restore();
  // amber light edge on the moving side
  g.save();
  g.shadowColor = AMBER; g.shadowBlur = 40;
  g.strokeStyle = AMBER; g.lineWidth = 14; g.beginPath(); g.moveTo(edge, -20); g.lineTo(edge - sk * (1 + 20 / DH), DH + 20); g.stroke();
  g.shadowBlur = 0; g.strokeStyle = '#fff3c4'; g.lineWidth = 4; g.beginPath(); g.moveTo(edge, -20); g.lineTo(edge - sk * (1 + 20 / DH), DH + 20); g.stroke();
  g.restore();
  g.restore();
}

// Dim everything except rect {x,y,w,h} (a = 0..1), with a soft cyan rim around the hole
export function dimAround(g, rect, a, env) {
  if (a <= 0.001 || !rect) return;
  const p = 14, r = 26;
  g.save();
  g.beginPath(); g.rect(0, 0, env.DW, env.DH);
  g.roundRect(rect.x - p, rect.y - p, rect.w + p * 2, rect.h + p * 2, r);
  g.fillStyle = `rgba(6,18,31,${0.66 * a})`; g.fill('evenodd');
  g.globalAlpha = a * 0.7; g.strokeStyle = BRAND.cian; g.lineWidth = 4; g.shadowColor = BRAND.cian; g.shadowBlur = 24;
  g.beginPath(); g.roundRect(rect.x - p, rect.y - p, rect.w + p * 2, rect.h + p * 2, r); g.stroke();
  g.restore();
}

// ESPACIO PATROCINADO ribbon (big, complete) — amber band with navy condensed text
function ribbon(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.5, spin: 0.05 });
  if (!L) return;
  g.save(); g.translate(o.x, o.y); g.rotate((o.rot || 0) * Math.PI / 180 + L.r);
  const reveal = easeOut(prog(t, o.t0, o.t0 + 0.45));
  g.globalAlpha = L.a;
  const w = o.w, h = o.h;
  g.beginPath(); g.rect(-w / 2 - 60, -h, (w + 120) * reveal, h * 3); g.clip();
  // folded tails
  g.fillStyle = '#9a5a00';
  for (const s of [-1, 1]) { g.beginPath(); g.moveTo(s * w / 2, -h / 2 + 14); g.lineTo(s * (w / 2 + 46), -h / 2 + 14); g.lineTo(s * (w / 2 + 26), 14); g.lineTo(s * (w / 2 + 46), h / 2 + 14); g.lineTo(s * w / 2, h / 2 + 14); g.closePath(); g.fill(); }
  slab(g, w, h, 10, { face: ['#FFD25A', AMBER], side: '#9a5a00', depth: 10 });
  // marquee sparkle sweep
  const sw = ((t - o.t0) * 0.6) % 1.4 - 0.2;
  g.save(); rrect(g, -w / 2, -h / 2, w, h, 10); g.clip();
  g.fillStyle = grad(g, -w / 2 + sw * w - 80, 0, -w / 2 + sw * w + 80, 0, ['rgba(255,255,255,0)', 'rgba(255,255,255,0.55)', 'rgba(255,255,255,0)']);
  g.fillRect(-w / 2, -h / 2, w, h); g.restore();
  text3D(g, [o.text], { x: 0, y: 3, size: o.size, fam: FONTS.cond, italic: true, face: [NAVY, '#123a63'], side: 'rgba(255,255,255,0.55)', depth: 4, maxW: w - 60, shadow: false, highlight: false });
  g.restore();
}

// generic speech-bubble phone icon (not a brand logo) for the contact line
function chatIcon(g, x, y, r) {
  g.save(); g.translate(x, y);
  g.fillStyle = '#25C26A'; g.beginPath(); g.arc(0, 0, r, 0, 7); g.fill();
  g.beginPath(); g.moveTo(-r * 0.7, r * 0.55); g.lineTo(-r * 0.95, r * 1.0); g.lineTo(-r * 0.25, r * 0.85); g.fill();
  g.strokeStyle = '#ffffff'; g.lineWidth = r * 0.12; g.beginPath(); g.arc(0, 0, r * 0.82, 0, 7); g.stroke();
  // handset
  g.fillStyle = '#ffffff'; g.rotate(-0.6);
  g.beginPath(); g.roundRect(-r * 0.16, -r * 0.48, r * 0.32, r * 0.96, r * 0.14); g.fill();
  g.beginPath(); g.roundRect(-r * 0.32, -r * 0.5, r * 0.4, r * 0.24, r * 0.1); g.fill();
  g.beginPath(); g.roundRect(-r * 0.32, r * 0.26, r * 0.4, r * 0.24, r * 0.1); g.fill();
  g.restore();
}
function contactLine(g, t, o) {
  const L = life(t, o.t0, o.t1, { inDur: 0.45, spin: 0.04 });
  if (!L) return;
  g.save(); g.translate(o.x, o.y); g.rotate(L.r); g.scale(L.s * (o.k || 1), L.s * (o.k || 1)); g.globalAlpha = L.a;
  font(g, FONTS.bold, o.size); let tw = g.measureText(o.text).width;
  const icon = o.size * 1.25, pad = 30;
  let fs = o.size; const avail = o.maxW - icon - pad * 2 - 16;
  if (tw > avail) { fs = o.size * avail / tw; font(g, FONTS.bold, fs); tw = g.measureText(o.text).width; }
  const w = icon + 16 + tw + pad * 2, h = fs * 1.2 + 34;
  slab(g, w, h, h / 2, { face: ['#ffffff', '#e6eef8'], side: '#7f98b5', depth: 8 });
  chatIcon(g, -w / 2 + pad + icon / 2 - 6, 0, icon / 2);
  g.fillStyle = NAVY; g.textBaseline = 'middle'; g.textAlign = 'left';
  g.fillText(o.text, -w / 2 + pad + icon + 10, 2);
  g.restore();
}

// ---------------------------------------------------------------- scene timeline (all 2D graphics)
// cut times covered by the navy/amber wipe (vertical, TV)
export const WIPES = { v: [7.35, 31.0, 37.0, 44.0, 50.0, 56.0], tv: [7.6, 31.0, 37.0, 44.0, 50.0, 56.0] };
// default rect of the finished post during the proof moment (matches main.js postCard placement)
export function proofRectDefault(TV) {
  return TV ? { x: 1060 - 304, y: 575 - 380, w: 608, h: 760 } : { x: 540 - 320, y: 905 - 400, w: 640, h: 800 };
}
const RED = ['#ff4a66', BRAND.rojo], BLUE = ['#7aa6ff', '#3B71FB'], CYANF = ['#7ff0ff', '#1fb8e0'], AMB = ['#FFD25A', AMBER], FIRE = [AMBER, ORANGE];
const WHITE = ['#ffffff', '#e4f2ff'];

export function timeline(g, t, env) {
  const TV = env.TV ?? (env.DW > env.DH);
  const E = { DW: env.DW ?? (TV ? 1920 : 1080), DH: env.DH ?? (TV ? 1080 : 1920) };
  const LT = (v, tv) => TV ? tv : v;
  const cuts = env.wipes || env.cuts || (TV ? WIPES.tv : WIPES.v);
  // draw queue: items still alive after the active cut (t1 > cut + 0.3) are drawn ON TOP of the wipe → never an empty frame
  const Q = [];
  const D = (fn, o) => Q.push([o.t1, () => fn(g, t, o)]);
  const S = (o) => D(sticker, o);

  // ---- proof moment dim (under the graphics of that moment)
  const dimA = smoothstep(prog(t, 21.75, 22.05)) * (1 - smoothstep(prog(t, 24.3, 24.55)));
  if (dimA > 0) dimAround(g, env.proofRect || proofRectDefault(TV), dimA, E);

  // ---- S1 hook
  S({ t0: 0.55, t1: 4.45, x: LT(540, 1330), y: LT(360, 340), rot: -4, lines: ['¿LA NOTICIA ESTÁ', 'PASANDO AHORA?'], size: 84, face: RED, side: '#5a0718', maxW: LT(980, 900) });
  // golden cursor travels in and taps the coin at 2.65
  const coin = { x: LT(760, 1400), y: LT(1330, 640) };
  if (t > 2.1 && t < 2.53) {
    const k = easeInOut(prog(t, 2.1, 2.53));
    cursor(g, lerp(LT(1150, 1760), coin.x + 46, k), lerp(LT(1700, 980), coin.y + 64, k), 0.6, 0, clamp((t - 2.1) / 0.1), true);
  }
  tapAt(g, t, 2.65, coin.x, coin.y, { scale: 1.3 });
  S({ t0: 2.85, t1: 4.45, x: LT(540, 1360), y: LT(1450, 830), rot: 4, lines: [[['PUBLÍCALA EN ', null], ['1 MINUTO', RED]]], size: LT(72, 64), face: WHITE, side: '#7f98b5', textFace: [NAVY, '#163d66'], textSide: 'rgba(8,225,255,0.9)', textDepth: 6, maxW: LT(980, 860) });

  // ---- S2..S5 step banners (cyan badges)
  const BY = LT(410, 322), BX = LT(540, 1330), BW = LT(980, 880);
  D(banner, { t0: 4.55, t1: 10.9, num: 1, lines: ['TOMA LA FOTO O', 'GRABA EL VIDEO'], x: BX, y: BY, maxW: BW });
  D(banner, { t0: 10.95, t1: 18.2, num: 2, lines: ['ESCRIBE', 'LO QUE PASÓ'], x: BX, y: BY, maxW: BW, rot: 2 });
  D(banner, { t0: 17.95, t1: LT(21.85, 21.2), num: 3, lines: ['EL SISTEMA ARMA', 'LA NOTICIA SOLO'], x: BX, y: BY, maxW: BW });
  D(banner, { t0: 25.0, t1: 26.75, num: 4, lines: ['SOLO DALE', 'SUBIR'], x: BX, y: BY, maxW: BW, rot: 2 });
  D(note, { t0: 13.0, t1: 17.9, x: LT(540, 1330), y: LT(600, 560), rot: -3, lines: ['Tal como te llegó la información'], size: 44, maxW: LT(900, 760) });
  // proof: bullets beside / under the finished post
  D(list, { t0: 21.6, t1: 24.45, x: LT(150, 1410), y: LT(1390, 470), lines: ['Titular', 'Texto para Facebook', 'Diseño con tu marca'], maxW: LT(800, 410) });
  S({ t0: 26.85, t1: 30.85, x: LT(540, 1330), y: LT(480, 330), rot: -5, lines: ['¡PUBLICADO!'], size: 110, face: CYANF, side: '#0B4a6a', maxW: LT(940, 880) });


  // ---- S6 styles
  S({ t0: 30.85, t1: 36.75, x: LT(540, 1250), y: LT(400, 272), rot: -3, lines: ['ELIGE EL ESTILO'], size: LT(84, 66), padY: LT(30, 26), face: BLUE, side: NAVY, maxW: LT(980, 900) });
  const labels = [['CLÁSICO', LT(270, 880), -6, [BRAND.azul, '#2c63b0']], ['CRISTAL 3D', LT(540, 1220), 3, CYANF], ['IMPACTO 4D', LT(810, 1560), -4, [BRAND.rojo, '#a80f2c']]];
  labels.forEach(([txt, x, r, face], i) => {
    const f = envW(t, [33.2, 34.3, 35.4][i], [33.2, 34.3, 35.4][i] + 1.2, 0.3, 0.3);
    S({ t0: onBeat(32.3) + i * BEAT, t1: 36.75, x, y: LT(1110, 925) + f * 6, rot: r, lines: [txt], fam: FONTS.cond, italic: true, size: 56 * (1 + f * 0.12), face, side: INK, maxW: 260, padX: 22, padY: 12, depth: 10 });
  });

  // ---- S7 video
  S({ t0: 36.85, t1: 43.75, x: LT(540, 1560), y: LT(380, 330), rot: -3, lines: TV ? ['VIDEO', 'NOTICIA'] : ['VIDEO NOTICIA CON', 'CORTINA Y SONIDO'], size: LT(72, 80), padX: LT(40, 34), face: RED, side: '#4a0612', maxW: LT(980, 520) });
  D(list, { t0: 38.6, t1: 43.75, x: LT(80, 1310), y: LT(1430, 530), lines: ['Varias fotos en un video', 'Cortinas de noticiero', 'Efectos de sonido'], maxW: LT(560, 510) });

  // ---- S8 advertising: section title, then the big headline + ribbon
  S({ t0: 43.85, t1: 45.1, x: LT(540, 1452), y: LT(400, 320), rot: 3, lines: TV ? ['VENDE', 'PUBLICIDAD'] : ['VENDE PUBLICIDAD'], size: LT(84, 72), face: AMB, side: '#8a5a00', textFace: [NAVY, '#163d66'], textSide: 'rgba(255,255,255,0.6)', textDepth: 5, maxW: LT(980, 740) });
  S({ t0: 45.0, t1: 49.75, x: LT(540, 1452), y: LT(420, 345), rot: -2, lines: ['TU NOTICIA', 'YA TRAE', [['PATROCINADOR', AMB]]], size: LT(84, 64), padX: LT(44, 30), face: ['#163d66', NAVY], side: INK, textFace: ['#ffffff', '#e8f6ff'], textSide: INK, maxW: LT(980, 744) });
  D(list, { t0: 45.6, t1: 49.75, x: LT(150, 1290), y: LT(1360, 610), lines: ['Cintas de patrocinadores', 'Videos sueltos unidos', 'Tus anunciantes en cada nota'], maxW: LT(800, 530) });
  D(ribbon, { t0: 45.3, t1: 49.75, x: LT(540, 1150), y: LT(1250, 935), rot: -2, w: LT(940, 900), h: LT(104, 92), size: LT(74, 64), text: 'ESPACIO PATROCINADO' });

  // ---- S9 call to action (owner decision 27-oct: NO prices) — orange = CTA, benefits without numbers
  S({ t0: 49.85, t1: 55.75, x: LT(540, 1300), y: LT(400, 322), rot: -3, lines: ['PIDE TU', 'DEMOSTRACIÓN'], size: LT(96, 72), face: FIRE, side: '#7a2e0c', maxW: LT(980, 900) });
  const perks = [
    [['CON TU LOGO', 'Y TUS COLORES'], BLUE, NAVY, LT(700, 535), LT(0, -40)],
    [['PARA TV Y RADIO'], ['#1d4f86', NAVY], INK, LT(910, 715), LT(0, 40)],
    [['SIN', 'COMPLICACIONES'], WHITE, '#7f98b5', LT(1120, 885), LT(0, -40)],
  ];
  perks.forEach(([lines, face, side, y, dx], i) => {
    const white = face === WHITE;
    S({ t0: onBeat(50.3) + i * BEAT * 2, t1: 55.75, x: LT(540, 1300) + dx, y, rot: [2, -2, 2][i], lines, size: LT(70, 64), padY: LT(28, 26), face, side, maxW: LT(940, 840), textFace: white ? [NAVY, '#163d66'] : undefined, textSide: white ? 'rgba(8,225,255,0.9)' : INK, textDepth: white ? 5 : undefined });
  });

  // ---- S10 close (orange = call to action only)
  S({ t0: 55.85, t1: 58.55, x: LT(540, 1350), y: LT(350, 330), rot: -3, lines: [[['EN MENOS DE', null]], [['24 HORAS', [AMBER, '#e08a00']]]], size: LT(76, 68), face: WHITE, side: '#7f98b5', textFace: [NAVY, '#163d66'], textSide: 'rgba(8,225,255,0.9)', textDepth: 5, maxW: LT(980, 840) });
  S({ t0: onBeat(56.2), t1: 58.55, x: LT(540, 1350), y: LT(575, 548), rot: 2, lines: ['TIENES TU SISTEMA', 'DISEÑADO'], size: LT(66, 64), face: BLUE, side: NAVY, maxW: LT(980, 840) });
  // proaudih.com + CTA + WhatsApp; pulse on the 60.5 s hit
  const pulse = 1 + Math.exp(-Math.max(0, t - 60.5) * 7) * Math.sin(Math.max(0, t - 60.5) * 22) * 0.06 * (t > 60.5 ? 1 : 0);
  const close = (o, k = pulse) => Q.push([o.t1, () => { g.save(); g.translate(o.x, o.y); g.scale(k, k); g.translate(-o.x, -o.y); sticker(g, t, o); g.restore(); }]);
  close({ t0: 58.5, t1: 62.6, x: LT(540, 1400), y: LT(720, 612), rot: -3, still: true, lines: [[['proaudih', ['#ffffff', '#e8f0ff']], ['.com', ['#3DE0FF', '#7fb0ff']]]], fam: FONTS.logo, size: LT(104, 100), face: ['#13284f', '#0A0F1E'], side: '#020a12', rim: '#3B71FB', rimW: 6, maxW: LT(920, 780), textSide: '#020a12' });
  close({ t0: 59.0, t1: 62.6, x: LT(540, 1400), y: LT(880, 772), rot: 0, still: true, lines: ['Escríbenos y pide', 'tu demostración'], fam: FONTS.bold, size: LT(62, 56), face: FIRE, side: '#7a2e0c', textFace: ['#ffffff', '#fff3e0'], textSide: '#7a2e0c', textDepth: 4, maxW: LT(900, 760), padY: 22 }, 1 + (pulse - 1) * 0.6);
  D(contactLine, { t0: 59.4, t1: 62.6, x: LT(540, 1400), y: LT(1030, 925), text: '+504 9741-7560 · +504 9350-3349', size: LT(44, 40), maxW: LT(980, 820) });

  // ---- flush: old scene → navy/amber wipe → new scene's stickers on top
  const tc = cuts.find(c => Math.abs(t - c) < 0.31);
  if (tc === undefined) for (const [, f] of Q) f();
  else {
    for (const [t1, f] of Q) if (t1 <= tc + 0.3) f();
    transitionWipe(g, t, tc, E);
    for (const [t1, f] of Q) if (t1 > tc + 0.3) f();
  }

  // ---- top brand mark (fixed; fades as the 3D logo plate enters at 58.5 s)
  topMark(g, env.logo, 1 - smoothstep(prog(t, 58.2, 58.5)), TV ? {} : null);
}
const smoothstep = (x) => x * x * (3 - 2 * x);
