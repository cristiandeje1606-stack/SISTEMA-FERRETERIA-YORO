// node shot.js <url> <outfile> [W H]  -> saves window.out dataURL (photo page)
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); }
const fs = require('fs');
(async () => {
  const [url, out, W = 1600, H = 1200] = process.argv.slice(2);
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const p = await b.newPage({ viewport: { width: +W, height: +H } });
  p.on('console', m => console.log('[page]', m.text())); p.on('pageerror', e => console.log('[err]', e.message));
  await p.goto(url); await p.waitForFunction(() => window.ready, null, { timeout: 60000 });
  await p.evaluate(() => window.ready);
  const d = await p.evaluate(() => window.out);
  fs.writeFileSync(out, Buffer.from(d.split(',')[1], 'base64'));
  await b.close(); console.log('saved', out);
})();
