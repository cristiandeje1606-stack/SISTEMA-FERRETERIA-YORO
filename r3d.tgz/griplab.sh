#!/bin/bash
# griplab.sh out.jpg 'grip-json' 'hand-json'
SP=$1; G=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$2"); H=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$3")
B='{"rotY":2.9,"aimW":1,"phX":-0.12,"phY":0.84,"phZ":0.24,"handR":"grip","handL":"relax","mic":0,"aimYaw":3.69,"aimPitch":-0.55,"headX":0.15}'
P=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "[$B]"); V=$(python3 -c "import urllib.parse;print(urllib.parse.quote('[\"phone:0.45\",\"phone:-0.45\",\"phone:0:0.45\",\"phone:0:-0.45\"]'))")
cd /home/claude/r3d && node shot.js "http://localhost:8765/lab.html?poses=$P&views=$V&fov=35&grip=$G&hand=$H" $1 | grep DBG | head -1
