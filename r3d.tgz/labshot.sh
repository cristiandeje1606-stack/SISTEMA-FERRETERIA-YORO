#!/bin/bash
# usage: labshot.sh out.jpg 'poses-json' 'views-json' [extra query]
P=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$2")
V=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$3")
cd /home/claude/r3d && node shot.js "http://localhost:8765/lab.html?poses=$P&views=$V$4" "$1" 2>&1 | grep -v "^\[page\] Failed" | tail -3
