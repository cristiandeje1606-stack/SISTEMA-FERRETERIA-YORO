// node render.js W H start end out.mp4 [fps=30] [scale=1]
// Renders index.html frame by frame (deterministic window.render(t)) and pipes JPEG frames to ffmpeg (libx264).
// Requires: python3 -m http.server 8765 serving /home/claude/r3d  (auto-started if not running)
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); }
const { spawn, execSync } = require('child_process');
const http = require('http');
const path = require('path');

const [Wa = 1080, Ha = 1920, sA = 0, eA = 62, out = 'out.mp4', fpsA = 30, scaleA = 1] = process.argv.slice(2);
const W = +Wa, H = +Ha, start = +sA, end = +eA, fps = +fpsA, scale = +scaleA;
const PORT = 8765;

function ping() { return new Promise(r => { http.get(`http://localhost:${PORT}/index.html`, res => { res.resume(); r(res.statusCode === 200); }).on('error', () => r(false)); }); }

(async () => {
  if (!(await ping())) {
    const srv = spawn('python3', ['-m', 'http.server', String(PORT)], { cwd: __dirname, stdio: 'ignore', detached: true }); srv.unref();
    for (let i = 0; i < 50 && !(await ping()); i++) await new Promise(r => setTimeout(r, 200));
  }
  // page renders at W*scale x H*scale; ffmpeg outputs W x H
  const RW = Math.round(W * scale), RH = Math.round(H * scale);
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-gpu-vsync'] });
  const page = await browser.newPage({ viewport: { width: RW, height: RH }, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('[pageerror]', e.message));
  await page.goto(`http://localhost:${PORT}/index.html?w=${RW}&h=${RH}`);
  await page.waitForFunction(() => window.ready, null, { timeout: 180000 });
  await page.evaluate(() => window.ready);
  const missing = await page.evaluate(() => window.missingAssets());
  if (missing.length) console.log('placeholders used for:', missing.join(', '));

  const vf = (RW !== W || RH !== H) ? ['-vf', `scale=${W}:${H}:flags=lanczos`] : [];
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
    ...vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-pix_fmt', 'yuv420p', '-r', String(fps), '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise(r => ff.on('close', r));

  const n0 = Math.round(start * fps), n1 = Math.round(end * fps);
  const T0 = Date.now(); let tr = 0, ts = 0;
  for (let n = n0; n < n1; n++) {
    const t = n / fps;
    const a = Date.now();
    await page.evaluate((t) => window.render(t), t);
    const b = Date.now();
    const buf = await page.screenshot({ type: 'jpeg', quality: 92 });
    const c = Date.now(); tr += b - a; ts += c - b;
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    const k = n - n0 + 1;
    if (k % 30 === 0 || n === n1 - 1) {
      const el = (Date.now() - T0) / 1000, per = el / k;
      process.stdout.write(`frame ${k}/${n1 - n0}  t=${t.toFixed(2)}  ${(per * 1000).toFixed(0)} ms/frame (render ${(tr / k).toFixed(0)} + shot ${(ts / k).toFixed(0)})  ETA ${((n1 - n - 1) * per / 60).toFixed(1)} min\n`);
    }
  }
  ff.stdin.end(); await done; await browser.close();
  console.log('wrote', path.resolve(out));
})();
