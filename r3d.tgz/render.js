// node render.js W H start end out.mp4 [fps=30] [scale=1] [flags...]
// Renders index.html frame by frame (deterministic window.render(t)) and pipes JPEG frames to ffmpeg (libx264).
// Requires: python3 -m http.server 8765 serving /home/claude/r3d  (auto-started if not running)
//
// Flags (after the positional args, or as env vars):
//   --ss[=k]      supersampling: page renders at k× (default 1.5) and ffmpeg downscales with lanczos  (env SS=k).
//                 Same as passing scale=k positionally; the larger of the two wins.
//   --mb=N        motion blur sub-frames on FAST moments only (default 3; --mb=0 or --no-mb disables)   (env MB=N).
//   --shutter=s   shutter as a fraction of the frame (default 0.5 = 180°)                                (env SHUTTER).
//   --q=<qs>      extra query string for index.html (e.g. --q=tm=aces&vig=0)                             (env Q).
// Motion blur: sub-frames span [t - shutter/fps, t] and are averaged in the page (3D+background layer and the 2D
// overlay layer separately, premultiplied alpha, so the vignette stays between them). Any sub-frame that falls on
// the other side of a camera cut / street↔studio switch is dropped, so cuts never ghost. Fully deterministic.
// FAST moments: window.FAST_MOMENTS ([[t0,t1],...]) if the page defines it, else the built-in list below
// (jumps, beat push-ins easeOutExpo 0.6 s, transition wipes, single taps).
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { try { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); } catch (e2) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); } }
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

const argv = process.argv.slice(2);
const pos = argv.filter(a => !a.startsWith('--'));
const flag = (n) => { const a = argv.find(x => x === `--${n}` || x.startsWith(`--${n}=`)); return a === undefined ? undefined : (a.includes('=') ? a.slice(a.indexOf('=') + 1) : ''); };
const [Wa = 1080, Ha = 1920, sA = 0, eA = 62, out = 'out.mp4', fpsA = 30, scaleA = 1] = pos;
const W = +Wa, H = +Ha, start = +sA, end = +eA, fps = +fpsA;
const ssF = flag('ss') ?? process.env.SS;
const scale = Math.max(+scaleA || 1, ssF === undefined ? 1 : (+ssF || 1.5));
const MB = flag('no-mb') !== undefined ? 0 : Math.max(0, Math.round(+(flag('mb') ?? process.env.MB ?? 3)));
const SHUTTER = +(flag('shutter') ?? process.env.SHUTTER ?? 0.5);
const EXTRA_Q = flag('q') ?? process.env.Q ?? '';
const PORT = 8765;

// built-in fast moments (seconds) — taken from main.js / overlay.js timings
const BEATS = [1.3, 2.85, 4.55, 7.6, 11.0, 18.0, 20.2, 25.0, 27.0, 31.0, 37.0, 44.0, 50.0, 56.0, 60.5];
const WIPES = [7.35, 7.6, 31.0, 37.0, 44.0, 50.0, 56.0];
const TAPS = [2.65, 6.8, 19.4, 25.95];
const FAST_DEFAULT = [                                // kept short: each blurred frame costs ~N× a plain frame
  [0.95, 1.55], [28.3, 29.8],                         // jumps (hop + squash)
  ...BEATS.map(b => [b, b + 0.35]),                   // push-ins (fastest part of the 0.6 s easeOutExpo)
  ...WIPES.map(c => [c - 0.25, c + 0.25]),            // navy/amber wipes
  ...TAPS.map(tp => [tp - 0.12, tp + 0.18]),          // cursor taps (descent + contact)
];

function ping() { return new Promise(r => { http.get(`http://localhost:${PORT}/index.html`, res => { res.resume(); r(res.statusCode === 200); }).on('error', () => r(false)); }); }

// in-page: render N sub-frames ending at t, average them into the bg / fx canvases (gl hidden). Returns used count.
async function pageMotionBlur(page, t, span, N) {
  return page.evaluate(async ({ t, span, N }) => {
    const bg = document.getElementById('bg'), gl = document.getElementById('gl'), fx = document.getElementById('fx');
    const W = bg.width, H = bg.height;
    let S = window.__mbS;
    if (!S || S.W !== W || S.H !== H) {
      const lo = document.createElement('canvas'); lo.width = W; lo.height = H;
      S = window.__mbS = { W, H, lo, lx: lo.getContext('2d', { willReadFrequently: true }), fxx: fx.getContext('2d', { willReadFrequently: true }) };
    }
    const G = window.__gl || {};
    const st = () => { const c = G.camera, sc = G.scene; const studio = sc && sc.getObjectByName('studio');
      return c ? { p: c.position.clone(), q: c.quaternion.clone(), s: studio ? studio.visible : null } : null; };
    const shots = [];
    for (let i = 0; i < N; i++) {
      const ti = t - span * (N - 1 - i) / (N - 1);
      window.render(Math.max(0, ti));
      S.lx.globalCompositeOperation = 'copy'; S.lx.filter = 'none'; S.lx.drawImage(bg, 0, 0);
      S.lx.globalCompositeOperation = 'source-over'; S.lx.filter = gl.style.filter || getComputedStyle(gl).filter || 'none'; S.lx.drawImage(gl, 0, 0); S.lx.filter = 'none';
      shots.push({ st: st(), lo: S.lx.getImageData(0, 0, W, H).data, fx: S.fxx.getImageData(0, 0, W, H).data });
    }
    // keep only sub-frames in the same shot as the final one
    const ref = shots[N - 1].st;
    const use = shots.filter(s => !ref || !s.st || (s.st.s === ref.s && s.st.p.distanceTo(ref.p) < 0.35 && s.st.q.angleTo(ref.q) < 0.2));
    const n = use.length;
    if (n > 1) {
      const len = W * H * 4;
      const lo = new Uint8ClampedArray(len), fo = new Uint8ClampedArray(len);
      const accL = new Uint16Array(len), accF = new Float32Array(len);
      for (const s of use) {
        const a = s.lo, f = s.fx;
        for (let k = 0; k < len; k++) accL[k] += a[k];
        for (let k = 0; k < len; k += 4) { const al = f[k + 3]; if (!al) continue; accF[k] += f[k] * al; accF[k + 1] += f[k + 1] * al; accF[k + 2] += f[k + 2] * al; accF[k + 3] += al; }
      }
      for (let k = 0; k < len; k++) lo[k] = (accL[k] + (n >> 1)) / n;
      for (let k = 0; k < len; k += 4) { const A = accF[k + 3]; if (!A) continue; fo[k] = accF[k] / A + 0.5; fo[k + 1] = accF[k + 1] / A + 0.5; fo[k + 2] = accF[k + 2] / A + 0.5; fo[k + 3] = A / n + 0.5; }
      const bx = bg.getContext('2d'); bx.save(); bx.setTransform(1, 0, 0, 1, 0, 0); bx.putImageData(new ImageData(lo, W, H), 0, 0); bx.restore();
      S.fxx.save(); S.fxx.setTransform(1, 0, 0, 1, 0, 0); S.fxx.putImageData(new ImageData(fo, W, H), 0, 0); S.fxx.restore();
      gl.style.visibility = 'hidden';
    }
    return n;
  }, { t, span, N });
}

(async () => {
  if (!(await ping())) {
    const srv = spawn('python3', ['-m', 'http.server', String(PORT)], { cwd: __dirname, stdio: 'ignore', detached: true }); srv.unref();
    for (let i = 0; i < 50 && !(await ping()); i++) await new Promise(r => setTimeout(r, 200));
  }
  // page renders at W*scale x H*scale; ffmpeg outputs W x H
  const RW = Math.round(W * scale), RH = Math.round(H * scale);
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-gpu-vsync'] });
  const page = await browser.newPage({ viewport: { width: RW, height: RH }, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('[pageerror]', e.message));
  await page.goto(`http://localhost:${PORT}/index.html?w=${RW}&h=${RH}${EXTRA_Q ? '&' + EXTRA_Q : ''}`);
  await page.waitForFunction(() => window.ready, null, { timeout: 180000 });
  await page.evaluate(() => window.ready);
  const missing = await page.evaluate(() => window.missingAssets ? window.missingAssets() : []);
  if (missing.length) console.log('placeholders used for:', missing.join(', '));
  const FAST = (await page.evaluate(() => Array.isArray(window.FAST_MOMENTS) ? window.FAST_MOMENTS : null)) || FAST_DEFAULT;
  const isFast = (t) => FAST.some(([a, b]) => t >= a && t < b);
  console.log(`render ${W}x${H} @${fps} fps · page ${RW}x${RH}${scale !== 1 ? ` (supersample ${scale}× → lanczos)` : ''} · motion blur ${MB > 1 ? `${MB} sub-frames, shutter ${SHUTTER}` : 'off'}`);

  const vf = (RW !== W || RH !== H) ? ['-vf', `scale=${W}:${H}:flags=lanczos`] : [];
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
    ...vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-pix_fmt', 'yuv420p', '-r', String(fps), '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise(r => ff.on('close', r));

  const n0 = Math.round(start * fps), n1 = Math.round(end * fps);
  const T0 = Date.now(); let tr = 0, ts = 0, nmb = 0;
  for (let n = n0; n < n1; n++) {
    const t = n / fps;
    const a = Date.now();
    let blurred = false;
    if (MB > 1 && isFast(t)) { const used = await pageMotionBlur(page, t, SHUTTER / fps, MB); blurred = used > 1; if (blurred) nmb++; }
    else await page.evaluate((t) => window.render(t), t);
    const b = Date.now();
    const buf = await page.screenshot({ type: 'jpeg', quality: 92 });
    if (blurred) await page.evaluate(() => { document.getElementById('gl').style.visibility = ''; });
    const c = Date.now(); tr += b - a; ts += c - b;
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    const k = n - n0 + 1;
    if (k % 30 === 0 || n === n1 - 1) {
      const el = (Date.now() - T0) / 1000, per = el / k;
      process.stdout.write(`frame ${k}/${n1 - n0}  t=${t.toFixed(2)}  ${(per * 1000).toFixed(0)} ms/frame (render ${(tr / k).toFixed(0)} + shot ${(ts / k).toFixed(0)})  blurred ${nmb}  ETA ${((n1 - n - 1) * per / 60).toFixed(1)} min\n`);
    }
  }
  ff.stdin.end(); await done; await browser.close();
  console.log('wrote', path.resolve(out));
})();
