// node qa.js outdir t1,t2,...  -> full-res frames f_<t>.jpg
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); }
(async () => {
  const [dir, times] = process.argv.slice(2);
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const QW = +(process.env.QW || 1080), QH = +(process.env.QH || 1920);
  const p = await b.newPage({ viewport: { width: QW, height: QH } });
  p.on('pageerror', e => console.log('[err]', e.message));
  await p.goto(`http://localhost:8765/index.html?w=${QW}&h=${QH}`);
  await p.waitForFunction(() => window.ready, null, { timeout: 120000 }); await p.evaluate(() => window.ready);
  for (const t of times.split(',').map(Number)) { await p.evaluate(t => window.render(t), t); await p.screenshot({ path: `${dir}/f_${t}.jpg`, type: 'jpeg', quality: 90 }); }
  await b.close();
})();
