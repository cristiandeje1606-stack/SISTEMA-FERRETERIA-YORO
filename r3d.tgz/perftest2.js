let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/usr/local/lib/node_modules/playwright')); }
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  await p.goto(`http://localhost:8765/index.html?w=1080&h=1920${process.argv[2]||''}`); await p.evaluate(() => window.ready);
  for (const t of [14, 14.03, 33]) {
    const r = await p.evaluate((t) => {
      const T = []; const now = () => performance.now();
      let a = now(); window.render(t); T.push(now() - a);
      const glc = document.getElementById('gl'); const ctx = glc.getContext('webgl2');
      a = now(); const px = new Uint8Array(4); ctx.readPixels(0, 0, 1, 1, ctx.RGBA, ctx.UNSIGNED_BYTE, px); T.push(now() - a);
      const c = document.createElement('canvas'); c.width = 1080; c.height = 1920; const x = c.getContext('2d');
      a = now(); x.drawImage(glc, 0, 0); x.getImageData(0, 0, 1, 1); T.push(now() - a);
      a = now(); c.toDataURL('image/jpeg', 0.92); T.push(now() - a);
      a = now(); document.getElementById('fx').getContext('2d').getImageData(0,0,1,1); T.push(now() - a);
      return T.map(Math.round);
    }, t);
    const s0 = Date.now(); await p.screenshot({ type: 'jpeg', quality: 92 }); const s1 = Date.now();
    console.log(t, 'render,finish,draw,jpeg,fx', r, 'shot', s1 - s0);
  }
  await b.close();
})();
